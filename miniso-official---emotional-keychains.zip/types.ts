export interface Product {
  id: string;
  name: string;
  price: number;
  category: 'Zootopia' | 'Kitty' | 'Anime' | 'Original';
  description: string;
  emotion: string; // e.g., "Happy", "Melancholy", "Excited"
  image: string;
  rating: number;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface MoodMatchRequest {
  mood: string;
}

export interface MoodMatchResponse {
  suggestedProductIds: string[];
  message: string;
}
