import React, { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { PRODUCTS } from '../constants';
import { StarIcon, ShoppingBagIcon } from '../components/Icons';
import { useCart } from '../App';

export const ShopPage = () => {
    const [category, setCategory] = useState('All');
    const categories = ['All', 'Zootopia', 'Kitty', 'Anime'];

    const filteredProducts = category === 'All' 
        ? PRODUCTS 
        : PRODUCTS.filter(p => p.category === category);

    return (
        <div className="pt-32 pb-20 bg-gray-50 min-h-screen">
            <div className="container mx-auto px-4 md:px-6">
                <div className="flex flex-col md:flex-row items-center justify-between mb-12">
                    <h1 className="text-3xl font-black text-gray-900">Shop All Collections</h1>
                    
                    {/* Filters */}
                    <div className="flex gap-2 mt-4 md:mt-0 overflow-x-auto pb-2 md:pb-0 w-full md:w-auto">
                        {categories.map(cat => (
                            <button 
                                key={cat}
                                onClick={() => setCategory(cat)}
                                className={`px-6 py-2 rounded-full text-sm font-bold transition-all whitespace-nowrap ${category === cat ? 'bg-red-600 text-white shadow-md' : 'bg-white text-gray-600 border border-gray-200 hover:border-red-300'}`}
                            >
                                {cat}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                    {filteredProducts.map(product => (
                        <Link key={product.id} to={`/product/${product.id}`} className="bg-white rounded-2xl overflow-hidden border border-gray-100 hover:shadow-xl transition-all group flex flex-col h-full">
                            <div className="aspect-square overflow-hidden relative">
                                <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                                {product.rating >= 4.8 && (
                                    <div className="absolute top-3 left-3 bg-red-500 text-white text-[10px] font-bold px-2 py-1 rounded-full">
                                        BEST SELLER
                                    </div>
                                )}
                            </div>
                            <div className="p-5 flex flex-col flex-1">
                                <div className="flex justify-between items-start mb-2">
                                    <h3 className="font-bold text-gray-800 group-hover:text-red-600 transition-colors line-clamp-1">{product.name}</h3>
                                </div>
                                <p className="text-sm text-gray-500 mb-4 line-clamp-2 flex-1">{product.description}</p>
                                <div className="flex items-center justify-between pt-4 border-t border-gray-50">
                                    <span className="text-xl font-black text-red-600">${product.price.toFixed(2)}</span>
                                    <div className="flex items-center text-amber-400 text-sm font-bold gap-1">
                                        <StarIcon className="w-4 h-4 fill-current" fill /> {product.rating}
                                    </div>
                                </div>
                            </div>
                        </Link>
                    ))}
                </div>
            </div>
        </div>
    );
};

export const ProductDetailsPage = () => {
    const { id } = useParams();
    const { addToCart } = useCart();
    const product = PRODUCTS.find(p => p.id === id);

    if (!product) return <div className="pt-40 text-center">Product not found</div>;

    return (
        <div className="pt-32 pb-20 bg-white min-h-screen">
            <div className="container mx-auto px-4 md:px-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-20 items-start">
                    {/* Image Gallery */}
                    <div className="space-y-4">
                        <div className="aspect-square rounded-3xl overflow-hidden bg-gray-50 border-2 border-gray-100">
                            <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                        </div>
                        <div className="grid grid-cols-4 gap-4">
                            {[1, 2, 3, 4].map(i => (
                                <div key={i} className="aspect-square rounded-xl overflow-hidden bg-gray-50 border border-gray-200 cursor-pointer hover:border-red-400 transition-colors">
                                    <img src={product.image} alt="Thumbnail" className="w-full h-full object-cover opacity-70 hover:opacity-100" />
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Details */}
                    <div>
                        <div className="flex items-center gap-2 mb-4">
                            <span className="bg-red-50 text-red-600 px-3 py-1 rounded-full text-xs font-bold uppercase">{product.category}</span>
                            <span className="bg-gray-50 text-gray-600 px-3 py-1 rounded-full text-xs font-bold uppercase">Emotion: {product.emotion}</span>
                        </div>
                        <h1 className="text-3xl md:text-5xl font-black text-gray-900 mb-4">{product.name}</h1>
                        <div className="flex items-center gap-4 mb-6">
                            <div className="flex text-amber-400">
                                {[1,2,3,4,5].map(star => (
                                    <StarIcon key={star} className="w-5 h-5" fill={star <= Math.round(product.rating)} />
                                ))}
                            </div>
                            <span className="text-gray-400 text-sm">(124 Reviews)</span>
                        </div>
                        <p className="text-3xl font-black text-red-600 mb-8">${product.price.toFixed(2)}</p>

                        <p className="text-gray-600 leading-relaxed mb-8 text-lg">
                            {product.description} <br/>
                            Bring a touch of emotion to your keys, bag, or backpack. Made with premium silicone and high-quality metal clasps.
                        </p>

                        <div className="flex gap-4 mb-12">
                            <button 
                                onClick={() => addToCart(product)}
                                className="flex-1 bg-red-600 text-white font-bold py-4 rounded-full hover:bg-red-700 transition-colors shadow-lg hover:shadow-red-200 flex items-center justify-center gap-2"
                            >
                                <ShoppingBagIcon className="w-5 h-5" /> Add to Cart
                            </button>
                            <button className="p-4 border-2 border-gray-200 rounded-full hover:border-red-200 hover:text-red-600 transition-colors">
                                <StarIcon className="w-6 h-6" />
                            </button>
                        </div>

                        {/* Meta */}
                        <div className="border-t border-gray-100 pt-8 space-y-3 text-sm text-gray-500">
                            <p><span className="font-bold text-gray-900 w-24 inline-block">Shipping:</span> Free worldwide shipping on orders over $50</p>
                            <p><span className="font-bold text-gray-900 w-24 inline-block">Returns:</span> 30-day return policy</p>
                            <p><span className="font-bold text-gray-900 w-24 inline-block">Material:</span> Eco-friendly PVC + Zinc Alloy</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
