import React from 'react';
import { Link } from 'react-router-dom';
import { PRODUCTS } from '../constants';
import { StarIcon, SparklesIcon } from '../components/Icons';

const Hero = () => (
    <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden bg-red-50">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-red-100 rounded-l-[100px] md:rounded-l-[200px] opacity-50 -z-10" />
        
        <div className="container mx-auto px-4 md:px-6 flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 space-y-6">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white border border-red-200 text-red-600 text-xs font-bold uppercase tracking-wider shadow-sm">
                    <SparklesIcon className="w-4 h-4" /> New Collection 2025
                </div>
                <h1 className="text-4xl md:text-6xl font-black text-gray-900 leading-tight">
                    Carry Your <br/> <span className="text-red-600">Emotion</span> Everywhere.
                </h1>
                <p className="text-lg text-gray-600 max-w-md">
                    Discover our exclusive Zootopia & Kitty keychain collection. Cute, durable, and full of personality.
                </p>
                <div className="flex gap-4 pt-4">
                    <Link to="/shop" className="px-8 py-4 bg-red-600 text-white rounded-full font-bold shadow-lg hover:bg-red-700 hover:shadow-xl hover:-translate-y-1 transition-all">
                        Shop Now
                    </Link>
                    <Link to="/mood-matcher" className="px-8 py-4 bg-white text-gray-800 border border-gray-200 rounded-full font-bold hover:bg-gray-50 hover:border-red-200 transition-all">
                        Mood Matcher
                    </Link>
                </div>
            </div>
            <div className="md:w-1/2 mt-12 md:mt-0 relative">
                <div className="relative w-80 h-80 md:w-[500px] md:h-[500px] mx-auto">
                    <div className="absolute inset-0 bg-white rounded-full shadow-2xl flex items-center justify-center overflow-hidden border-8 border-white animate-float">
                        <img 
                            src={PRODUCTS[0].image} 
                            alt="Hero Product" 
                            className="w-full h-full object-cover hover:scale-110 transition-transform duration-700" 
                        />
                    </div>
                    {/* Decorative blobs */}
                    <div className="absolute -top-4 -right-4 w-24 h-24 bg-yellow-300 rounded-full blur-xl opacity-50" />
                    <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-red-400 rounded-full blur-xl opacity-50" />
                </div>
            </div>
        </div>
    </section>
);

const FeaturedProducts = () => (
    <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6">
            <div className="text-center mb-16">
                <h2 className="text-3xl font-black text-gray-900 mb-4">Best Sellers</h2>
                <p className="text-gray-500">The community's favorite picks.</p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                {PRODUCTS.slice(0, 4).map(product => (
                    <Link key={product.id} to={`/product/${product.id}`} className="group">
                        <div className="relative aspect-square bg-gray-50 rounded-2xl overflow-hidden mb-4">
                            <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                            <div className="absolute top-3 right-3 bg-white p-2 rounded-full shadow-md hover:text-red-600 transition-colors">
                                <StarIcon className="w-4 h-4" />
                            </div>
                        </div>
                        <h3 className="font-bold text-lg text-gray-800 group-hover:text-red-600 transition-colors">{product.name}</h3>
                        <div className="flex items-center justify-between mt-1">
                            <p className="text-gray-500 text-sm">{product.category}</p>
                            <p className="font-bold text-red-600">${product.price.toFixed(2)}</p>
                        </div>
                    </Link>
                ))}
            </div>
        </div>
    </section>
);

const MoodFeatureBanner = () => (
    <section className="py-20 bg-gray-900 text-white overflow-hidden relative">
        <div className="absolute inset-0 bg-[url('https://picsum.photos/seed/pattern/1000/1000')] opacity-10 bg-cover bg-center" />
        <div className="container mx-auto px-4 md:px-6 relative z-10 flex flex-col md:flex-row items-center justify-between gap-12">
            <div className="md:w-1/2">
                <h2 className="text-3xl md:text-5xl font-black mb-6">Let AI Find Your <br/> <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-pink-400">Perfect Match</span></h2>
                <p className="text-gray-300 mb-8 text-lg">
                    Feeling happy, sad, or energetic? Tell our mascot how you feel, and we'll recommend the keychain that matches your emotion perfectly.
                </p>
                <Link to="/mood-matcher" className="inline-block px-8 py-4 bg-gradient-to-r from-red-600 to-pink-600 rounded-full font-bold shadow-lg shadow-red-900/50 hover:scale-105 transition-transform">
                    Try Mood Matcher
                </Link>
            </div>
            <div className="md:w-1/2 flex justify-center">
                 <div className="relative w-64 h-64 bg-white/10 backdrop-blur-lg rounded-3xl p-6 border border-white/20 transform rotate-3">
                    <div className="absolute -top-10 -left-10 bg-white text-gray-900 p-4 rounded-xl shadow-lg max-w-[150px] text-xs font-bold">
                        "I'm feeling a bit gloomy today..."
                    </div>
                    <div className="absolute -bottom-5 -right-5 bg-red-600 text-white p-4 rounded-xl shadow-lg max-w-[180px] text-xs font-bold">
                        "You need the Sunshine Lion to brighten your day! 🌞"
                    </div>
                    <img src={PRODUCTS[2].image} className="w-full h-full object-cover rounded-2xl" />
                 </div>
            </div>
        </div>
    </section>
);

const HomePage = () => (
    <main>
        <Hero />
        <FeaturedProducts />
        <MoodFeatureBanner />
    </main>
);

export default HomePage;
