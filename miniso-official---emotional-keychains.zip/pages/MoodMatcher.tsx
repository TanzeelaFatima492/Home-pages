import React, { useState } from 'react';
import { getMoodRecommendation } from '../services/geminiService';
import { PRODUCTS } from '../constants';
import { Link } from 'react-router-dom';
import { SparklesIcon } from '../components/Icons';

export const MoodMatcher = () => {
    const [mood, setMood] = useState('');
    const [loading, setLoading] = useState(false);
    const [result, setResult] = useState<{ message: string; products: typeof PRODUCTS } | null>(null);

    const handleAnalyze = async () => {
        if (!mood.trim()) return;
        setLoading(true);
        try {
            const response = await getMoodRecommendation(mood);
            const recommendedProducts = PRODUCTS.filter(p => response.recommendedProductIds.includes(p.id));
            setResult({
                message: response.message,
                products: recommendedProducts.length > 0 ? recommendedProducts : [PRODUCTS[0]] // Fallback
            });
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="pt-32 pb-20 bg-gradient-to-b from-red-50 to-white min-h-screen">
            <div className="container mx-auto px-4 md:px-6 max-w-3xl text-center">
                <div className="inline-block p-4 rounded-full bg-white shadow-lg mb-8 animate-bounce">
                    <span className="text-4xl">🤖 ❤️</span>
                </div>
                <h1 className="text-4xl md:text-6xl font-black text-gray-900 mb-6">
                    How are you feeling today?
                </h1>
                <p className="text-xl text-gray-600 mb-12">
                    Tell us about your day or your mood, and our AI will find the perfect emotional companion for you.
                </p>

                <div className="bg-white p-2 rounded-2xl shadow-xl border border-red-100 flex flex-col md:flex-row gap-2 mb-12">
                    <input 
                        type="text" 
                        value={mood}
                        onChange={(e) => setMood(e.target.value)}
                        placeholder="e.g., I'm feeling a bit stressed about exams..." 
                        className="flex-1 p-4 rounded-xl outline-none text-lg"
                        onKeyDown={(e) => e.key === 'Enter' && handleAnalyze()}
                    />
                    <button 
                        onClick={handleAnalyze}
                        disabled={loading || !mood}
                        className="bg-red-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-red-700 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                        {loading ? 'Analyzing...' : <><SparklesIcon /> Match Me</>}
                    </button>
                </div>

                {result && (
                    <div className="animate-fade-in-up">
                        <div className="bg-red-50 border border-red-200 p-6 rounded-2xl mb-12 inline-block text-left">
                             <p className="text-lg font-medium text-gray-800 italic">
                                " {result.message} "
                             </p>
                        </div>

                        <h3 className="text-2xl font-bold mb-8">We recommend:</h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 justify-center">
                            {result.products.map(product => (
                                <Link key={product.id} to={`/product/${product.id}`} className="bg-white rounded-2xl shadow-lg overflow-hidden hover:scale-105 transition-transform duration-300 border border-gray-100">
                                    <div className="aspect-square relative">
                                        <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                                        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/50 to-transparent p-4">
                                            <p className="text-white font-bold">{product.emotion} Vibes</p>
                                        </div>
                                    </div>
                                    <div className="p-4">
                                        <h4 className="font-bold text-gray-900">{product.name}</h4>
                                        <p className="text-red-600 font-bold mt-1">${product.price.toFixed(2)}</p>
                                    </div>
                                </Link>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};
