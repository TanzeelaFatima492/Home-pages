import { GoogleGenAI, Type } from "@google/genai";
import { PRODUCTS } from '../constants';

// Initialize the Gemini AI client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getMoodRecommendation = async (moodText: string): Promise<{ message: string, recommendedProductIds: string[] }> => {
  try {
    const productContext = PRODUCTS.map(p => `${p.id}: ${p.name} (${p.emotion} emotion)`).join(', ');

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `The user is feeling: "${moodText}".
      Based on their mood, recommend 1-2 keychains from this list: [${productContext}].
      
      Return a JSON object with:
      1. "message": A short, cute, anime-style empathetic message (max 2 sentences) addressing their mood and suggesting the item.
      2. "recommendedProductIds": An array of the ID strings of the recommended products.
      `,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            message: { type: Type.STRING },
            recommendedProductIds: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          }
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text);
    }
    
    throw new Error("No response text");
  } catch (error) {
    console.error("Gemini Mood Match Error:", error);
    // Fallback
    return {
      message: "We think a cute keychain is always the answer!",
      recommendedProductIds: ['1', '3']
    };
  }
};
