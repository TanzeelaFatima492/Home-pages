import { Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Judy Hopps Officer Key',
    price: 9.99,
    category: 'Zootopia',
    description: 'Determined and optimistic. This keychain brings the spirit of justice and big dreams to your daily carry.',
    emotion: 'Optimistic',
    image: 'https://picsum.photos/seed/judy/500/500',
    rating: 4.9
  },
  {
    id: '2',
    name: 'Nick Wilde Sly Fox',
    price: 9.99,
    category: 'Zootopia',
    description: 'Charming and clever. A reminder to stay witty and cool under pressure.',
    emotion: 'Cool',
    image: 'https://picsum.photos/seed/nick/500/500',
    rating: 4.8
  },
  {
    id: '3',
    name: 'Classic Red Bow Kitty',
    price: 12.50,
    category: 'Kitty',
    description: 'Pure sweetness and friendship. The classic icon of cuteness.',
    emotion: 'Sweet',
    image: 'https://picsum.photos/seed/kitty1/500/500',
    rating: 5.0
  },
  {
    id: '4',
    name: 'Angel Wings Kitty',
    price: 14.00,
    category: 'Kitty',
    description: 'Soaring high with adorable wings. Perfect for dreamers.',
    emotion: 'Dreamy',
    image: 'https://picsum.photos/seed/kitty2/500/500',
    rating: 4.7
  },
  {
    id: '5',
    name: 'Sleepy Sloth Flash',
    price: 8.50,
    category: 'Zootopia',
    description: 'Take... it... easy... No rush in life with Flash by your side.',
    emotion: 'Chill',
    image: 'https://picsum.photos/seed/flash/500/500',
    rating: 4.6
  },
  {
    id: '6',
    name: 'Grumpy Chief Bogo',
    price: 10.00,
    category: 'Zootopia',
    description: 'Stern but caring deep down. For those who mean business.',
    emotion: 'Serious',
    image: 'https://picsum.photos/seed/bogo/500/500',
    rating: 4.5
  },
  {
    id: '7',
    name: 'Strawberry Pink Anime Girl',
    price: 11.99,
    category: 'Anime',
    description: 'Bursting with energy and strawberry sweetness.',
    emotion: 'Energetic',
    image: 'https://picsum.photos/seed/anime1/500/500',
    rating: 4.8
  },
  {
    id: '8',
    name: 'Midnight Ninja Cat',
    price: 13.50,
    category: 'Anime',
    description: 'Silent, mysterious, and incredibly cute in the dark.',
    emotion: 'Mysterious',
    image: 'https://picsum.photos/seed/ninja/500/500',
    rating: 4.9
  }
];

export const NAV_LINKS = [
  { label: 'Home', href: '/' },
  { label: 'Shop All', href: '/shop' },
  { label: 'New Arrivals', href: '/shop?filter=new' },
  { label: 'Mood Matcher', href: '/mood-matcher' }, // AI Feature
];
