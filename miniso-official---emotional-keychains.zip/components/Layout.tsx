import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom'; // We will use HashRouter in App
import { NAV_LINKS } from '../constants';
import { ShoppingBagIcon, MenuIcon, XIcon, HeartIcon } from './Icons';
import { useCart } from '../App';

interface LayoutProps {
  children: React.ReactNode;
}

export const Header = ({ onCartClick }: { onCartClick: () => void }) => {
  const { cart } = useCart();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-white/95 backdrop-blur-md shadow-md py-3' : 'bg-transparent py-6'}`}>
      <div className="container mx-auto px-4 md:px-6 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center text-white font-bold text-xl group-hover:rotate-12 transition-transform">
                M
            </div>
            <span className={`font-black text-2xl tracking-tight ${isScrolled ? 'text-gray-900' : 'text-red-600'} transition-colors`}>
                MINISO
            </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {NAV_LINKS.map((link) => (
            <Link 
                key={link.href} 
                to={link.href}
                className={`font-semibold text-sm uppercase tracking-wide hover:text-red-500 transition-colors ${location.pathname === link.href ? 'text-red-600' : 'text-gray-600'}`}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Actions */}
        <div className="flex items-center gap-4">
            <button className="text-gray-600 hover:text-red-600 transition-colors">
                <HeartIcon className="w-6 h-6" />
            </button>
            <button onClick={onCartClick} className="relative text-gray-600 hover:text-red-600 transition-colors group">
                <ShoppingBagIcon className="w-6 h-6 group-hover:scale-110 transition-transform" />
                {totalItems > 0 && (
                    <span className="absolute -top-2 -right-2 bg-red-600 text-white text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full border-2 border-white">
                        {totalItems}
                    </span>
                )}
            </button>
            <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="md:hidden text-gray-600">
                {mobileMenuOpen ? <XIcon /> : <MenuIcon />}
            </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="absolute top-full left-0 w-full bg-white shadow-lg md:hidden p-4 flex flex-col gap-4 border-t border-gray-100">
            {NAV_LINKS.map((link) => (
            <Link 
                key={link.href} 
                to={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="font-bold text-gray-700 py-2 border-b border-gray-50 hover:text-red-600"
            >
              {link.label}
            </Link>
          ))}
        </div>
      )}
    </header>
  );
};

export const Footer = () => (
    <footer className="bg-gray-900 text-white py-12 md:py-16">
        <div className="container mx-auto px-4 md:px-6 grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
                <div className="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center text-white font-bold text-xl mb-4">M</div>
                <p className="text-gray-400 text-sm leading-relaxed">
                    Miniso Official. Bringing joy and emotion to your everyday life through adorable, high-quality keychains.
                </p>
            </div>
            <div>
                <h3 className="font-bold text-lg mb-4">Shop</h3>
                <ul className="space-y-2 text-gray-400 text-sm">
                    <li><Link to="/shop" className="hover:text-red-500">New Arrivals</Link></li>
                    <li><Link to="/shop" className="hover:text-red-500">Best Sellers</Link></li>
                    <li><Link to="/shop" className="hover:text-red-500">Zootopia Collection</Link></li>
                    <li><Link to="/shop" className="hover:text-red-500">Kitty Collection</Link></li>
                </ul>
            </div>
            <div>
                <h3 className="font-bold text-lg mb-4">Support</h3>
                <ul className="space-y-2 text-gray-400 text-sm">
                    <li><Link to="#" className="hover:text-red-500">Track Order</Link></li>
                    <li><Link to="#" className="hover:text-red-500">Returns & Exchanges</Link></li>
                    <li><Link to="#" className="hover:text-red-500">Shipping Info</Link></li>
                    <li><Link to="#" className="hover:text-red-500">Contact Us</Link></li>
                </ul>
            </div>
            <div>
                <h3 className="font-bold text-lg mb-4">Stay Connected</h3>
                <p className="text-gray-400 text-sm mb-4">Subscribe to get special offers and updates.</p>
                <div className="flex">
                    <input type="email" placeholder="Enter email" className="bg-gray-800 text-white px-4 py-2 rounded-l-lg outline-none w-full text-sm focus:ring-1 focus:ring-red-500" />
                    <button className="bg-red-600 px-4 py-2 rounded-r-lg font-bold hover:bg-red-700 transition-colors">Go</button>
                </div>
            </div>
        </div>
        <div className="container mx-auto px-4 mt-12 pt-8 border-t border-gray-800 text-center text-gray-500 text-xs">
            &copy; {new Date().getFullYear()} Miniso Official. All rights reserved. This is a demo.
        </div>
    </footer>
);

export const CartDrawer = ({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) => {
    const { cart, updateQuantity, removeFromCart, total } = useCart();

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[60] flex justify-end">
            <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
            <div className="relative w-full max-w-md bg-white h-full shadow-2xl flex flex-col animate-slide-in">
                <div className="p-5 border-b flex items-center justify-between bg-red-50">
                    <h2 className="text-xl font-bold text-gray-800">Your Cart</h2>
                    <button onClick={onClose} className="p-2 hover:bg-red-100 rounded-full transition-colors">
                        <XIcon />
                    </button>
                </div>

                <div className="flex-1 overflow-y-auto p-5 space-y-6">
                    {cart.length === 0 ? (
                        <div className="h-full flex flex-col items-center justify-center text-gray-400 space-y-4">
                            <ShoppingBagIcon className="w-16 h-16 opacity-20" />
                            <p>Your cart is empty.</p>
                            <Link to="/shop" onClick={onClose} className="text-red-600 font-bold hover:underline">Start Shopping</Link>
                        </div>
                    ) : (
                        cart.map(item => (
                            <div key={item.id} className="flex gap-4">
                                <div className="w-20 h-20 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
                                    <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                                </div>
                                <div className="flex-1 flex flex-col justify-between">
                                    <div>
                                        <h3 className="font-bold text-gray-800 line-clamp-1">{item.name}</h3>
                                        <p className="text-sm text-gray-500">{item.category}</p>
                                    </div>
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center border rounded-lg">
                                            <button 
                                                onClick={() => updateQuantity(item.id, Math.max(1, item.quantity - 1))}
                                                className="px-2 py-1 hover:bg-gray-100 text-gray-600"
                                            >-</button>
                                            <span className="px-2 text-sm font-bold">{item.quantity}</span>
                                            <button 
                                                onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                                className="px-2 py-1 hover:bg-gray-100 text-gray-600"
                                            >+</button>
                                        </div>
                                        <span className="font-bold text-red-600">${(item.price * item.quantity).toFixed(2)}</span>
                                    </div>
                                </div>
                                <button onClick={() => removeFromCart(item.id)} className="text-gray-400 hover:text-red-500 self-start">
                                    <XIcon className="w-4 h-4" />
                                </button>
                            </div>
                        ))
                    )}
                </div>

                {cart.length > 0 && (
                    <div className="p-6 border-t bg-gray-50">
                        <div className="flex justify-between mb-4 text-lg font-bold text-gray-800">
                            <span>Total</span>
                            <span>${total.toFixed(2)}</span>
                        </div>
                        <Link 
                            to="/checkout" 
                            onClick={onClose}
                            className="block w-full bg-red-600 text-white text-center font-bold py-3 rounded-full hover:bg-red-700 transition-colors shadow-lg hover:shadow-xl"
                        >
                            Checkout Now
                        </Link>
                    </div>
                )}
            </div>
        </div>
    );
};
