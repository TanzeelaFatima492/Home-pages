import { GoogleGenAI, Type } from "@google/genai";
import { DesignRequest, AIReponseSchema } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateDesignSuggestion = async (request: DesignRequest): Promise<AIReponseSchema> => {
  const prompt = `
    You are an expert Pakistani hand-embroidery consultant for "Tatriz by Zara". 
    A customer wants a custom design.
    
    Occasion: ${request.occasion}
    Fabric: ${request.fabric}
    Color Preference: ${request.colorPreference}
    Details: ${request.additionalDetails}

    Please suggest traditional yet modern embroidery motifs (like Phulkari, Sindhi Ajrak patterns, Zardozi, etc.), a suitable color palette, and refine the fabric choice if needed.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            suggestedMotifs: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "List of specific embroidery styles or motifs"
            },
            colorPalette: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "List of hex codes or color names"
            },
            fabricRecommendation: {
              type: Type.STRING,
              description: "Best fabric choice for this work"
            },
            estimatedTime: {
              type: Type.STRING,
              description: "Estimated time to complete (e.g., 2-3 weeks)"
            },
            description: {
              type: Type.STRING,
              description: "A poetic and inviting description of the final piece"
            }
          },
          required: ["suggestedMotifs", "colorPalette", "fabricRecommendation", "estimatedTime", "description"],
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    return JSON.parse(text) as AIReponseSchema;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Failed to generate design suggestions.");
  }
};