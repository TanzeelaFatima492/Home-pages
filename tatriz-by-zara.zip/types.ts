export interface Product {
  id: number;
  name: string;
  category: 'wedding' | 'ceremony' | 'baby' | 'accessories' | 'watches';
  price: number;
  description: string;
  image: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface DesignRequest {
  occasion: string;
  fabric: string;
  colorPreference: string;
  additionalDetails: string;
}

export interface AIReponseSchema {
  suggestedMotifs: string[];
  colorPalette: string[];
  fabricRecommendation: string;
  estimatedTime: string;
  description: string;
}