import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Star } from 'lucide-react';

const Home: React.FC = () => {
  return (
    <div className="flex flex-col w-full">
      {/* Hero Section */}
      <section className="relative h-[80vh] w-full">
        <div className="absolute inset-0">
          <img 
            src="https://picsum.photos/1920/1080?grayscale" 
            alt="Embroidery Background" 
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-tatriz-green/90 to-transparent"></div>
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 h-full flex items-center">
          <div className="max-w-2xl text-white">
            <h1 className="font-serif text-5xl md:text-7xl font-bold mb-6 leading-tight">
              Hand Embroidery <br/> 
              <span className="text-tatriz-gold italic">On Demand</span>
            </h1>
            <p className="text-lg md:text-xl mb-8 font-light text-gray-100">
              From the heart of Pakistan to your wardrobe. Exquisite handcrafted designs for weddings, newborns, and treasured gifts.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/shop" className="px-8 py-3 bg-tatriz-gold text-tatriz-green font-bold rounded hover:bg-yellow-500 transition text-center">
                Shop Collection
              </Link>
              <Link to="/custom-design" className="px-8 py-3 border-2 border-white text-white font-bold rounded hover:bg-white hover:text-tatriz-green transition text-center">
                Custom Design
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Grid */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-center text-tatriz-green mb-12">Our Specialties</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Card 1 */}
            <Link to="/shop?category=wedding" className="group relative overflow-hidden rounded-lg shadow-lg aspect-[3/4]">
              <img src="https://picsum.photos/600/800?random=1" alt="Wedding" className="w-full h-full object-cover transition duration-500 group-hover:scale-110" />
              <div className="absolute inset-0 bg-black/40 group-hover:bg-black/50 transition flex items-center justify-center">
                <h3 className="font-serif text-3xl text-white font-bold border-b-2 border-tatriz-gold pb-2">Weddings & Events</h3>
              </div>
            </Link>
             {/* Card 2 */}
             <Link to="/shop?category=baby" className="group relative overflow-hidden rounded-lg shadow-lg aspect-[3/4]">
              <img src="https://picsum.photos/600/800?random=2" alt="New Born" className="w-full h-full object-cover transition duration-500 group-hover:scale-110" />
              <div className="absolute inset-0 bg-black/40 group-hover:bg-black/50 transition flex items-center justify-center">
                <h3 className="font-serif text-3xl text-white font-bold border-b-2 border-tatriz-gold pb-2">New Baby</h3>
              </div>
            </Link>
             {/* Card 3 */}
             <Link to="/shop?category=accessories" className="group relative overflow-hidden rounded-lg shadow-lg aspect-[3/4]">
              <img src="https://picsum.photos/600/800?random=3" alt="Accessories" className="w-full h-full object-cover transition duration-500 group-hover:scale-110" />
              <div className="absolute inset-0 bg-black/40 group-hover:bg-black/50 transition flex items-center justify-center">
                <h3 className="font-serif text-3xl text-white font-bold border-b-2 border-tatriz-gold pb-2">Gajry & Watches</h3>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* Feature Highlight: Gajry */}
      <section className="py-16 bg-tatriz-cream">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center gap-12">
          <div className="w-full md:w-1/2">
             <img src="https://picsum.photos/800/600?random=4" alt="Gajry" className="rounded-lg shadow-xl" />
          </div>
          <div className="w-full md:w-1/2 space-y-6">
            <h2 className="font-serif text-4xl font-bold text-tatriz-green">Traditional Gajry & Floral Art</h2>
            <p className="text-gray-700 leading-relaxed">
              Complete your festive look with our handcrafted Gajry. Made with fresh-looking artificial flowers interwoven with gold threads and beads, perfect for Mehndi ceremonies, Mayo, and dholkis. Customizable colors to match your outfit.
            </p>
            <Link to="/shop" className="inline-flex items-center text-tatriz-red font-bold hover:underline">
              View Accessories <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;