import React, { useState } from 'react';
import { Wand2, Loader2, Check } from 'lucide-react';
import { DesignRequest, AIReponseSchema } from '../types';
import { generateDesignSuggestion } from '../services/geminiService';

const CustomDesign: React.FC = () => {
  const [formData, setFormData] = useState<DesignRequest>({
    occasion: '',
    fabric: '',
    colorPreference: '',
    additionalDetails: ''
  });
  const [loading, setLoading] = useState(false);
  const [suggestion, setSuggestion] = useState<AIReponseSchema | null>(null);
  const [error, setError] = useState('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleGetSuggestion = async () => {
    if (!formData.occasion) {
      setError("Please at least tell us the occasion.");
      return;
    }
    setLoading(true);
    setError('');
    try {
      const result = await generateDesignSuggestion(formData);
      setSuggestion(result);
    } catch (err) {
      setError("Sorry, our design assistant is busy. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    alert("Custom design request submitted! Zara will contact you shortly.");
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="font-serif text-4xl md:text-5xl font-bold text-tatriz-green mb-4">Custom Design Studio</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Not sure what you want? Let our AI-powered assistant, trained on Pakistani heritage patterns, 
          suggest the perfect design for your special day.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Input Form */}
        <div className="bg-white p-8 rounded-lg shadow-lg">
          <h2 className="font-serif text-2xl font-bold mb-6 flex items-center gap-2">
            <span className="bg-tatriz-gold text-tatriz-green w-8 h-8 rounded-full flex items-center justify-center text-sm">1</span>
            Describe Your Vision
          </h2>
          
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Occasion</label>
              <select 
                name="occasion" 
                value={formData.occasion} 
                onChange={handleInputChange}
                className="w-full border border-gray-300 rounded-md px-4 py-2 focus:ring-2 focus:ring-tatriz-gold focus:outline-none"
              >
                <option value="">Select Occasion</option>
                <option value="Baraat (Wedding Day)">Baraat (Wedding Day)</option>
                <option value="Mehndi / Dholki">Mehndi / Dholki</option>
                <option value="Walima (Reception)">Walima (Reception)</option>
                <option value="Nikah">Nikah</option>
                <option value="New Born Gift">New Born Gift</option>
                <option value="Casual/Formal Party">Casual/Formal Party</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Preferred Fabric</label>
              <input 
                type="text" 
                name="fabric" 
                value={formData.fabric} 
                onChange={handleInputChange}
                placeholder="e.g. Chiffon, Velvet, Cotton" 
                className="w-full border border-gray-300 rounded-md px-4 py-2 focus:ring-2 focus:ring-tatriz-gold focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Color Preferences</label>
              <input 
                type="text" 
                name="colorPreference" 
                value={formData.colorPreference} 
                onChange={handleInputChange}
                placeholder="e.g. Deep Red, Emerald Green, Pastels" 
                className="w-full border border-gray-300 rounded-md px-4 py-2 focus:ring-2 focus:ring-tatriz-gold focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Additional Details</label>
              <textarea 
                name="additionalDetails" 
                value={formData.additionalDetails} 
                onChange={handleInputChange}
                rows={4}
                placeholder="Describe the look, heavy or light work, specific flowers..." 
                className="w-full border border-gray-300 rounded-md px-4 py-2 focus:ring-2 focus:ring-tatriz-gold focus:outline-none"
              />
            </div>

            <div className="flex gap-4">
               <button 
                type="button"
                onClick={handleGetSuggestion}
                disabled={loading}
                className="flex-1 bg-tatriz-green text-white py-3 px-4 rounded hover:bg-green-900 transition flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Wand2 className="w-5 h-5" />}
                Get AI Suggestions
              </button>
            </div>
            {error && <p className="text-red-600 text-sm mt-2">{error}</p>}
          </div>
        </div>

        {/* Output / Final Form */}
        <div className="bg-tatriz-cream p-8 rounded-lg border-2 border-dashed border-tatriz-gold relative">
           <h2 className="font-serif text-2xl font-bold mb-6 flex items-center gap-2 text-gray-800">
            <span className="bg-tatriz-green text-white w-8 h-8 rounded-full flex items-center justify-center text-sm">2</span>
            Design Proposal
          </h2>

          {suggestion ? (
            <div className="space-y-6 animate-fade-in">
              <div className="bg-white p-6 rounded shadow-sm">
                <h3 className="font-serif text-xl font-bold text-tatriz-green mb-2">Concept</h3>
                <p className="italic text-gray-700">"{suggestion.description}"</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white p-4 rounded shadow-sm">
                  <h4 className="font-bold text-sm text-gray-500 uppercase mb-2">Suggested Motifs</h4>
                  <ul className="list-disc list-inside text-gray-800">
                    {suggestion.suggestedMotifs.map((m, i) => <li key={i}>{m}</li>)}
                  </ul>
                </div>
                <div className="bg-white p-4 rounded shadow-sm">
                  <h4 className="font-bold text-sm text-gray-500 uppercase mb-2">Palette</h4>
                  <div className="flex gap-2 flex-wrap">
                    {suggestion.colorPalette.map((color, i) => (
                      <span key={i} className="px-3 py-1 bg-gray-100 rounded text-sm">{color}</span>
                    ))}
                  </div>
                </div>
              </div>

               <div className="bg-white p-4 rounded shadow-sm">
                   <div className="flex justify-between items-center">
                       <div>
                           <h4 className="font-bold text-sm text-gray-500 uppercase">Fabric</h4>
                           <p className="text-gray-800">{suggestion.fabricRecommendation}</p>
                       </div>
                        <div className="text-right">
                           <h4 className="font-bold text-sm text-gray-500 uppercase">Timeline</h4>
                           <p className="text-gray-800">{suggestion.estimatedTime}</p>
                       </div>
                   </div>
                </div>

              <button 
                onClick={handleSubmitOrder}
                className="w-full bg-tatriz-gold text-tatriz-green font-bold py-4 rounded shadow hover:bg-yellow-500 transition flex items-center justify-center gap-2"
              >
                <Check className="w-6 h-6" />
                Submit Request for Quotation
              </button>
              <p className="text-xs text-gray-500 text-center mt-2">No payment required yet. We will contact you to finalize price.</p>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-gray-400 min-h-[300px]">
              <Wand2 className="w-16 h-16 mb-4 opacity-20" />
              <p>Fill out the form and ask our AI for traditional inspiration.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CustomDesign;