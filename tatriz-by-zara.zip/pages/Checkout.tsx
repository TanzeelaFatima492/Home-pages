import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { CheckCircle } from 'lucide-react';

const Checkout: React.FC = () => {
  const { cartTotal, clearCart, cartCount } = useCart();
  const navigate = useNavigate();
  const [step, setStep] = useState<'form' | 'success'>('form');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTimeout(() => {
      clearCart();
      setStep('success');
    }, 1000);
  };

  if (cartCount === 0 && step !== 'success') {
     // Redirect if empty but allow showing success message
     setTimeout(() => navigate('/shop'), 100);
     return null;
  }

  if (step === 'success') {
    return (
      <div className="min-h-[60vh] flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <div className="mx-auto bg-green-100 w-20 h-20 rounded-full flex items-center justify-center mb-6">
            <CheckCircle className="w-10 h-10 text-tatriz-green" />
          </div>
          <h2 className="font-serif text-3xl font-bold text-gray-900 mb-2">Order Placed!</h2>
          <p className="text-gray-600 mb-8">
            Shukriya! Your order has been received. We will start crafting your items with love. You will receive an email confirmation shortly.
          </p>
          <button onClick={() => navigate('/')} className="bg-tatriz-gold text-tatriz-green px-8 py-3 rounded font-bold hover:bg-yellow-500 transition">
            Back to Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <h1 className="font-serif text-3xl font-bold text-tatriz-green mb-8 text-center">Checkout</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Form */}
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h2 className="text-xl font-bold mb-6">Shipping Details</h2>
          <form id="checkout-form" onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-600 mb-1">First Name</label>
                <input required type="text" className="w-full border border-gray-300 p-2 rounded focus:ring-tatriz-gold focus:border-tatriz-gold" />
              </div>
              <div>
                <label className="block text-sm text-gray-600 mb-1">Last Name</label>
                <input required type="text" className="w-full border border-gray-300 p-2 rounded focus:ring-tatriz-gold focus:border-tatriz-gold" />
              </div>
            </div>
            
            <div>
              <label className="block text-sm text-gray-600 mb-1">Address</label>
              <input required type="text" className="w-full border border-gray-300 p-2 rounded focus:ring-tatriz-gold focus:border-tatriz-gold" />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-600 mb-1">City</label>
                <input required type="text" className="w-full border border-gray-300 p-2 rounded focus:ring-tatriz-gold focus:border-tatriz-gold" />
              </div>
               <div>
                <label className="block text-sm text-gray-600 mb-1">Postal Code</label>
                <input required type="text" className="w-full border border-gray-300 p-2 rounded focus:ring-tatriz-gold focus:border-tatriz-gold" />
              </div>
            </div>

            <div>
              <label className="block text-sm text-gray-600 mb-1">Phone (Pakistan)</label>
              <input required type="tel" placeholder="+92 300 1234567" className="w-full border border-gray-300 p-2 rounded focus:ring-tatriz-gold focus:border-tatriz-gold" />
            </div>

            <div className="pt-6">
              <h2 className="text-xl font-bold mb-4">Payment Method</h2>
              <div className="space-y-2">
                <label className="flex items-center gap-3 p-3 border rounded cursor-pointer hover:bg-gray-50">
                  <input type="radio" name="payment" defaultChecked className="text-tatriz-green focus:ring-tatriz-green" />
                  <span>Cash on Delivery (COD)</span>
                </label>
                 <label className="flex items-center gap-3 p-3 border rounded cursor-pointer hover:bg-gray-50">
                  <input type="radio" name="payment" className="text-tatriz-green focus:ring-tatriz-green" />
                  <span>Bank Transfer (JazzCash / EasyPaisa)</span>
                </label>
              </div>
            </div>
          </form>
        </div>

        {/* Summary */}
        <div className="bg-gray-50 p-6 rounded-lg h-fit">
           <h2 className="text-xl font-bold mb-6">Order Summary</h2>
           <div className="flex justify-between mb-2 font-bold text-lg">
             <span>Total Amount</span>
             <span className="text-tatriz-green">PKR {cartTotal.toLocaleString()}</span>
           </div>
           <p className="text-sm text-gray-500 mb-6">Including taxes and free shipping.</p>
           
           <button 
            type="submit" 
            form="checkout-form"
            className="w-full bg-tatriz-green text-white py-4 rounded font-bold hover:bg-green-900 transition shadow-lg"
          >
             Place Order
           </button>
        </div>
      </div>
    </div>
  );
};

export default Checkout;