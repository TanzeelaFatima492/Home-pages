import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { ShoppingBag, Filter } from 'lucide-react';
import { Product } from '../types';
import { useCart } from '../context/CartContext';

const MOCK_PRODUCTS: Product[] = [
  { id: 1, name: "Bridal Phulkari Dupatta", category: "wedding", price: 15000, description: "Hand-stitched traditional Phulkari heavy dupatta.", image: "https://picsum.photos/400/500?random=10" },
  { id: 2, name: "Custom Nikah Nama Frame", category: "wedding", price: 8500, description: "Velvet base with gold zardozi work.", image: "https://picsum.photos/400/500?random=11" },
  { id: 3, name: "Baby's First Kurta (White)", category: "baby", price: 3500, description: "Soft cotton with delicate neckline embroidery.", image: "https://picsum.photos/400/500?random=12" },
  { id: 4, name: "Newborn Swaddle Set", category: "baby", price: 4500, description: "Embroidered name and date of birth.", image: "https://picsum.photos/400/500?random=13" },
  { id: 5, name: "Rose & Jasmine Gajry Pair", category: "accessories", price: 2000, description: "Artificial flowers with pearl detailing.", image: "https://picsum.photos/400/500?random=14" },
  { id: 6, name: "Mehndi Plate Cover", category: "ceremony", price: 1200, description: "Gota work cover for rasam plates.", image: "https://picsum.photos/400/500?random=15" },
  { id: 7, name: "Friendship Bracelets (Embroidered)", category: "ceremony", price: 800, description: "Set of 5 custom thread bracelets.", image: "https://picsum.photos/400/500?random=16" },
  { id: 8, name: "Vintage Strap Watch", category: "watches", price: 6000, description: "Leather strap with micro-embroidery floral patterns.", image: "https://picsum.photos/400/500?random=17" },
  { id: 9, name: "Midnight Blue Shawl", category: "wedding", price: 12000, description: "Heavy kashmiri tanka work.", image: "https://picsum.photos/400/500?random=18" },
];

const Shop: React.FC = () => {
  const { addToCart } = useCart();
  const location = useLocation();
  const [filter, setFilter] = useState<string>('all');

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const category = params.get('category');
    if (category) {
      setFilter(category);
    }
  }, [location]);

  const filteredProducts = filter === 'all' 
    ? MOCK_PRODUCTS 
    : MOCK_PRODUCTS.filter(p => p.category === filter || (filter === 'accessories' && (p.category === 'watches' || p.category === 'accessories')));

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row justify-between items-center mb-8">
        <h1 className="font-serif text-4xl font-bold text-tatriz-green">Shop Collection</h1>
        
        <div className="flex items-center gap-2 mt-4 md:mt-0 overflow-x-auto pb-2 md:pb-0">
          <Filter className="w-5 h-5 text-gray-500" />
          {['all', 'wedding', 'baby', 'ceremony', 'accessories', 'watches'].map(cat => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-4 py-2 rounded-full text-sm capitalize transition whitespace-nowrap ${
                filter === cat 
                ? 'bg-tatriz-green text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        {filteredProducts.map(product => (
          <div key={product.id} className="bg-white rounded-lg shadow-md hover:shadow-xl transition duration-300 flex flex-col h-full">
            <div className="relative h-64 w-full overflow-hidden rounded-t-lg bg-gray-200">
              <img 
                src={product.image} 
                alt={product.name} 
                className="w-full h-full object-cover hover:scale-105 transition duration-500"
              />
              <div className="absolute top-2 right-2 bg-white/90 px-2 py-1 rounded text-xs font-bold uppercase tracking-wide text-gray-600">
                {product.category}
              </div>
            </div>
            <div className="p-4 flex flex-col flex-grow">
              <h3 className="font-serif text-lg font-bold text-gray-900 mb-1">{product.name}</h3>
              <p className="text-sm text-gray-600 mb-4 flex-grow">{product.description}</p>
              <div className="flex items-center justify-between mt-auto">
                <span className="text-lg font-bold text-tatriz-green">PKR {product.price.toLocaleString()}</span>
                <button 
                  onClick={() => addToCart(product)}
                  className="bg-tatriz-gold text-tatriz-green p-2 rounded-full hover:bg-yellow-500 transition"
                  title="Add to Cart"
                >
                  <ShoppingBag className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {filteredProducts.length === 0 && (
        <div className="text-center py-20 text-gray-500">
          <p>No products found in this category.</p>
        </div>
      )}
    </div>
  );
};

export default Shop;