import React from 'react';
import { Link } from 'react-router-dom';
import { Trash2, Plus, Minus, ArrowRight } from 'lucide-react';
import { useCart } from '../context/CartContext';

const Cart: React.FC = () => {
  const { cart, removeFromCart, updateQuantity, cartTotal, cartCount } = useCart();

  if (cartCount === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-24 text-center">
        <h2 className="text-3xl font-serif text-gray-800 mb-4">Your cart is empty</h2>
        <p className="text-gray-600 mb-8">Looks like you haven't found your perfect embroidery yet.</p>
        <Link to="/shop" className="inline-block bg-tatriz-green text-white px-8 py-3 rounded hover:bg-green-900 transition">
          Continue Shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <h1 className="font-serif text-4xl font-bold text-tatriz-green mb-8">Shopping Cart</h1>
      
      <div className="flex flex-col lg:flex-row gap-12">
        <div className="flex-grow space-y-6">
          {cart.map((item) => (
            <div key={item.id} className="bg-white p-4 rounded-lg shadow-sm flex gap-4 items-center">
              <img src={item.image} alt={item.name} className="w-24 h-24 object-cover rounded bg-gray-200" />
              
              <div className="flex-grow">
                <h3 className="font-serif text-lg font-bold text-gray-800">{item.name}</h3>
                <p className="text-sm text-gray-500 capitalize">{item.category}</p>
                <div className="text-tatriz-green font-bold mt-1">PKR {item.price.toLocaleString()}</div>
              </div>

              <div className="flex items-center gap-3">
                <button 
                  onClick={() => updateQuantity(item.id, item.quantity - 1)}
                  className="p-1 rounded-full hover:bg-gray-100 text-gray-600"
                  disabled={item.quantity <= 1}
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-8 text-center font-medium">{item.quantity}</span>
                <button 
                  onClick={() => updateQuantity(item.id, item.quantity + 1)}
                  className="p-1 rounded-full hover:bg-gray-100 text-gray-600"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>

              <button 
                onClick={() => removeFromCart(item.id)}
                className="text-red-500 hover:text-red-700 ml-4"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          ))}
        </div>

        <div className="lg:w-96">
          <div className="bg-white p-6 rounded-lg shadow-lg sticky top-24">
            <h3 className="font-serif text-xl font-bold mb-4 border-b pb-2">Order Summary</h3>
            
            <div className="space-y-2 mb-4">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal</span>
                <span>PKR {cartTotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Shipping</span>
                <span>Free</span>
              </div>
            </div>
            
            <div className="flex justify-between font-bold text-xl text-gray-900 border-t pt-4 mb-6">
              <span>Total</span>
              <span>PKR {cartTotal.toLocaleString()}</span>
            </div>

            <Link to="/checkout" className="w-full block text-center bg-tatriz-green text-white py-3 rounded hover:bg-green-900 transition font-bold">
              Proceed to Checkout
            </Link>
             <p className="text-xs text-gray-500 text-center mt-4">
               Secure Checkout powered by Tatriz
             </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;