import React from 'react';
import { Instagram, Facebook, Mail, Phone } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-tatriz-green text-white mt-auto">
      <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="font-serif text-2xl font-bold mb-4">Tatriz by Zara</h3>
            <p className="text-gray-200 text-sm leading-relaxed">
              Bringing the heritage of Pakistani hand embroidery to the world. 
              Each stitch tells a story of tradition, love, and craftsmanship.
            </p>
          </div>
          <div>
            <h4 className="font-serif text-xl font-semibold mb-4 text-tatriz-gold">Customer Care</h4>
            <ul className="space-y-2 text-sm text-gray-200">
              <li><a href="#" className="hover:text-tatriz-gold">Shipping & Returns</a></li>
              <li><a href="#" className="hover:text-tatriz-gold">Size Guide</a></li>
              <li><a href="#" className="hover:text-tatriz-gold">Track Order</a></li>
              <li><a href="#" className="hover:text-tatriz-gold">Custom Orders FAQ</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-serif text-xl font-semibold mb-4 text-tatriz-gold">Connect</h4>
            <div className="flex space-x-4 mb-4">
              <a href="#" className="hover:text-tatriz-gold transition"><Instagram className="w-6 h-6" /></a>
              <a href="#" className="hover:text-tatriz-gold transition"><Facebook className="w-6 h-6" /></a>
            </div>
            <div className="space-y-2 text-sm text-gray-200">
              <p className="flex items-center gap-2"><Mail className="w-4 h-4" /> zara@tatriz.pk</p>
              <p className="flex items-center gap-2"><Phone className="w-4 h-4" /> +92 300 1234567</p>
            </div>
          </div>
        </div>
        <div className="border-t border-green-800 mt-8 pt-8 text-center text-sm text-gray-300">
          <p>&copy; {new Date().getFullYear()} Tatriz by Zara. Made in Pakistan.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;