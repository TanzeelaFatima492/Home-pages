import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import Header from "./components/Header";
import Hero from "./components/Hero";
import Collection from "./components/Collection";
import Craftsmanship from "./components/Craftsmanship";
import AtelierStudio from "./components/AtelierStudio";
import Testimonials from "./components/Testimonials";
import ServiceModal from "./components/ServiceModal";
import Footer from "./components/Footer";
import MouseGlow from "./components/MouseGlow";
import FloatingParticles from "./components/FloatingParticles";
import { Sparkles } from "lucide-react";

export default function App() {
  const [isInitialLoading, setIsInitialLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("collection");
  const [isAdvisoryOpen, setIsAdvisoryOpen] = useState(false);
  const [preSelectedCakeName, setPreSelectedCakeName] = useState("");

  // Simulated high-end pre-loader for an interactive, immersive landing experience
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsInitialLoading(false);
    }, 2800);
    return () => clearTimeout(timer);
  }, []);

  const openAdvisoryWithCake = (cakeName: string) => {
    setPreSelectedCakeName(cakeName);
    setIsAdvisoryOpen(true);
  };

  const openAdvisoryGeneric = () => {
    setPreSelectedCakeName("Custom Sculpted Blueprints");
    setIsAdvisoryOpen(true);
  };

  return (
    <div className="relative min-h-screen bg-lux-cream selection:bg-lux-rosegold selection:text-white overflow-hidden font-sans">
      
      {/* Absolute high-end mouse glow tracing */}
      <MouseGlow />

      <AnimatePresence mode="wait">
        {isInitialLoading ? (
          /* INTRO AWWWARDS-GRADE LOADER SECTION */
          <motion.div
            key="preloader-portal"
            id="brand-curtain-loader"
            className="fixed inset-0 z-100 flex flex-col items-center justify-center bg-lux-charcoal"
            exit={{
              y: "-100%",
              transition: { duration: 1.1, ease: [0.85, 0, 0.15, 1] }
            }}
          >
            {/* Fine drifting particles in loader */}
            <FloatingParticles />

            <div className="space-y-6 text-center px-6">
              {/* Brand icon reveal */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 1, ease: "easeOut" }}
                className="mx-auto flex h-14 w-14 items-center justify-center rounded-full border border-lux-gold/20"
              >
                <Sparkles className="h-5 w-5 text-lux-gold animate-pulse" />
              </motion.div>

              {/* Title staggered spelling reveal */}
              <div className="space-y-2">
                <motion.h2
                  className="font-display text-2xl tracking-[0.3em] text-lux-cream sm:text-3xl uppercase font-semibold"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.4, duration: 1.2 }}
                >
                  MAISON DE PÂTISSERIE
                </motion.h2>

                <motion.span
                  className="block font-mono text-[9px] tracking-[0.4em] text-lux-gold uppercase"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.9, duration: 0.8 }}
                >
                  Le Génie Confectionneur Parisien
                </motion.span>
              </div>

              {/* Minimal Luxury Progress Bar */}
              <div className="relative mx-auto h-[1px] w-48 overflow-hidden bg-lux-cream/10">
                <motion.div
                  className="absolute left-0 top-0 h-full bg-lux-gold"
                  initial={{ width: 0 }}
                  animate={{ width: "100%" }}
                  transition={{ duration: 2.2, ease: "easeInOut" }}
                />
              </div>
            </div>
          </motion.div>
        ) : (
          /* ACTUAL COMPLETED LUXURY PRESENTATION STAGE */
          <motion.div
            key="main-atelier-gallery"
            initial={{ opacity: 0, scale: 1.01 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.2, ease: "easeOut" }}
            className="flex flex-col min-h-screen"
          >
            {/* Navigation Header */}
            <Header
              onBookClick={openAdvisoryGeneric}
              activeTab={activeTab}
              setActiveTab={setActiveTab}
            />

            {/* Cinematic Hero */}
            <Hero
              onDiscoverClick={() => {
                document.getElementById("collection")?.scrollIntoView({ behavior: "smooth" });
              }}
              onConsultClick={openAdvisoryGeneric}
            />

            {/* Collection Interactive Gallery */}
            <Collection onBespokeClick={openAdvisoryWithCake} />

            {/* Artisan Craftsmanship & Savoir-faire */}
            <Craftsmanship />

            {/* Atmospheric Cinema Section */}
            <AtelierStudio />

            {/* Editorial Testimonials Critiques Carousel */}
            <Testimonials />

            {/* Detailed Brand Advisory Reservation Form */}
            <ServiceModal
              isOpen={isAdvisoryOpen}
              onClose={() => setIsAdvisoryOpen(false)}
              preSelectedCake={preSelectedCakeName}
            />

            {/* Luxury Editorial Footer */}
            <Footer />
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
