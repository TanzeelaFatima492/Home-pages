import React, { useState } from "react";
import { Sparkles, Globe, ShieldCheck, Mail, Send, Check } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function Footer() {
  const [subEmail, setSubEmail] = useState("");
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subEmail) return;

    setIsSubscribed(true);
    setTimeout(() => {
      setSubEmail("");
    }, 2000);
  };

  return (
    <footer id="footer-lux" className="relative border-t border-lux-rosegold/15 bg-lux-charcoal pt-24 pb-12 px-6 md:px-12 text-lux-cream overflow-hidden">
      
      {/* Background soft ambient glowing orb */}
      <div className="absolute bottom-[-100px] right-[-100px] w-96 h-96 bg-lux-gold/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="relative mx-auto max-w-7xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 pb-16">
          
          {/* Main Brand Column / Column Span 5 */}
          <div className="lg:col-span-5 space-y-6 text-left">
            <div className="flex items-center gap-2">
              <span className="font-display text-lg tracking-[0.2em] font-semibold text-lux-cream uppercase">
                Maison de Pâtisserie
              </span>
              <Sparkles className="h-4 w-4 text-lux-gold animate-pulse" />
            </div>
            
            <p className="font-sans text-xs font-light leading-relaxed text-lux-cream/60 max-w-sm">
              Reconstituting classical flour and cocoa as majestic geometric monuments. Sculpting taste with the precision of high-fashion and structural physics.
            </p>

            {/* Newsletter Sign up */}
            <div className="space-y-3 pt-4">
              <h5 className="font-mono text-[9px] tracking-[0.3em] text-lux-gold uppercase font-bold">
                Join L'Archive Collective
              </h5>
              <p className="font-sans text-[10px] text-lux-cream/50">
                Receive private invitations to seasonal tasting exhibitions and new portfolio previews.
              </p>

              <form onSubmit={handleSubscribe} className="relative flex max-w-md items-center mt-3">
                <input
                  type="email"
                  required
                  value={subEmail}
                  onChange={(e) => setSubEmail(e.target.value)}
                  placeholder="patron@sovereign.com"
                  className="w-full rounded-full border border-lux-cream/10 bg-lux-cream/5 px-6 py-3.5 font-sans text-xs text-lux-cream placeholder-lux-cream/30 focus:border-lux-rosegold focus:outline-hidden"
                />
                
                <button
                  type="submit"
                  className="absolute right-1.5 flex h-10 w-24 items-center justify-center rounded-full bg-lux-rosegold font-mono text-[9px] font-semibold tracking-wider text-white uppercase hover:bg-lux-gold hover:text-lux-charcoal transition-all duration-300 pointer-events-auto"
                >
                  {isSubscribed ? <Check className="h-3.5 w-3.5" /> : "Request"}
                </button>
              </form>
              <AnimatePresence>
                {isSubscribed && (
                  <motion.span
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="block font-mono text-[8px] text-emerald-400 uppercase tracking-widest pl-2"
                  >
                    ✦ Private list credentials sent.
                  </motion.span>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Links grid col span 7 */}
          <div className="lg:col-span-7 grid grid-cols-2 md:grid-cols-3 gap-10 text-left">
            {/* Salons Locale Column */}
            <div className="space-y-4">
              <h5 className="font-mono text-[9px] tracking-[0.25em] text-lux-gold uppercase font-bold">
                Les Salons
              </h5>
              <ul className="space-y-3 font-sans text-xs font-light text-lux-cream/65">
                <li className="hover:text-lux-pink-200 transition-colors">
                  <span className="block font-semibold text-lux-cream">Paris Atelier</span>
                  <span className="text-[11px] opacity-80">Rue d’Alger, 1er Arrondissement</span>
                </li>
                <li className="hover:text-lux-pink-200 transition-colors">
                  <span className="block font-semibold text-lux-cream">Milan Gilda</span>
                  <span className="text-[11px] opacity-80">Via Della Spiga, Quadrilatero</span>
                </li>
                <li className="hover:text-lux-pink-200 transition-colors">
                  <span className="block font-semibold text-lux-cream">New York Desk</span>
                  <span className="text-[11px] opacity-80">Mercer Street, Soho District</span>
                </li>
              </ul>
            </div>

            {/* Services/Elite Projects */}
            <div className="space-y-4">
              <h5 className="font-mono text-[9px] tracking-[0.25em] text-lux-gold uppercase font-bold">
                Sovereign Service
              </h5>
              <ul className="space-y-3 font-sans text-xs font-light text-lux-cream/65">
                <li><a href="#collection" className="hover:text-lux-pink-200 transition-colors">Couture Wedding Commissions</a></li>
                <li><a href="#collection" className="hover:text-lux-pink-200 transition-colors">Galas & Fine Installations</a></li>
                <li><a href="#collection" className="hover:text-lux-pink-200 transition-colors">Cryogenic Jet Cargo Logistics</a></li>
                <li><a href="#collection" className="hover:text-lux-pink-200 transition-colors">Private Chef Residency</a></li>
                <li><a href="#craftsmanship" className="hover:text-lux-pink-200 transition-colors">Artisanship Research Lab</a></li>
              </ul>
            </div>

            {/* Legal Status details */}
            <div className="space-y-4 col-span-2 md:col-span-1">
              <h5 className="font-mono text-[9px] tracking-[0.25em] text-lux-gold uppercase font-bold">
                Assurance
              </h5>
              <div className="space-y-4">
                <div className="flex items-start gap-2.5">
                  <ShieldCheck className="h-4 w-4 text-lux-gold shrink-0 mt-0.5" />
                  <span className="font-sans text-[11px] font-light leading-relaxed text-lux-cream/60">
                    All gold gilding is certified 100% biologically edible and hypoallergenic.
                  </span>
                </div>
                <div className="flex items-start gap-2.5">
                  <Globe className="h-4 w-4 text-lux-gold shrink-0 mt-0.5" />
                  <span className="font-sans text-[11px] font-light leading-relaxed text-lux-cream/60">
                    Logistical routes utilize custom cold-vault aircraft chambers to protect sculptures.
                  </span>
                </div>
              </div>
            </div>

          </div>

        </div>

        {/* Legal and credits disclaimer line */}
        <div className="border-t border-lux-cream/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-lux-cream/40 font-mono text-[9px] tracking-widest uppercase">
          <div className="flex flex-wrap items-center gap-6 justify-center md:justify-start">
            <span>© 2026 Maison de Pâtisserie SA.</span>
            <span>All Intellectual Masterpieces Protected</span>
          </div>

          <div className="flex gap-6">
            <span className="hover:text-lux-gold cursor-pointer transition-colors">Cookie Ledger</span>
            <span className="hover:text-lux-gold cursor-pointer transition-colors">Access Policy</span>
            <span className="hover:text-lux-gold cursor-pointer transition-colors">Credits</span>
          </div>
        </div>
      </div>

    </footer>
  );
}
