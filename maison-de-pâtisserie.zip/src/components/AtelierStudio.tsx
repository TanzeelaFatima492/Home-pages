import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Play, Volume2, VolumeX, Eye, Sparkles, X, Clapperboard, Film } from "lucide-react";

export default function AtelierStudio() {
  const [isPlayingFilm, setIsPlayingFilm] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [activeScene, setActiveScene] = useState(0);

  // High fashion editorial screenplay captions to simulate a premium cinematic atmosphere
  const cinematicScenes = [
    {
      title: "I. L’Inspiration",
      desc: "In Paris’s historic 1er arrondissement, botanical curves write the initial blueprint.",
      time: "0:00 — 0:45"
    },
    {
      title: "II. La Tempérance",
      desc: "Slow churning single-estate ganache in heavy copper basins, matching strict room moisture controls.",
      time: "0:45 — 1:30"
    },
    {
      title: "III. La Dorure",
      desc: "Master hands apply pure 24k gold, catching early morning Seine reflection across mirrors.",
      time: "1:30 — 2:15"
    }
  ];

  return (
    <section id="atelier" className="relative h-[80vh] min-h-[500px] w-full overflow-hidden bg-lux-cream flex items-center justify-center">
      
      {/* Editorial Panning Background Image simulating a cinema roll */}
      <div className="absolute inset-0">
        <motion.div
          animate={{
            scale: [1.02, 1.06, 1.02],
            x: [-15, 15, -15],
          }}
          transition={{
            duration: 25,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="h-full w-full"
        >
          {/* Using unsplash with high contrast luxury kitchen filters */}
          <img
            src="https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&q=80&w=1920"
            alt="Maison de Pâtisserie Experimental Atelier Studio"
            className="h-full w-full object-cover brightness-[0.45] saturate-[0.8]"
            referrerPolicy="no-referrer"
          />
        </motion.div>
        
        {/* Cinematic horizontal dark bars */}
        <div className="absolute inset-x-0 top-0 h-16 bg-lux-charcoal/80 z-2 border-b border-lux-gold/15 flex items-center justify-between px-10">
          <span className="font-mono text-[9px] tracking-[0.3em] text-lux-gold uppercase">
            DOCUMENTARY FILM PROJECT
          </span>
          <span className="font-mono text-[9px] tracking-widest text-lux-cream/60">
            PRODUCED AT THE PARIS LAB
          </span>
        </div>
        
        <div className="absolute inset-x-0 bottom-0 h-16 bg-lux-charcoal/80 z-2 border-t border-lux-gold/15 flex items-center justify-between px-10">
          <span className="font-mono text-[9px] tracking-widest text-lux-cream/50">
            Maison de Pâtisserie © 2026
          </span>
          <span className="font-mono text-[9px] tracking-[0.2em] text-lux-gold">
            RATIO 2.35:1 CINEMATIC CONTRAST
          </span>
        </div>

        {/* Ambient Dark Blending to merge sections */}
        <div className="absolute inset-0 bg-radial-to-c from-transparent via-transparent to-lux-charcoal/40 z-1" />
      </div>

      {/* Center Atmospheric Interaction Panel */}
      <div className="relative z-10 text-center max-w-xl px-6 space-y-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="mx-auto h-24 w-24 rounded-full border border-lux-gold/30 bg-lux-charcoal/50 backdrop-blur-md flex items-center justify-center cursor-pointer group shadow-2xl"
          onClick={() => setIsPlayingFilm(true)}
          whileHover={{ scale: 1.08, borderColor: "rgba(183, 110, 121, 0.8)", backgroundColor: "rgba(183, 110, 121, 0.15)" }}
          whileTap={{ scale: 0.96 }}
        >
          <Play className="h-6 w-6 text-lux-cream transition-colors group-hover:text-lux-gold translate-x-0.5" />
        </motion.div>

        <div className="space-y-3">
          <span className="font-mono text-[10px] tracking-[0.35em] text-lux-gold uppercase block">
            Inside L'Atelier
          </span>
          <h3 className="font-display text-3xl font-light text-lux-cream sm:text-4xl">
            Watch the <span className="font-serif italic text-lux-pink-100 font-bold">Genesis</span> of Sweet Art
          </h3>
          <p className="font-sans text-[11px] font-light leading-relaxed text-lux-cream/70 max-w-md mx-auto">
            A poetic visual documentary exploration of our Paris studio. Experience the absolute serenity, thermal discipline, and artistry required to construct high-fashion cakes.
          </p>
        </div>
      </div>

      {/* Cinematic Full Screen Overlay Theater */}
      <AnimatePresence>
        {isPlayingFilm && (
          <motion.div
            id="cinematic-theater-portal"
            className="fixed inset-0 z-50 bg-lux-charcoal flex flex-col justify-between p-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {/* Theater Top Nav */}
            <div className="flex justify-between items-center z-10 border-b border-lux-cream/10 pb-4">
              <div className="flex items-center gap-3">
                <Film className="h-4 w-4 text-lux-gold" />
                <span className="font-mono text-[10px] tracking-widest text-[#faf6f0] uppercase">
                  Maison de Pâtisserie: The Cinema Series
                </span>
              </div>
              
              <button
                onClick={() => setIsPlayingFilm(false)}
                className="flex h-9 w-9 items-center justify-center rounded-full border border-lux-cream/20 bg-lux-charcoal/60 text-[#faf6f0] hover:bg-lux-rosegold hover:text-white transition-all duration-300"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Immersive Screenspace Player */}
            <div className="relative flex-1 flex flex-col items-center justify-center my-6 rounded-2xl overflow-hidden border border-lux-gold/15 bg-black">
              {/* Loop Video Placeholder / Luxury Graphics */}
              <div className="absolute inset-0">
                <img
                  src="https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&q=80&w=1920"
                  alt="Atmospheric baking studio"
                  className="h-full w-full object-cover brightness-[0.3] blur-xs"
                />
              </div>

              {/* Staggered Screenplay Caption Block */}
              <div className="relative z-10 text-center max-w-2xl p-8 space-y-10">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeScene}
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -15 }}
                    transition={{ duration: 0.6 }}
                    className="space-y-5"
                  >
                    <span className="font-mono text-[9px] tracking-[0.4em] text-lux-gold uppercase block">
                      {cinematicScenes[activeScene].title} — {cinematicScenes[activeScene].time}
                    </span>
                    <h4 className="font-display text-2xl font-light text-lux-cream leading-relaxed leading-relaxed">
                      "{cinematicScenes[activeScene].desc}"
                    </h4>
                  </motion.div>
                </AnimatePresence>

                {/* Subtitle Scene Navigator tabs */}
                <div className="flex justify-center items-center gap-3">
                  {cinematicScenes.map((scene, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveScene(idx)}
                      className={`h-2.5 w-16 rounded-full transition-all duration-300 ${
                        idx === activeScene ? "bg-lux-gold w-24" : "bg-lux-cream/20 hover:bg-lux-cream/40"
                      }`}
                    />
                  ))}
                </div>
              </div>

              {/* Live soundscape simulation button */}
              <div className="absolute bottom-6 right-6">
                <button
                  onClick={() => setIsMuted(!isMuted)}
                  className="flex items-center gap-2 rounded-full border border-lux-cream/20 bg-lux-charcoal/50 px-4 py-2 font-mono text-[9px] text-[#faf6f0] uppercase hover:bg-lux-cream hover:text-lux-charcoal transition-all duration-300"
                >
                  {isMuted ? (
                    <>
                      <VolumeX className="h-3.5 w-3.5" />
                      <span>Sound Off</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="h-3.5 w-3.5 text-lux-gold animate-bounce" />
                      <span>Sound On (Ambient Wind & Violin)</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Theatre Footer */}
            <div className="flex justify-between items-center z-10 border-t border-lux-cream/10 pt-4 text-lux-cream/50 font-mono text-[9px]">
              <span>VIRTUAL PARIS EXPERIENCE v2.4</span>
              <span>PRESS SPACE TO PLAY / PAUSE</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

    </section>
  );
}
