import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Sparkles, Menu, X, Compass, Clock, Globe } from "lucide-react";

interface HeaderProps {
  onBookClick: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function Header({ onBookClick, activeTab, setActiveTab }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: "collection", label: "La Collection" },
    { id: "atelier", label: "L'Atelier" },
    { id: "craftsmanship", label: "Savoir-faire" },
    { id: "testimonials", label: "Critique" }
  ];

  const handleNavClick = (id: string) => {
    setActiveTab(id);
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <>
      <motion.header
        id="lux-branding-nav"
        className="fixed top-0 left-0 right-0 z-50 border-b border-lux-rosegold/10 bg-lux-cream/60 backdrop-blur-xl transition-colors duration-300"
        initial={{ y: -60, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
      >
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 md:px-10">
          
          {/* Logo Brand Title */}
          <button 
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="group flex flex-col items-start justify-center text-left focus:outline-hidden"
          >
            <div className="flex items-center gap-2">
              <span className="font-display text-sm font-semibold tracking-[0.25em] text-lux-charcoal lg:text-base group-hover:text-lux-rosegold transition-colors duration-300 uppercase">
                Maison de Pâtisserie
              </span>
              <motion.span 
                animate={{ rotate: 360 }}
                transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
              >
                <Sparkles className="h-3.5 w-3.5 text-lux-gold" />
              </motion.span>
            </div>
            <span className="font-mono text-[9px] tracking-[0.35em] text-lux-rosegold/80 uppercase mt-0.5">
              Haute Confectionery · Paris
            </span>
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden items-center gap-10 md:flex">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className="group relative py-1 font-sans text-xs font-medium tracking-[0.2em] text-lux-charcoal/80 uppercase hover:text-lux-charcoal transition-colors duration-200"
              >
                {item.label}
                <span className="absolute bottom-0 left-0 h-[1.5px] w-0 bg-lux-rosegold transition-all duration-300 group-hover:w-full" />
                {activeTab === item.id && (
                  <motion.span
                    layoutId="activeIndicator"
                    className="absolute bottom-0 left-0 h-[1.5px] w-full bg-lux-rosegold"
                    transition={{ type: "spring", stiffness: 350, damping: 35 }}
                  />
                )}
              </button>
            ))}
          </nav>

          {/* CTA & Menu Toggle */}
          <div className="flex items-center gap-4">
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.98 }}
              onClick={onBookClick}
              className="group hidden items-center gap-2 rounded-full border border-lux-rosegold/30 bg-radial from-lux-cream to-lux-cham/30 px-5 py-2.5 font-mono text-[10px] font-semibold tracking-[0.18em] text-lux-charcoal uppercase transition-all duration-300 hover:border-lux-rosegold hover:bg-lux-rosegold hover:text-white md:flex"
            >
              <span>Privé Advisory</span>
              <motion.span
                animate={{ x: [0, 3, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                →
              </motion.span>
            </motion.button>

            {/* Mobile Hamburger Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="flex h-10 w-10 items-center justify-center rounded-full border border-lux-rosegold/10 text-lux-charcoal focus:outline-hidden md:hidden hover:bg-lux-rosegold/5"
            >
              {mobileMenuOpen ? <X className="h-4 w-4 text-lux-charcoal" /> : <Menu className="h-4 w-4" />}
            </button>
          </div>
        </div>
      </motion.header>

      {/* Mobile Drawer Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            id="mobile-drawer-portal"
            className="fixed inset-0 z-45 bg-lux-charcoal/90 backdrop-blur-2xl"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
          >
            <div className="flex h-full flex-col justify-between p-8 pt-28">
              <div className="space-y-8">
                <span className="font-mono text-[10px] tracking-[0.4em] text-lux-rosegold uppercase">
                  Explore L'Atelier
                </span>
                <nav className="flex flex-col gap-6">
                  {navItems.map((item, index) => (
                    <motion.button
                      key={item.id}
                      initial={{ x: -20, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                      transition={{ delay: index * 0.1, duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
                      onClick={() => handleNavClick(item.id)}
                      className="text-left font-display text-3xl font-light tracking-wide text-lux-cream hover:text-lux-rosegold transition-colors duration-200"
                    >
                      {item.label}
                    </motion.button>
                  ))}
                </nav>
              </div>

              <div className="space-y-6 border-t border-lux-cream/10 pt-8 text-lux-cream/60">
                <div className="flex items-center gap-3 font-mono text-[10px]">
                  <Globe className="h-4 w-4 text-lux-gold" />
                  <span>Available Internationally (Private Jet Logistics)</span>
                </div>
                <div className="flex items-center gap-3 font-mono text-[10px]">
                  <Clock className="h-4 w-4 text-lux-gold" />
                  <span>Advisory Booking Hours: 9:00 — 19:00 CET</span>
                </div>
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onBookClick();
                  }}
                  className="w-full rounded-full border border-lux-rosegold/50 bg-lux-rosegold px-6 py-4 text-center font-mono text-xs font-semibold tracking-widest text-white uppercase hover:bg-transparent hover:text-lux-rosegold transition-all duration-300"
                >
                  Request Consultation
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
