import { useEffect } from "react";
import { motion, useMotionValue, useSpring } from "motion/react";

export default function MouseGlow() {
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  // Smooth springs for high-end luxury feel
  const springX = useSpring(mouseX, { stiffness: 60, damping: 25, mass: 0.8 });
  const springY = useSpring(mouseY, { stiffness: 60, damping: 25, mass: 0.8 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mouseX.set(e.clientX - 175); // offsets for glow radius (350px/2)
      mouseY.set(e.clientY - 175);
    };

    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, [mouseX, mouseY]);

  return (
    <motion.div
      id="mouse-halo-glow"
      className="pointer-events-none fixed top-0 left-0 z-10 h-[350px] w-[350px] rounded-full bg-radial from-lux-rosegold/12 via-lux-gold/6 to-transparent blur-3xl"
      style={{
        x: springX,
        y: springY,
      }}
    />
  );
}
