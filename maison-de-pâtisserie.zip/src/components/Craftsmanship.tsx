import { useEffect, useState, useRef } from "react";
import { motion, useInView } from "motion/react";
import { STATS } from "../data";
import { Sparkles, Milestone, Award, CircleDot } from "lucide-react";

export default function Craftsmanship() {
  return (
    <section id="craftsmanship" className="relative py-28 px-6 md:px-12 bg-lux-charcoal text-lux-cream overflow-hidden">
      
      {/* Background ambient dark gold radial halo */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-lux-gold/5 blur-[120px] pointer-events-none" />

      <div className="relative mx-auto max-w-7xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
          
          {/* Left Column: Savoir-faire story details */}
          <div className="lg:col-span-5 space-y-10 text-left">
            <div className="space-y-4">
              <span className="font-mono text-[10px] tracking-[0.4em] text-lux-gold uppercase block">
                Savoir-faire
              </span>
              <h2 className="font-display text-4xl font-light leading-tight sm:text-5xl">
                Couture is an <br />
                <span className="font-serif italic font-bold text-lux-pink-200">Act of Valour</span>
              </h2>
              <div className="h-[1px] w-12 bg-lux-pink-100/30 mt-3" />
            </div>

            <p className="font-sans text-xs font-light leading-relaxed text-lux-cream/70">
              Unlike industrial baking houses, Maison de Pâtisserie maintains a research-driven culinary laboratory. Every cake is initiated on heavy draft paper as architectural blueprints, analyzing volumetric thresholds, structural loads, and humidity resilience. We balance flavor, moisture, and density with physical gravity to implement feats that defy classical confectionery geometry.
            </p>

            {/* Three Pillar Steps */}
            <div className="space-y-6">
              {[
                {
                  title: "Architectural Blueprint Draw",
                  desc: "Drafting the cake's silhouette, detailing support columns and edible structural spans."
                },
                {
                  title: "Satin Ganache Texturing",
                  desc: "Drying and polishing dozens of structural layers until they obtain a perfectly smooth silk matte finish."
                },
                {
                  title: "Gold Architectural Gilding",
                  desc: "Precision leafing with pure, certified 24-carat gold, applied by hand using fine custom sable brushes."
                }
              ].map((step, index) => (
                <div key={index} className="flex gap-4 group">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-lux-gold/20 bg-lux-charcoal text-lux-gold group-hover:bg-lux-gold group-hover:text-lux-charcoal transition-all duration-300">
                    <span className="font-mono text-xs font-medium">0{index + 1}</span>
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-display text-base font-light text-lux-cream group-hover:text-lux-pink-200 transition-colors">
                      {step.title}
                    </h4>
                    <p className="font-sans text-[11px] font-light text-lux-cream/60">
                      {step.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column: Beautiful generated studio photography and tickers */}
          <div className="lg:col-span-7 space-y-12">
            
            {/* Visual Frame */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.98 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 1 }}
              className="relative aspect-16/9 overflow-hidden rounded-3xl border border-lux-gold/20 shadow-2xl p-2 bg-linear-to-tr from-lux-gold/10 to-transparent"
            >
              <div className="absolute inset-x-0 top-0 h-4 bg-linear-to-b from-lux-gold/10 to-transparent z-1" />
              <img
                src="/src/assets/images/artisan_baking_studio_1780230975308.png"
                alt="Pastry Chef applying gold leaf with tweezers"
                className="h-full w-full object-cover rounded-2xl brightness-110 saturate-[0.95]"
                referrerPolicy="no-referrer"
              />
              {/* Gold dust particle overlay to increase epic design scale */}
              <div className="absolute inset-0 bg-radial-to-t from-lux-charcoal via-transparent to-transparent opacity-80" />
              
              <div className="absolute bottom-6 left-6 right-6 flex justify-between items-center bg-lux-charcoal/80 border border-lux-gold/20 rounded-full py-3 px-6 backdrop-blur-md">
                <div className="flex items-center gap-2.5">
                  <span className="h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
                  <span className="font-mono text-[9px] text-lux-cream tracking-widest uppercase">Live from Paris Atelier</span>
                </div>
                <span className="font-mono text-[9px] text-lux-gold uppercase">Gilding Stage</span>
              </div>
            </motion.div>

            {/* Custom Interactive Counters */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {STATS.map((stat, idx) => (
                <CounterBox key={idx} stat={stat} index={idx} />
              ))}
            </div>

          </div>

        </div>
      </div>

    </section>
  );
}

/* Individual Counter Box Component with Tick-up Math */
function CounterBox({ stat, index }: { stat: typeof STATS[0]; index: number; key?: any }) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  useEffect(() => {
    if (isInView) {
      let start = 0;
      const end = stat.value;
      const duration = 2000; // 2 seconds tick time
      const incrementTime = Math.max(Math.floor(duration / end), 20);
      const timer = setInterval(() => {
        start += 1;
        if (start >= end) {
          setCount(end);
          clearInterval(timer);
        } else {
          setCount(start);
        }
      }, incrementTime);

      return () => clearInterval(timer);
    }
  }, [isInView, stat.value]);

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
      className="rounded-2xl border border-lux-gold/10 bg-lux-charcoal/40 p-5 text-center backdrop-blur-md flex flex-col justify-center items-center shadow-inner"
    >
      <span className="font-mono text-2xl font-light text-lux-gold tracking-tighter md:text-3xl lg:text-4xl">
        {count}
        <span className="text-lux-pink-200">{stat.suffix}</span>
      </span>
      <span className="font-sans text-[10px] tracking-wide text-lux-cream/60 mt-2 block balance uppercase">
        {stat.label}
      </span>
    </motion.div>
  );
}
