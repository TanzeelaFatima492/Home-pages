import { motion, useScroll, useTransform } from "motion/react";
import { ArrowDown, Sparkles, Award, Star } from "lucide-react";

interface HeroProps {
  onDiscoverClick: () => void;
  onConsultClick: () => void;
}

export default function Hero({ onDiscoverClick, onConsultClick }: HeroProps) {
  const { scrollY } = useScroll();
  
  // High-performance hardware-accelerated parallax transforms
  const yImage = useTransform(scrollY, [0, 800], [0, 160]);
  const scaleImage = useTransform(scrollY, [0, 800], [1, 1.12]);
  const opacityText = useTransform(scrollY, [0, 400], [1, 0]);

  return (
    <section id="hero-cinematic-stage" className="relative flex min-h-screen w-full items-center justify-center overflow-hidden bg-[#faf6f0] px-6 pt-20">
      
      {/* Cinematic Parallax Background Image */}
      <div className="absolute inset-0 z-0 h-full w-full overflow-hidden">
        <motion.div 
          className="h-full w-full"
          style={{ y: yImage, scale: scaleImage }}
        >
          <img
            src="/src/assets/images/luxury_hero_cake_1780230898311.png"
            alt="Maison de Pâtisserie Golden Grand Tier Cake"
            className="h-full w-full object-cover brightness-[0.93] saturation-[1.05]"
            referrerPolicy="no-referrer"
          />
        </motion.div>
        
        {/* Absolute Gradients for Luxury Blending */}
        <div className="absolute inset-0 bg-linear-to-b from-[#faf6f0]/40 via-transparent to-[#faf6f0] z-2" />
        <div className="absolute inset-0 bg-radial-to-c from-transparent via-transparent to-[#faf6f0]/30 z-2" />
      </div>

      {/* Hero Content Overlay */}
      <div className="relative z-10 mx-auto grid w-full max-w-7xl grid-cols-1 items-end pb-12 pt-16 md:grid-cols-2 md:pb-24">
        
        {/* Brand Statement / Left Column */}
        <motion.div 
          style={{ opacity: opacityText }}
          className="flex flex-col items-start gap-6 text-left"
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1.2, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
        >
          {/* Micro Ribbon Badge */}
          <div className="inline-flex items-center gap-2 rounded-full border border-lux-rosegold/30 bg-[#faf6f0]/90 backdrop-blur-md px-3.5 py-1.5 font-mono text-[9px] font-semibold tracking-[0.25em] text-lux-charcoal uppercase shadow-xs">
            <Sparkles className="h-3 w-3 text-lux-gold animate-pulse" />
            <span>Grand Opening · May 2026</span>
          </div>

          {/* Majestic Hero Typography */}
          <div className="space-y-3">
            <h1 className="font-display text-5xl font-light leading-[1.05] text-lux-charcoal sm:text-6xl md:text-7xl lg:text-8xl">
              Sculpted <br />
              <span className="font-serif italic text-lux-rosegold font-bold">Confections</span>
            </h1>
            <p className="max-w-md font-sans text-sm font-light tracking-wide text-lux-charcoal/80 sm:text-base">
              A luxury pastry house where botanical design, classical architecture, and grand crus chocolate synthesize into edible museum-level sculpture. 
            </p>
          </div>

          {/* Interactive CTAs */}
          <div className="flex flex-wrap items-center gap-4 pt-4 w-full sm:w-auto">
            <motion.button
              whileHover={{ y: -3, scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={onDiscoverClick}
              className="relative overflow-hidden rounded-full border border-lux-rosegold bg-linear-to-r from-lux-rosegold to-lux-rosegold/95 px-8 py-4 font-mono text-[10px] font-semibold tracking-[0.25em] text-white uppercase shadow-lg shadow-lux-rosegold/20 transition-all duration-300 hover:shadow-lux-rosegold/40 w-full sm:w-auto"
            >
              Le Collection
            </motion.button>

            <motion.button
              whileHover={{ y: -3, bg: "rgba(250, 246, 240, 1)" }}
              whileTap={{ scale: 0.98 }}
              onClick={onConsultClick}
              className="rounded-full border border-lux-charcoal/20 bg-[#faf6f0]/80 backdrop-blur-md px-8 py-4 font-mono text-[10px] font-semibold tracking-[0.25em] text-lux-charcoal uppercase transition-all duration-300 hover:border-lux-rosegold w-full sm:w-auto"
            >
              Advisory Desk
            </motion.button>
          </div>
        </motion.div>

        {/* Brand Accolades / Right Column */}
        <motion.div 
          style={{ opacity: opacityText }}
          className="mt-12 flex flex-col items-start gap-8 border-l border-lux-rosegold/20 pl-6 text-left md:mt-0 md:items-end md:border-l-0 md:border-r md:pr-10 md:pl-0 md:text-right"
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1.2, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
        >
          {/* Awwwards Replica Seal Widget */}
          <div className="flex items-center gap-3">
            <div className="flex flex-col">
              <span className="font-mono text-[9px] tracking-widest text-lux-rosegold/80 uppercase">Awwwards. Site of the Day</span>
              <span className="font-sans text-xs font-semibold text-lux-charcoal">Gold Selection Award 2026 · Winner</span>
            </div>
            <div className="flex h-12 w-12 items-center justify-center rounded-full border border-lux-gold/30 bg-[#faf6f0]/90 backdrop-blur-md">
              <Award className="h-5 w-5 text-lux-gold" />
            </div>
          </div>

          <div className="max-w-xs space-y-2">
            <div className="flex items-center gap-1 md:justify-end">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="h-3.5 w-3.5 fill-lux-gold text-lux-gold" />
              ))}
            </div>
            <p className="font-serif italic text-xs text-lux-charcoal/80">
              "An otherworldly fusion of premium architecture and sweet mastery. A monument in culinary innovation."
            </p>
            <span className="block font-mono text-[9px] tracking-[0.2em] text-lux-rosegold uppercase">
              — The Parisian Gastronomer, Nov 2025
            </span>
          </div>
        </motion.div>
      </div>

      {/* Floating Animated Scroll Down Cue */}
      <motion.div 
        className="absolute bottom-6 left-1/2 z-10 -translate-x-1/2 cursor-pointer flex flex-col items-center gap-2"
        animate={{ y: [0, 8, 0] }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        onClick={onDiscoverClick}
      >
        <span className="font-mono text-[9px] tracking-widest text-lux-charcoal uppercase opacity-60">
          Scroll to explore
        </span>
        <div className="flex h-8 w-8 items-center justify-center rounded-full border border-lux-charcoal/20 bg-[#faf6f0]/70 backdrop-blur-md">
          <ArrowDown className="h-3.5 w-3.5 text-lux-charcoal" />
        </div>
      </motion.div>
    </section>
  );
}
