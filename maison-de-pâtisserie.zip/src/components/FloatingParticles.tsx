import { motion } from "motion/react";

interface Particle {
  id: number;
  x: number;
  y: number;
  size: number;
  duration: number;
  delay: number;
  opacity: number;
}

// Generate static list of random-like particles to avoid SSR mismatch are keep render stable
const particlesData: Particle[] = Array.from({ length: 24 }).map((_, i) => ({
  id: i,
  x: (i * 7) % 100, // percentage horizontal
  y: (i * 13) % 100, // percentage vertical
  size: ((i * 3) % 4) + 2, // 2px to 5px size
  duration: 15 + ((i * 4) % 12), // 15s to 27s
  delay: (i * 0.75) % 10, // 0s to 10s delay
  opacity: 0.15 + (((i * 9) % 35) / 100), // 0.15 to 0.50
}));

export default function FloatingParticles() {
  return (
    <div id="floating-gold-dust-sandbox" className="pointer-events-none absolute inset-0 overflow-hidden z-2">
      {particlesData.map((p) => (
        <motion.div
          key={p.id}
          className="absolute rounded-full bg-linear-to-tr from-lux-gold to-lux-rosegold"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: p.size,
            height: p.size,
            opacity: p.opacity,
            filter: "drop-shadow(0 0 4px rgba(197, 168, 128, 0.4))",
          }}
          animate={{
            y: [-120, -10],
            x: [0, Math.sin(p.id) * 40, 0],
            opacity: [0, p.opacity, p.opacity * 0.5, 0],
          }}
          transition={{
            duration: p.duration,
            repeat: Infinity,
            delay: p.delay,
            ease: "easeInOut",
          }}
        />
      ))}
    </div>
  );
}
