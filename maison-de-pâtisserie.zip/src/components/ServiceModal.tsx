import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Sparkles, Send, CheckCircle, Calendar, Users, Briefcase, Calculator } from "lucide-react";

interface ServiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  preSelectedCake?: string;
}

export default function ServiceModal({ isOpen, onClose, preSelectedCake = "" }: ServiceModalProps) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [eventDate, setEventDate] = useState("");
  const [guests, setGuests] = useState("50");
  const [selectedStyle, setSelectedStyle] = useState(preSelectedCake || "Bespoke Art Piece");
  const [customText, setCustomText] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  
  // Real-time calculation of designer quotation based on guests + selection
  const [estimatePrice, setEstimatePrice] = useState(1200);

  useEffect(() => {
    // Keep parent selected product synched or prefilled
    if (preSelectedCake) {
      setSelectedStyle(preSelectedCake);
    }
  }, [preSelectedCake]);

  useEffect(() => {
    // Dynamic price estimation algorithm based on selected styles and portions
    let basePrice = 800;
    if (selectedStyle.includes("Elysian") || selectedStyle.includes("Gold")) basePrice = 1850;
    else if (selectedStyle.includes("Rose") || selectedStyle.includes("L'Aura")) basePrice = 1420;
    else if (selectedStyle.includes("Sphère") || selectedStyle.includes("entremet")) basePrice = 145;
    else if (selectedStyle.includes("Cube") || selectedStyle.includes("Noir")) basePrice = 950;
    else if (selectedStyle.includes("Fleur")) basePrice = 1200;
    else if (selectedStyle.includes("Pearl")) basePrice = 1600;

    const guestCount = parseInt(guests) || 10;
    const guestMultiplier = guestCount > 100 ? 1.5 : guestCount > 50 ? 1.2 : 1.0;
    const totalEstimate = Math.round(basePrice * guestMultiplier);
    setEstimatePrice(totalEstimate);
  }, [selectedStyle, guests]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !eventDate) return;

    setIsSubmitting(true);
    // Mimic the processing of an ultra-high-end cryptographic ledger signature or dispatch
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 2200);
  };

  const resetForm = () => {
    setName("");
    setEmail("");
    setEventDate("");
    setGuests("50");
    setSelectedStyle("Bespoke Art Piece");
    setCustomText("");
    setIsSuccess(false);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          id="service-modal-backdrop"
          className="fixed inset-0 z-50 flex items-center justify-center bg-lux-charcoal/85 p-4 backdrop-blur-xl"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          {/* Glassmorphic Container Box */}
          <motion.div
            id="advisory-form-container"
            className="relative w-full max-w-2xl rounded-3xl bg-lux-cream/95 p-8 md:p-10 border border-lux-rosegold/30 shadow-2xl overflow-hidden"
            initial={{ scale: 0.96, y: 15 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.96, y: 15 }}
            transition={{ type: "spring", stiffness: 300, damping: 28 }}
          >
            {/* Ambient Gold Glimmer inside Modal */}
            <div className="absolute top-0 right-0 w-48 h-48 bg-lux-gold/15 rounded-full blur-2xl pointer-events-none" />

            {/* Exit Trigger */}
            <button
              onClick={() => {
                resetForm();
                onClose();
              }}
              className="absolute top-6 right-6 flex h-8 w-8 items-center justify-center rounded-full border border-lux-rosegold/20 text-lux-charcoal hover:bg-lux-rosegold hover:text-white hover:rotate-90 transition-all duration-300 pointer-events-auto"
            >
              <X className="h-4 w-4" />
            </button>

            {/* Successful dispatch screen */}
            {isSuccess ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-10 space-y-6"
              >
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-600 border border-emerald-500/30">
                  <CheckCircle className="h-8 w-8" />
                </div>

                <div className="space-y-2">
                  <span className="font-mono text-[9px] tracking-[0.4em] text-lux-rosegold uppercase block">
                    Advisory Dispatched
                  </span>
                  <h3 className="font-display text-3xl font-light text-lux-charcoal">
                    Sovereign Commission Logged
                  </h3>
                  <p className="max-w-md mx-auto font-sans text-xs font-light leading-relaxed text-lux-charcoal/70">
                    We have successfully registered your interest, <strong>{name}</strong>. A dedicated Artisan Liaison officer will reach out to <strong>{email}</strong> via private invite inside 24 standard hours.
                  </p>
                </div>

                {/* Estimate summary layout */}
                <div className="mx-auto max-w-sm rounded-2xl border border-lux-gold/20 bg-lux-cream/60 p-5 mt-4">
                  <div className="flex justify-between items-center font-mono text-[9px] uppercase tracking-wider text-lux-charcoal">
                    <span>Assigned Style Portfolio</span>
                    <span className="font-semibold text-lux-rosegold">{selectedStyle}</span>
                  </div>
                  <div className="flex justify-between items-center font-mono text-[9px] uppercase tracking-wider text-lux-charcoal mt-2">
                    <span>Estimated Tiers Value</span>
                    <span className="font-serif italic text-base text-lux-bronze font-bold">${estimatePrice}</span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    resetForm();
                    onClose();
                  }}
                  className="rounded-full bg-lux-charcoal text-white font-mono text-[10px] tracking-widest uppercase px-8 py-3.5 hover:bg-lux-rosegold transition-colors duration-300"
                >
                  Return to Atelier
                </button>
              </motion.div>
            ) : (
              /* Request advisory form and live calculator */
              <div className="space-y-6">
                
                {/* Header detail */}
                <div className="space-y-2 text-left">
                  <span className="font-mono text-[9px] tracking-[0.4em] text-lux-rosegold uppercase block">
                    Bespoke Consultation Service
                  </span>
                  <h3 className="font-display text-2xl font-light text-lux-charcoal sm:text-3xl">
                    Sovereign <span className="font-serif italic font-bold text-lux-rosegold">Commission</span> Portal
                  </h3>
                  <p className="font-sans text-[11px] font-light text-lux-charcoal/75 max-w-lg">
                    Schedule a private advisory session to draft custom confectionery architecture for weddings, haute couture galas, or elite corporate installations.
                  </p>
                </div>

                {/* Form Elements */}
                <form onSubmit={handleSubmit} className="space-y-4">
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
                    {/* Name */}
                    <div className="space-y-1">
                      <label className="font-mono text-[9px] uppercase tracking-widest text-[#151413]/60 pl-1 block">Your Name</label>
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Baroness de Rothschild"
                        className="w-full rounded-xl border border-lux-rosegold/20 bg-linear-to-tr from-white to-[#faf6f0] px-4 py-3 font-sans text-xs focus:border-lux-rosegold focus:outline-hidden"
                      />
                    </div>

                    {/* Email */}
                    <div className="space-y-1">
                      <label className="font-mono text-[9px] uppercase tracking-widest text-[#151413]/60 pl-1 block">Email Courier</label>
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="client@sovereign.com"
                        className="w-full rounded-xl border border-lux-rosegold/20 bg-linear-to-tr from-white to-[#faf6f0] px-4 py-3 font-sans text-xs focus:border-lux-rosegold focus:outline-hidden"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-left">
                    {/* Event Date */}
                    <div className="space-y-1">
                      <label className="font-mono text-[9px] uppercase tracking-widest text-[#151413]/60 pl-1 block">
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3 w-3 text-lux-gold" />
                          <span>Event Date</span>
                        </span>
                      </label>
                      <input
                        type="date"
                        required
                        value={eventDate}
                        onChange={(e) => setEventDate(e.target.value)}
                        className="w-full rounded-xl border border-lux-rosegold/20 bg-linear-to-tr from-white to-[#faf6f0] px-4 py-3 font-sans text-xs focus:border-lux-rosegold focus:outline-hidden"
                      />
                    </div>

                    {/* Guests Scale */}
                    <div className="space-y-1">
                      <label className="font-mono text-[9px] uppercase tracking-widest text-[#151413]/60 pl-1 block">
                        <span className="flex items-center gap-1">
                          <Users className="h-3 w-3 text-lux-gold" />
                          <span>Estimated Guests</span>
                        </span>
                      </label>
                      <select
                        value={guests}
                        onChange={(e) => setGuests(e.target.value)}
                        className="w-full rounded-xl border border-lux-rosegold/20 bg-linear-to-tr from-white to-[#faf6f0] px-3 py-3 font-sans text-xs focus:border-lux-rosegold focus:outline-hidden"
                      >
                        <option value="20">Under 30 Servings</option>
                        <option value="50">30 - 60 Servings</option>
                        <option value="100">60 - 120 Servings</option>
                        <option value="250">Grand Gala (150+ Servings)</option>
                      </select>
                    </div>

                    {/* Select Collection Style */}
                    <div className="space-y-1">
                      <label className="font-mono text-[9px] uppercase tracking-widest text-[#151413]/60 pl-1 block">
                        <span className="flex items-center gap-1">
                          <Briefcase className="h-3 w-3 text-lux-gold" />
                          <span>Design Style</span>
                        </span>
                      </label>
                      <select
                        value={selectedStyle}
                        onChange={(e) => setSelectedStyle(e.target.value)}
                        className="w-full rounded-xl border border-lux-rosegold/20 bg-linear-to-tr from-white to-[#faf6f0] px-3 py-3 font-sans text-xs focus:border-lux-rosegold focus:outline-hidden"
                      >
                        <option value="The Elysian Gold">The Elysian Gold</option>
                        <option value="L’Aura de Rose">L’Aura de Rose</option>
                        <option value="Sphère d'Or-Rose">Sphère d'Or-Rose</option>
                        <option value="Le Cube Noir-Et-Or">Le Cube Noir-Et-Or</option>
                        <option value="Fleur Luxueuse">Fleur Luxueuse</option>
                        <option value="Le Céleste Perle">Le Céleste Perle</option>
                        <option value="Custom Sculpted Blueprints">Bespoke Custom Sculpt</option>
                      </select>
                    </div>
                  </div>

                  {/* Aesthetic Concept notes */}
                  <div className="space-y-1 text-left">
                    <label className="font-mono text-[9px] uppercase tracking-widest text-[#151413]/60 pl-1 block">Aesthetic Concept Notes / Venue Style</label>
                    <textarea
                      rows={2}
                      value={customText}
                      onChange={(e) => setCustomText(e.target.value)}
                      placeholder="Share specifics on color pairing, floral installations, or venue architecture..."
                      className="w-full rounded-xl border border-lux-rosegold/20 bg-linear-to-tr from-white to-[#faf6f0] p-4 font-sans text-xs focus:border-lux-rosegold focus:outline-hidden"
                    />
                  </div>

                  {/* Real-time Luxury Estimator Card */}
                  <div className="flex items-center justify-between p-4 bg-lux-cham/25 border border-lux-gold/20 rounded-2xl">
                    <div className="flex items-center gap-2">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#faf6f0] text-lux-gold">
                        <Calculator className="h-4 w-4" />
                      </div>
                      <div className="text-left">
                        <span className="block font-mono text-[8px] tracking-wider text-lux-charcoal/50 uppercase">Atelier Quotation Guide</span>
                        <span className="block font-mono text-[9px] text-lux-charcoal font-semibold">Tiers, Logistics & Custom Gilding included</span>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <span className="block font-serif text-[11px] text-lux-rosegold/80 uppercase tracking-widest">EST. VALOUR</span>
                      <span className="block font-serif italic text-lg font-bold text-lux-charcoal">${estimatePrice} USD</span>
                    </div>
                  </div>

                  {/* Submitting button with luxury spring indicator */}
                  <div className="pt-2">
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full flex items-center justify-center gap-2.5 rounded-full bg-lux-charcoal py-4 text-center font-mono text-[10px] font-semibold tracking-[0.25em] text-white uppercase transition-all duration-300 hover:bg-lux-rosegold focus:outline-hidden shadow-lg shadow-lux-charcoal/10"
                    >
                      {isSubmitting ? (
                        <>
                          <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                          <span>Encrypting & Registering...</span>
                        </>
                      ) : (
                        <>
                          <Send className="h-3.5 w-3.5" />
                          <span>Request Private Invitation</span>
                        </>
                      )}
                    </button>
                  </div>

                </form>
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
