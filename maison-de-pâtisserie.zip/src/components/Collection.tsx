import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { CAKES_COLLECTION } from "../data";
import { Cake } from "../types";
import { Sparkles, Calendar, ShoppingBag, Info, X, Star, Heart } from "lucide-react";

interface CollectionProps {
  onBespokeClick: (cakeName: string) => void;
}

export default function Collection({ onBespokeClick }: CollectionProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [activeCake, setActiveCake] = useState<Cake | null>(null);
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [likes, setLikes] = useState<Record<string, boolean>>({});

  const categories = ["All", "Haute Couture", "Sculpted Art", "Delicate Entremet"];

  const filteredCakes = selectedCategory === "All"
    ? CAKES_COLLECTION
    : CAKES_COLLECTION.filter(cake => cake.category === selectedCategory);

  const toggleLike = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setLikes(prev => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <section id="collection" className="relative py-28 px-6 md:px-12 bg-lux-cream overflow-hidden">
      
      {/* Background radial soft ambient lights */}
      <div className="absolute top-20 right-0 w-80 h-80 rounded-full bg-lux-pink-200/20 blur-3xl" />
      <div className="absolute bottom-10 left-0 w-96 h-96 rounded-full bg-lux-cham/30 blur-3xl" />

      <div className="relative mx-auto max-w-7xl">
        
        {/* Section Header */}
        <div className="mb-16 text-center space-y-4">
          <motion.span 
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            className="font-mono text-[10px] tracking-[0.4em] text-lux-rosegold uppercase block"
          >
            The Pastry Exhibition
          </motion.span>
          
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ delay: 0.1 }}
            className="font-display text-4xl font-light text-lux-charcoal sm:text-5xl"
          >
            La Table de <span className="font-serif italic font-bold text-lux-rosegold">Couture</span>
          </motion.h2>
          
          <div className="h-[1px] w-20 bg-lux-rosegold/30 mx-auto mt-4" />
        </div>

        {/* Categories Tab Selector with Slider */}
        <div className="flex flex-wrap justify-center items-center gap-3 mb-16">
          {categories.map((cat, idx) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className="relative px-6 py-2.5 rounded-full font-mono text-[9px] font-semibold tracking-widest uppercase transition-all duration-300 focus:outline-hidden"
              style={{
                color: selectedCategory === cat ? "#151413" : "rgba(21, 20, 19, 0.65)"
              }}
            >
              {selectedCategory === cat && (
                <motion.div
                  layoutId="activeCategoryBg"
                  className="absolute inset-0 bg-radial from-lux-pink-100 to-[#f2eae0] rounded-full shadow-xs border border-lux-rosegold/20"
                  transition={{ type: "spring", stiffness: 300, damping: 25 }}
                />
              )}
              <span className="relative z-10">{cat}</span>
            </button>
          ))}
        </div>

        {/* 3-Column Luxury Grid */}
        <motion.div 
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10"
        >
          <AnimatePresence mode="popLayout">
            {filteredCakes.map((cake) => {
              const isLiked = !!likes[cake.id];
              return (
                <motion.div
                  layout
                  id={`cake-card-${cake.id}`}
                  key={cake.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-50px" }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.6 }}
                  onMouseEnter={() => setHoveredId(cake.id)}
                  onMouseLeave={() => setHoveredId(null)}
                  onClick={() => setActiveCake(cake)}
                  className="group relative cursor-pointer overflow-hidden rounded-3xl border border-lux-rosegold/10 bg-lux-cream/40 p-4 backdrop-blur-md transition-all duration-500 hover:border-lux-rosegold/30 hover:shadow-2xl hover:shadow-lux-rosegold/10"
                >
                  {/* Rose Gold Gradient Border Overlay */}
                  <div className="absolute inset-0 -z-1 opacity-0 group-hover:opacity-100 bg-linear-to-tr from-lux-pink-200/30 via-transparent to-lux-gold/30 transition-all duration-700" />
                  
                  {/* Photo Studio Container */}
                  <div className="relative aspect-4/3 w-full overflow-hidden rounded-2xl bg-lux-cream-dark">
                    <img
                      src={cake.image}
                      alt={cake.name}
                      referrerPolicy="no-referrer"
                      className="absolute inset-0 h-full w-full object-cover transition-transform duration-1000 ease-out group-hover:scale-108"
                    />
                    
                    {/* Dark gradient shadow inside card image */}
                    <div className="absolute inset-0 bg-linear-to-t from-lux-charcoal/40 via-transparent to-transparent opacity-60" />

                    {/* Category Label Overlay */}
                    <div className="absolute top-4 left-4 rounded-full bg-[#faf6f0]/90 backdrop-blur-xs border border-lux-rosegold/20 px-3.5 py-1.5 font-mono text-[8px] tracking-widest text-lux-charcoal font-semibold uppercase">
                      {cake.category}
                    </div>

                    {/* Like Action Icon */}
                    <button
                      onClick={(e) => toggleLike(cake.id, e)}
                      className="absolute top-4 right-4 flex h-8 w-8 items-center justify-center rounded-full bg-[#faf6f0]/90 backdrop-blur-xs border border-lux-rosegold/20 text-lux-charcoal transition-all duration-300 hover:bg-lux-rosegold hover:text-white"
                    >
                      <Heart className={`h-3.5 w-3.5 transition-all ${isLiked ? "fill-lux-rosegold text-lux-rosegold" : "text-lux-charcoal"}`} />
                    </button>
                  </div>

                  {/* Descriptions block */}
                  <div className="mt-6 flex flex-col justify-between pl-1">
                    <div className="space-y-1">
                      <span className="font-mono text-[9px] tracking-widest text-lux-rosegold uppercase block">
                        {cake.subtitle}
                      </span>
                      <h3 className="font-display text-xl font-light text-lux-charcoal group-hover:text-lux-rosegold transition-colors duration-300">
                        {cake.name}
                      </h3>
                    </div>
                    
                    <div className="mt-5 flex items-center justify-between border-t border-lux-rosegold/10 pt-4">
                      <span className="font-mono text-[10px] tracking-widest text-lux-charcoal font-semibold">
                        Bespoke base: {cake.price}
                      </span>
                      <span className="font-mono text-[9px] tracking-widest text-lux-rosegold uppercase flex items-center gap-1 group-hover:underline">
                        <span>Examine details</span>
                        <span>→</span>
                      </span>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </motion.div>
      </div>

      {/* Exquisite Full Screen Product Modal */}
      <AnimatePresence>
        {activeCake && (
          <motion.div
            id="cake-details-overlay"
            className="fixed inset-0 z-50 flex items-center justify-center bg-lux-charcoal/80 p-4 backdrop-blur-md"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              id="details-card-scroller"
              className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-3xl bg-[#faf6f0] border border-lux-rosegold/20 shadow-2xl"
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
            >
              {/* Close Button Trigger */}
              <button
                onClick={() => setActiveCake(null)}
                className="absolute top-6 right-6 z-10 flex h-10 w-10 items-center justify-center rounded-full border border-lux-rosegold/20 bg-lux-cream text-lux-charcoal transition-all hover:bg-lux-rosegold hover:text-white hover:rotate-90 duration-300"
              >
                <X className="h-4 w-4" />
              </button>

              <div className="grid grid-cols-1 md:grid-cols-2">
                {/* Visual Half */}
                <div className="relative h-64 md:h-full min-h-[300px] bg-lux-cream-dark">
                  <img
                    src={activeCake.image}
                    alt={activeCake.name}
                    className="absolute inset-0 h-full w-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-linear-to-t from-[#faf6f0] md:bg-linear-to-r md:from-transparent md:to-[#faf6f0]/30" />
                </div>

                {/* Cultural/Pastry Science Information half */}
                <div className="p-8 md:p-12 space-y-8 flex flex-col justify-between">
                  <div className="space-y-4">
                    <div className="space-y-1">
                      <span className="font-mono text-[9px] tracking-widest text-lux-rosegold uppercase">
                        {activeCake.category} Collection
                      </span>
                      <h3 className="font-display text-3xl font-light text-lux-charcoal">
                        {activeCake.name}
                      </h3>
                    </div>
                    
                    <p className="font-sans text-xs font-light leading-relaxed text-lux-charcoal/80">
                      {activeCake.description}
                    </p>
                  </div>

                  {/* Flavor Architecture Metrics */}
                  <div className="space-y-4 border-t border-b border-lux-rosegold/10 py-6">
                    <h4 className="font-mono text-[10px] tracking-widest text-lux-charcoal uppercase font-bold">
                      La Gastronomie Architecte
                    </h4>
                    
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between font-mono text-[9px] text-lux-charcoal mb-1">
                          <span>Main Flavor Profile</span>
                          <span className="text-lux-rosegold font-semibold">{activeCake.profile.flavor}</span>
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between font-mono text-[9px] text-lux-charcoal mb-1">
                          <span>Texture Composition</span>
                          <span className="text-lux-rosegold font-semibold">{activeCake.profile.texture}</span>
                        </div>
                      </div>

                      {/* Sweetness Meter with Stars */}
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-[9px] text-lux-charcoal uppercase">Sweetness Scale</span>
                        <div className="flex items-center gap-1.5">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <div 
                              key={i} 
                              className={`h-2.5 w-2.5 rounded-full transition-colors ${
                                i < activeCake.profile.sweetness ? "bg-lux-rosegold" : "bg-lux-rosegold/20"
                              }`} 
                            />
                          ))}
                        </div>
                      </div>

                      {/* Portions */}
                      <div className="flex justify-between font-mono text-[9px] text-lux-charcoal">
                        <span>Standard Volume</span>
                        <span className="text-lux-rosegold font-semibold">{activeCake.profile.sizeServings}</span>
                      </div>
                    </div>

                    {/* Interactive Ingredients Pills */}
                    <div className="flex flex-wrap gap-1.5 pt-2">
                      {activeCake.profile.notes.map((note) => (
                        <span 
                          key={note}
                          className="rounded-md bg-lux-cream-dark px-2 py-1 font-mono text-[8px] tracking-wider text-lux-bronze/90 border border-lux-rosegold/10"
                        >
                          ✦ {note}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Booking Trigger Buttons */}
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex flex-col">
                      <span className="font-mono text-[9px] tracking-widest text-[#151413]/50 uppercase">Initial Quote</span>
                      <span className="font-serif italic text-2xl font-bold text-lux-charcoal">{activeCake.price}</span>
                    </div>

                    <button
                      onClick={() => {
                        onBespokeClick(activeCake.name);
                        setActiveCake(null);
                      }}
                      className="flex items-center gap-2 rounded-full bg-lux-rosegold border border-lux-rosegold px-6 py-3.5 font-mono text-[9px] font-semibold tracking-widest text-white uppercase shadow-lg shadow-lux-rosegold/20 hover:bg-[#faf6f0] hover:text-lux-rosegold transition-all duration-300 pointer-events-auto"
                    >
                      <ShoppingBag className="h-3 w-3" />
                      <span>Order Commission</span>
                    </button>
                  </div>

                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </section>
  );
}
