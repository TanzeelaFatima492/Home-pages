import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { TESTIMONIALS } from "../data";
import { ChevronLeft, ChevronRight, Quote, Star, Sparkles } from "lucide-react";

export default function Testimonials() {
  const [index, setIndex] = useState(0);

  const prev = () => {
    setIndex((prevIndex) => (prevIndex === 0 ? TESTIMONIALS.length - 1 : prevIndex - 1));
  };

  const next = () => {
    setIndex((prevIndex) => (prevIndex === TESTIMONIALS.length - 1 ? 0 : prevIndex + 1));
  };

  const current = TESTIMONIALS[index];

  return (
    <section id="testimonials" className="relative py-28 px-6 bg-[#faf6f0] overflow-hidden border-t border-b border-lux-rosegold/10">
      
      {/* Background visual graphics */}
      <div className="absolute top-1/2 left-10 -translate-y-1/2 font-serif text-[18rem] font-bold text-lux-rosegold/3 opacity-5 pointer-events-none select-none">
        “
      </div>
      
      <div className="relative mx-auto max-w-4xl text-center space-y-12">
        
        {/* Section Title */}
        <div className="space-y-3">
          <span className="font-mono text-[9px] tracking-[0.4em] text-lux-rosegold uppercase block">
            La Critique
          </span>
          <h2 className="font-display text-4xl font-light text-lux-charcoal">
            Selected <span className="font-serif italic font-bold text-lux-rosegold">Evaluations</span>
          </h2>
          <div className="h-[1px] w-12 bg-lux-rosegold/30 mx-auto mt-2" />
        </div>

        {/* Carousel Visual Box */}
        <div className="relative min-h-[220px] flex items-center justify-center py-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={current.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.5, ease: "easeInOut" }}
              className="space-y-6"
            >
              {/* Publication Badge */}
              <div className="inline-flex items-center gap-2 rounded-full border border-lux-rosegold/20 bg-lux-cream px-3 py-1 font-mono text-[8px] tracking-[0.2em] text-lux-charcoal font-semibold uppercase">
                <Sparkles className="h-2.5 w-2.5 text-lux-gold" />
                <span>{current.publication}</span>
              </div>

              {/* Majestic Quote */}
              <p className="font-serif text-xl md:text-2xl font-light italic leading-relaxed text-lux-charcoal/90 px-4 md:px-12">
                "{current.quote}"
              </p>

              {/* Stars */}
              <div className="flex justify-center items-center gap-1">
                {Array.from({ length: current.rating }).map((_, i) => (
                  <Star key={i} className="h-3.5 w-3.5 fill-lux-gold text-lux-gold" />
                ))}
              </div>

              {/* Authourial Citation */}
              <div>
                <h4 className="font-display text-sm font-semibold text-lux-charcoal">
                  {current.author}
                </h4>
                <p className="font-mono text-[9px] tracking-wider text-lux-rosegold uppercase mt-0.5">
                  {current.role}
                </p>
              </div>

            </motion.div>
          </AnimatePresence>
        </div>

        {/* Carousel Slide Controller Buttons */}
        <div className="flex justify-center items-center gap-8 pt-4">
          <button
            onClick={prev}
            className="flex h-12 w-12 items-center justify-center rounded-full border border-lux-rosegold/20 bg-lux-cream text-lux-charcoal transition-all hover:border-lux-rosegold hover:bg-lux-rosegold hover:text-white"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>

          {/* Dots Indicator */}
          <div className="flex items-center gap-2">
            {TESTIMONIALS.map((t, idx) => (
              <button
                key={t.id}
                onClick={() => setIndex(idx)}
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  idx === index ? "bg-lux-rosegold w-6" : "bg-lux-rosegold/20 w-1.5"
                }`}
              />
            ))}
          </div>

          <button
            onClick={next}
            className="flex h-12 w-12 items-center justify-center rounded-full border border-lux-rosegold/20 bg-lux-cream text-lux-charcoal transition-all hover:border-lux-rosegold hover:bg-lux-rosegold hover:text-white"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>

      </div>

    </section>
  );
}
