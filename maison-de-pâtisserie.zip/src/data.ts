import { Cake, Testimonial, StatItem } from "./types";

export const CAKES_COLLECTION: Cake[] = [
  {
    id: "elysian-gold",
    name: "The Elysian Gold",
    subtitle: "A multi-layered monument of sweet architecture",
    description: "An extraordinary multi-tiered couture creation accented with hand-laid 24k champagne gold gold leaf. Sculpted with a velvety cream-blush vanilla bean paste and paired with single-estate Madagascar vanilla buttercream.",
    price: "$1,850",
    image: "/src/assets/images/luxury_hero_cake_1780230898311.png",
    category: "Haute Couture",
    profile: {
      flavor: "Madagascar Vanilla & Salted Tonka Caramel",
      texture: "Light Velvet Sponge interspersed with Crisp praline crust",
      notes: ["Madagascar Bourbon Vanilla", "Fleur de Sel", "White Peach Gelée", "Warm Tonka Bean"],
      sweetness: 3,
      sizeServings: "100 - 120 Servings"
    }
  },
  {
    id: "rose-romantique",
    name: "L’Aura de Rose",
    subtitle: "Delicate sugar-petal rose sculptures adorned with rose gold margins",
    description: "Designed for grand statements, this blush and dusty-rose masterpiece features hundreds of handcrafted individual sugar rose petals. Adorned with a fine crystalline shimmer and premium gold accents.",
    price: "$1,420",
    image: "/src/assets/images/rose_gold_floral_cake_1780230944749.png",
    category: "Sculpted Art",
    profile: {
      flavor: "Blush Champagne & Wild Raspberry Infusion",
      texture: "Airy champagne-infused layers with silky white chocolate ganache",
      notes: ["Laurent-Perrier Rosé Reduction", "Wild Raspberries", "Almond Marzipan", "Organic Elderflower"],
      sweetness: 2,
      sizeServings: "60 - 80 Servings"
    }
  },
  {
    id: "or-et-rose-entremet",
    name: "Sphère d'Or-Rose",
    subtitle: "A perfect mirror-glazed jewel of technical modern pastry",
    description: "An avant-garde entremet featuring a high-gloss rose and champagne gold mirror glaze. Hovering on a minimalist concrete base, this perfect gem hides layers of rich chocolate mousse and liquid berry coulis.",
    price: "$145",
    image: "/src/assets/images/pink_gold_entremet_1780230920456.png",
    category: "Delicate Entremet",
    profile: {
      flavor: "Dark Cocoa Grand Cru & Passion Fruit Core",
      texture: "Satin-smooth cold mousse with a fluid-burst molten center",
      notes: ["Criollo Cocoa Blend 74%", "Molten Maracujá", "Piedmont Hazelnut Praline", "Sea-salt Feuilletine"],
      sweetness: 4,
      sizeServings: "Individual or 4 - 6 Servings"
    }
  },
  {
    id: "le-biscuit-monochrome",
    name: "Le Cube Noir-Et-Or",
    subtitle: "A geometric celebration of ultra-minimalist dessert design",
    description: "A dark charcoal and gold leaf cube featuring stark geometric symmetry. Highlighting clean lines that reference modern sculptural installation art, finished with hand-brushed rose-gold dust.",
    price: "$950",
    category: "Sculpted Art",
    image: "https://images.unsplash.com/photo-1535141192574-5d4897c13636?auto=format&fit=crop&q=80&w=720",
    profile: {
      flavor: "Smoked Espresso & Salted Black Sesame Cream",
      texture: "Dense, earthy and incredibly buttery, with sharp chocolate crisp foundations",
      notes: ["Roasted Robusta", "Black sesame tahini", "72% Single-origin chocolate", "Himalayan Pink Salt"],
      sweetness: 2,
      sizeServings: "40 - 50 Servings"
    }
  },
  {
    id: "fleur-luxueuse",
    name: "Fleur Luxueuse",
    subtitle: "A botanical pastel marvel featuring fresh-pressed biological petals",
    description: "An ethereal organic dream featuring edible micro-flowers crystalized in individual glass-like sugar panes. A clean, fresh botanical profile with wild lavender, lemon curd, and white champagne syrup.",
    price: "$1,200",
    category: "Haute Couture",
    image: "https://images.unsplash.com/photo-1519340333755-56e8359b4337?auto=format&fit=crop&q=80&w=720",
    profile: {
      flavor: "Provencal Lavender & Preserved Lemon Curd",
      texture: "Delicate lemon sponge layered with rich whipped lavender buttercream",
      notes: ["Fresh Lavender Infusion", "Amalfi Lemon Zest", "Raw Thyme Honey", "Whipped mascarpone"],
      sweetness: 3,
      sizeServings: "50 - 70 Servings"
    }
  },
  {
    id: "lunaire-pearl",
    name: "Le Céleste Perle",
    subtitle: "A pearl-encrusted celebration of celestial textures",
    description: "Inspired by sea pearls and moonlight, this delicate cream-white masterpiece is decorated with edible glowing confectionery pearls and thin white chocolate ribbons that curve elegantly around each layer.",
    price: "$1,600",
    category: "Haute Couture",
    image: "https://images.unsplash.com/photo-1522758971460-1d21eed7dc1d?auto=format&fit=crop&q=80&w=720",
    profile: {
      flavor: "White Velvet Almond & Spiced Pear Comté",
      texture: "Melt-in-the-mouth crumb with smooth baked pear compote",
      notes: ["Blanched Almond Flour", "Chardonnay-poached Pears", "Cinnamon bark extract", "Spiced honey"],
      sweetness: 2,
      sizeServings: "80 - 100 Servings"
    }
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: "t1",
    quote: "Maison de Pâtisserie didn’t just make a cake; they constructed a modern masterpiece. It was the visual and culinary anchor of our wedding at Lake Como.",
    author: "Genevieve Stirling",
    role: "Aesthetic Lead & Art Curator",
    publication: "Vogue Weddings",
    rating: 5
  },
  {
    id: "t2",
    quote: "The Sphère d’Or-Rose is an astounding culinary feat. The tension between the brittle glass-like outer shell and the flowing molten maracujá center is breathtaking.",
    author: "Chef Pierre-Jean L’Eclère",
    role: "Senior Gastronomy Critic",
    publication: "Michelin Guide",
    rating: 5
  },
  {
    id: "t3",
    quote: "Unmatched craftsmanship. Their work exists at the clean intersection of high-fashion sculpture and otherworldly confectionery satisfaction.",
    author: "Vivian Ward",
    role: "Creative Director",
    publication: "Harper’s Bazaar",
    rating: 5
  },
  {
    id: "t4",
    quote: "Every element on their bespoke cakes feels absolutely deliberate. It’s rare to find such high-fidelity architecture combined with sublime organic taste.",
    author: "Marcella C.",
    role: "Editor-at-Large",
    publication: "Brides Magazine",
    rating: 5
  }
];

export const STATS: StatItem[] = [
  { value: 12, suffix: "", label: "Years of Haute Confectionery" },
  { value: 48, suffix: "K+", label: "Couture Designs Manifested" },
  { value: 24, suffix: "k", label: "Pure Carat Gold Leafing Used" },
  { value: 3, suffix: "★", label: "Michelin-Affiliated Master Pastry Chefs" }
];
