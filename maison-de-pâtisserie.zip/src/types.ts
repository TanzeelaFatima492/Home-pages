export interface Cake {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  price: string;
  image: string;
  category: "Haute Couture" | "Sculpted Art" | "Delicate Entremet";
  profile: {
    flavor: string;
    texture: string;
    notes: string[];
    sweetness: number; // 1-5 scale
    sizeServings: string;
  };
}

export interface Testimonial {
  id: string;
  quote: string;
  author: string;
  role: string;
  publication: "Vogue Weddings" | "Michelin Guide" | "Harper’s Bazaar" | "The New York Times" | "Brides Magazine";
  rating: number;
}

export interface StatItem {
  value: number;
  suffix: string;
  label: string;
}

export type ActiveTab = "home" | "gallery" | "atelier" | "contact";
