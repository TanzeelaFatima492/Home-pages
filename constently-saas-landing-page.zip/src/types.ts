/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { LucideIcon } from 'lucide-react';

export interface NavItem {
  id: string;
  label: string;
  href: string;
  icon: LucideIcon;
}

export interface NavbarSettings {
  layout: 'capsule' | 'classic';
  blur: number; // in pixels
  glowEnabled: boolean;
  borderPinkGradient: boolean;
  floatingSpeed: number; // in seconds
  activeSection: string;
  sticky: boolean;
  accentGradient: string; // CSS gradient string
  hoverPillEffect: boolean;
}

export interface SearchResult {
  id: string;
  title: string;
  category: 'Feature' | 'Solution' | 'Resource';
  url: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  description: string;
  time: string;
  unread: boolean;
  type: 'info' | 'success' | 'alert';
}
