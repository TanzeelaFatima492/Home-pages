/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Settings, Sparkles, AlertCircle, Eye, EyeOff, Layout, Zap, Sliders, ChevronDown, ChevronUp } from 'lucide-react';
import { NavbarSettings } from '../types';

interface SettingsPanelProps {
  settings: NavbarSettings;
  setSettings: React.Dispatch<React.SetStateAction<NavbarSettings>>;
  inspectorMode: boolean;
  setInspectorMode: (val: boolean) => void;
}

export default function SettingsPanel({
  settings,
  setSettings,
  inspectorMode,
  setInspectorMode,
}: SettingsPanelProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);

  return (
    <div id="settings-panel" className="fixed bottom-6 right-6 z-40 max-w-sm w-[90vw] overflow-hidden rounded-2xl bg-neutral-900 border border-neutral-800 shadow-2xl text-white transition-all duration-300">
      {/* Settings Header */}
      <div 
        onClick={() => setIsCollapsed(!isCollapsed)}
        className="bg-neutral-950 p-4 flex items-center justify-between cursor-pointer hover:bg-neutral-900/60 transition-colors border-b border-neutral-800/80"
      >
        <div className="flex items-center gap-2">
          <Settings className="h-4 w-4 text-[#ff78c5] animate-spin" style={{ animationDuration: '6s' }} />
          <div>
            <h3 className="text-xs font-semibold tracking-tight font-sans text-white">
              Navbar Design Laboratory
            </h3>
            <p className="text-[10px] text-neutral-400 font-mono">
              Live Customization Engine
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#ff4fa3]/10 text-[#ff78c5] border border-[#ff4fa3]/20">
            V1.0
          </span>
          {isCollapsed ? <ChevronUp className="h-3.5 w-3.5 text-neutral-400" /> : <ChevronDown className="h-3.5 w-3.5 text-neutral-400" />}
        </div>
      </div>

      {/* Settings Contents */}
      {!isCollapsed && (
        <div className="p-4 space-y-4 max-h-[60vh] overflow-y-auto">
          {/* Note */}
          <div className="rounded-lg bg-neutral-950 p-3 text-[10px] font-sans text-neutral-400 border border-neutral-800/85 flex items-start gap-2">
            <Sparkles className="h-4 w-4 text-[#ff78c5] shrink-0 mt-0.5" />
            <span>
              Tweak parameters to watch the navbar adapt in real-time. Turn on <strong>Designer Mode</strong> to inspect exact padding and borders.
            </span>
          </div>

          {/* Designer Mode Switch */}
          <div className="flex items-center justify-between bg-neutral-950 p-2.5 rounded-lg border border-neutral-800/50">
            <div className="flex items-center gap-2">
              {inspectorMode ? (
                <Eye className="h-4 w-4 text-[#ff78c5]" />
              ) : (
                <EyeOff className="h-4 w-4 text-neutral-500" />
              )}
              <div>
                <span className="block text-xs font-medium text-white">Designer Inspect Mode</span>
                <span className="block text-[9px] text-neutral-400 font-mono">Hover navbar for padding & dimensions</span>
              </div>
            </div>
            <button
              onClick={() => setInspectorMode(!inspectorMode)}
              className={`relative inline-flex h-5 w-10 items-center rounded-full transition-colors ${
                inspectorMode ? 'bg-gradient-to-r from-[#ff4fa3] to-[#ff78c5]' : 'bg-neutral-800'
              }`}
            >
              <span
                className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white transition-transform ${
                  inspectorMode ? 'translate-x-5.5' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Controls list */}
          <div className="space-y-3 pt-1">
            {/* 1. Placement Layout */}
            <div className="space-y-1.5">
              <label className="text-[10px] font-mono text-neutral-400 uppercase tracking-widest flex items-center justify-between">
                <span>1. Layout Container</span>
                <span className="text-white text-[11px]">{settings.layout}</span>
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setSettings(prev => ({ ...prev, layout: 'capsule' }))}
                  className={`py-1.5 rounded-md text-xs font-semibold font-sans transition-all border ${
                    settings.layout === 'capsule'
                      ? 'bg-gradient-to-r from-[#ff4fa3] to-[#ff78c5] text-white border-transparent shadow-[0_0_10px_rgba(255,79,163,0.3)]'
                      : 'bg-neutral-950 text-neutral-400 border-neutral-800 hover:text-white'
                  }`}
                >
                  Rounded Capsule
                </button>
                <button
                  onClick={() => setSettings(prev => ({ ...prev, layout: 'classic' }))}
                  className={`py-1.5 rounded-md text-xs font-semibold font-sans transition-all border ${
                    settings.layout === 'classic'
                      ? 'bg-gradient-to-r from-[#ff4fa3] to-[#ff78c5] text-white border-transparent'
                      : 'bg-neutral-950 text-neutral-400 border-neutral-800 hover:text-white'
                  }`}
                >
                  Classic Banner
                </button>
              </div>
            </div>

            {/* 2. Glassmorphism Backdrop Blur */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-[10px] font-mono text-neutral-400 uppercase tracking-widest">
                <span>2. Backdrop Blur</span>
                <span className="text-white text-[11px]">{settings.blur}px</span>
              </div>
              <input
                type="range"
                min="0"
                max="32"
                step="4"
                value={settings.blur}
                onChange={(e) => setSettings(prev => ({ ...prev, blur: parseInt(e.target.value) }))}
                className="w-full h-1 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-[#ff78c5]"
              />
              <div className="flex justify-between text-[8px] font-sans text-neutral-500">
                <span>None (0px)</span>
                <span>Medium (16px)</span>
                <span>Ultra (32px)</span>
              </div>
            </div>

            {/* 3. Floating Speed */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-[10px] font-mono text-neutral-400 uppercase tracking-widest">
                <span>3. Logo Floating Motion</span>
                <span className="text-white text-[11px]">{settings.floatingSpeed}s loop</span>
              </div>
              <input
                type="range"
                min="1"
                max="10"
                step="1"
                value={settings.floatingSpeed}
                onChange={(e) => setSettings(prev => ({ ...prev, floatingSpeed: parseInt(e.target.value) }))}
                className="w-full h-1 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-[#ff4fa3]"
              />
              <div className="flex justify-between text-[8px] font-sans text-neutral-500">
                <span>Vigorous (1s)</span>
                <span>Standard (4s)</span>
                <span>Gentle (10s)</span>
              </div>
            </div>

            {/* 4. Glow Enabled toggle */}
            <div className="flex items-center justify-between py-1.5 border-t border-neutral-800/40">
              <span className="text-[10px] font-mono text-neutral-400 uppercase tracking-widest">4. Ambient Glow</span>
              <button
                onClick={() => setSettings(prev => ({ ...prev, glowEnabled: !prev.glowEnabled }))}
                className={`relative inline-flex h-4 w-8 items-center rounded-full transition-colors ${
                  settings.glowEnabled ? 'bg-[#ff78c5]' : 'bg-neutral-800'
                }`}
              >
                <span
                  className={`inline-block h-2.5 w-2.5 transform rounded-full bg-white transition-transform ${
                    settings.glowEnabled ? 'translate-x-4.5' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* 5. Border Pink Gradient */}
            <div className="flex items-center justify-between py-1.5 border-t border-b border-neutral-800/44">
              <span className="text-[10px] font-mono text-neutral-400 uppercase tracking-widest">5. Pink Gradient Frame</span>
              <button
                onClick={() => setSettings(prev => ({ ...prev, borderPinkGradient: !prev.borderPinkGradient }))}
                className={`relative inline-flex h-4 w-8 items-center rounded-full transition-colors ${
                  settings.borderPinkGradient ? 'bg-[#ff4fa3]' : 'bg-neutral-800'
                }`}
              >
                <span
                  className={`inline-block h-2.5 w-2.5 transform rounded-full bg-white transition-transform ${
                    settings.borderPinkGradient ? 'translate-x-4.5' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* 6. Hover Pill Background Effect */}
            <div className="flex items-center justify-between py-1.5">
              <span className="text-[10px] font-mono text-neutral-400 uppercase tracking-widest">6. Floating Hover Pill</span>
              <button
                onClick={() => setSettings(prev => ({ ...prev, hoverPillEffect: !prev.hoverPillEffect }))}
                className={`relative inline-flex h-4 w-8 items-center rounded-full transition-colors ${
                  settings.hoverPillEffect ? 'bg-[#ff4fa3]' : 'bg-neutral-800'
                }`}
              >
                <span
                  className={`inline-block h-2.5 w-2.5 transform rounded-full bg-white transition-transform ${
                    settings.hoverPillEffect ? 'translate-x-4.5' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* 7. Scroll Behavior Sticky switch */}
            <div className="flex items-center justify-between py-1.5 border-t border-neutral-800/40">
              <span className="text-[10px] font-mono text-neutral-400 uppercase tracking-widest">7. Sticky on Scroll</span>
              <button
                onClick={() => setSettings(prev => ({ ...prev, sticky: !prev.sticky }))}
                className={`relative inline-flex h-4 w-8 items-center rounded-full transition-colors ${
                  settings.sticky ? 'bg-[#ff78c5]' : 'bg-neutral-800'
                }`}
              >
                <span
                  className={`inline-block h-2.5 w-2.5 transform rounded-full bg-white transition-transform ${
                    settings.sticky ? 'translate-x-4.5' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Specs Panel */}
          <div className="rounded-lg bg-neutral-950 p-2.5 border border-dashed border-neutral-850 space-y-1">
            <span className="block text-[8px] font-mono text-neutral-500 uppercase tracking-widest">Active CSS Rules</span>
            <div className="text-[9px] font-mono text-emerald-400/90 leading-relaxed overflow-x-auto whitespace-pre">
              {`.luxury-capsule {
  backdrop-filter: blur(${settings.blur}px);
  border: ${settings.borderPinkGradient ? '1px solid linear-gradient' : '1px solid #e5e7eb'};
  box-shadow: ${settings.glowEnabled ? '0 0 24px rgba(255,120,197,0.6)' : '0 10px 15px -3px rgba(0,0,0,0.1)'};
}
.logo-animate {
  animation: float ${settings.floatingSpeed}s ease-in-out infinite;
}`}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
