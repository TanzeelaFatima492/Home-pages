/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  TrendingUp,
  Cpu,
  Layers,
  CheckCircle,
  HelpCircle,
  ArrowUpRight,
  BookOpen,
  Mail,
  Zap,
  Globe,
  Award,
  ChevronRight,
  Check,
  Send,
  Loader2
} from 'lucide-react';

export default function FeatureSections() {
  // Solutions interactive Tab
  const [activeTab, setActiveTab] = useState<'retail' | 'vc' | 'creators'>('retail');

  // Pricing interactive Toggle
  const [isAnnual, setIsAnnual] = useState(false);

  // Contact form submission state
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
      setEmail('');
    }, 1200);
  };

  return (
    <div className="w-full">
      
      {/* ── SECTION 1: FEATURES (Bento Grid) ── */}
      <section id="features" className="py-20 px-4 md:px-8 max-w-7xl mx-auto w-full">
        <div className="text-center mb-16">
          <span className="text-[10px] font-mono tracking-widest uppercase text-[#ff4fa3] font-semibold bg-[#ff4fa3]/10 px-3 py-1 rounded-full">
            01 // CAPABILITIES
          </span>
          <h2 className="text-3xl md:text-4xl font-display font-medium text-neutral-950 mt-4 tracking-tight">
            Designed for Multi-Channel Dominance
          </h2>
          <p className="text-sm text-neutral-500 font-sans mt-3 max-w-xl mx-auto">
            Everything your brand needs to automate, test, and scale premium copy and assets under a synchronized system.
          </p>
        </div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Card 1: Copywriting Engine (Double span on desktop) */}
          <div className="md:col-span-2 rounded-2xl border border-neutral-200 bg-white p-6 sm:p-8 hover:border-[#ff78c5]/40 transition-shadow hover:shadow-[0_12px_30px_rgba(255,79,163,0.04)] relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-[#ff4fa3]/5 to-[#ff78c5]/5 rounded-bl-[100px] pointer-events-none" />
            <div className="rounded-xl bg-[#ff4fa3]/10 text-[#ff4fa3] p-2.5 h-10 w-10 flex items-center justify-center transition-transform group-hover:scale-105">
              <Sparkles className="h-5 w-5" />
            </div>
            <h3 className="text-lg font-semibold text-neutral-800 font-sans mt-5">AI Copywriting Assistant</h3>
            <p className="text-sm text-neutral-500 font-sans mt-2.5 max-w-md">
              Synchronize custom editorial voices that write high-conversion copy matching your precise layout rules and character lengths, and export content natively to standard channels.
            </p>
            <div className="mt-6 flex flex-wrap gap-2 text-[10px] font-mono">
              <span className="px-2.5 py-1 rounded-md bg-neutral-100 text-neutral-500">Tone matching</span>
              <span className="px-2.5 py-1 rounded-md bg-neutral-100 text-neutral-500">SEO metadata</span>
              <span className="px-2.5 py-1 rounded-md bg-[#ff4fa3]/10 text-[#ff4fa3]">99.8% precision</span>
            </div>
          </div>

          {/* Card 2: SEO Optimizer */}
          <div className="rounded-2xl border border-neutral-200 bg-white p-6 sm:p-8 hover:border-[#ff78c5]/40 transition-shadow hover:shadow-[0_12px_30px_rgba(255,79,163,0.04)] group">
            <div className="rounded-xl bg-[#ff78c5]/10 text-[#ff78c5] p-2.5 h-10 w-10 flex items-center justify-center transition-transform group-hover:scale-105">
              <TrendingUp className="h-5 w-5" />
            </div>
            <h3 className="text-lg font-semibold text-neutral-800 font-sans mt-5">Automated SEO Optimizer</h3>
            <p className="text-xs text-neutral-500 font-sans mt-2.5 leading-relaxed">
              Autogenerate SEO rankings, scrape trend pools hourly, and format code markup automatically. Watch your rankings rise with no physical keying constraints.
            </p>
            <div className="text-[10px] font-mono mt-6 text-[#ff4fa3] font-semibold flex items-center gap-1 group-hover:gap-1.5 transition-all">
              <span>Explore SEO triggers</span> <ChevronRight className="h-3 w-3" />
            </div>
          </div>

          {/* Card 3: Scheduler */}
          <div className="rounded-2xl border border-neutral-200 bg-white p-6 sm:p-8 hover:border-[#ff4fa3]/40 transition-shadow hover:shadow-[0_12px_30px_rgba(255,79,163,0.04)] group">
            <div className="rounded-xl bg-indigo-50 text-indigo-600 p-2.5 h-10 w-10 flex items-center justify-center transition-transform group-hover:scale-105">
              <Layers className="h-5 w-5" />
            </div>
            <h3 className="text-lg font-semibold text-neutral-800 font-sans mt-5">Visual Narrative Scheduler</h3>
            <p className="text-xs text-neutral-500 font-sans mt-2.5 leading-relaxed">
              Drop copy into a beautiful calendar workspace. Control campaigns by dragging cells, linking assets, and planning pipelines with active visual notifications.
            </p>
          </div>

          {/* Card 4: Global CDN (Double span) */}
          <div className="md:col-span-2 rounded-2xl border border-neutral-200 bg-white p-6 sm:p-8 hover:border-[#ff78c5]/40 transition-shadow hover:shadow-[0_12px_30px_rgba(255,79,163,0.04)] relative overflow-hidden group">
            <div className="absolute -bottom-6 -right-6 w-40 h-40 bg-gradient-to-tr from-indigo-500/5 to-[#ff78c5]/5 rounded-tl-[100px] pointer-events-none" />
            <div className="rounded-xl bg-emerald-50 text-emerald-600 p-2.5 h-10 w-10 flex items-center justify-center transition-transform group-hover:scale-105">
              <Globe className="h-5 w-5" />
            </div>
            <h3 className="text-lg font-semibold text-neutral-800 font-sans mt-5">Global Network & Integration Edge</h3>
            <p className="text-sm text-neutral-500 font-sans mt-2.5 max-w-lg">
              Deliver low-latency content worldwide. Constently handles auto-translating into 34 different languages while preserving branding rules, local terminology variations, and tone constraints flawlessly.
            </p>
            <div className="mt-6 flex flex-wrap gap-2 text-[10px] font-mono">
              <span className="px-2.5 py-1 rounded-md bg-emerald-50 text-emerald-700">34 Global languages</span>
              <span className="px-2.5 py-1 rounded-md bg-neutral-100 text-neutral-500">Fast API endpoints</span>
              <span className="px-2.5 py-1 rounded-md bg-neutral-100 text-neutral-500">S3 Static Backing</span>
            </div>
          </div>
          
        </div>
      </section>

      {/* ── SECTION 2: SOLUTIONS (Interactive Case Tabs) ── */}
      <section id="solutions" className="bg-neutral-50/70 border-t border-b border-neutral-200/60 py-20 px-4 md:px-8 w-full">
        <div className="max-w-7xl mx-auto">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Content */}
            <div className="lg:col-span-5 space-y-6">
              <div>
                <span className="text-[10px] font-mono tracking-widest uppercase text-[#ff4fa3] font-semibold bg-[#ff4fa3]/10 px-3 py-1 rounded-full">
                  02 // USE CASES
                </span>
                <h2 className="text-3xl md:text-4xl font-display font-bold text-neutral-900 mt-4 tracking-tight leading-tight">
                  Calibrated for the Modern Ecosystem
                </h2>
                <p className="text-sm text-neutral-500 font-sans mt-4 leading-relaxed">
                  Every field operates under distinct boundaries. Constently provides deep-trained models for exact brand paradigms.
                </p>
              </div>

              {/* Navigation Tabs buttons */}
              <div className="flex flex-col gap-2">
                <button
                  onClick={() => setActiveTab('retail')}
                  className={`flex items-center gap-3 w-full p-4 rounded-xl text-left border transition-all ${
                    activeTab === 'retail'
                      ? 'bg-white border-neutral-200 text-neutral-900 shadow-sm'
                      : 'border-transparent text-neutral-400 hover:text-neutral-700'
                  }`}
                >
                  <span className={`h-2 w-2 rounded-full ${activeTab === 'retail' ? 'bg-[#ff4fa3]' : 'bg-neutral-300'}`} />
                  <div>
                    <span className="block text-xs font-semibold font-sans">E-Commerce & High-Growth Retail</span>
                    <span className="block text-[10px] font-mono text-neutral-400 mt-0.5">Scale descriptions, product copy, and social pipelines</span>
                  </div>
                </button>

                <button
                  onClick={() => setActiveTab('vc')}
                  className={`flex items-center gap-3 w-full p-4 rounded-xl text-left border transition-all ${
                    activeTab === 'vc'
                      ? 'bg-white border-neutral-200 text-neutral-900 shadow-sm'
                      : 'border-transparent text-neutral-400 hover:text-neutral-700'
                  }`}
                >
                  <span className={`h-2 w-2 rounded-full ${activeTab === 'vc' ? 'bg-[#ff4fa3]' : 'bg-neutral-300'}`} />
                  <div>
                    <span className="block text-xs font-semibold font-sans">Venture Capital & Portfolios</span>
                    <span className="block text-[10px] font-mono text-neutral-400 mt-0.5">Brand automation, reports summaries, and social presence</span>
                  </div>
                </button>

                <button
                  onClick={() => setActiveTab('creators')}
                  className={`flex items-center gap-3 w-full p-4 rounded-xl text-left border transition-all ${
                    activeTab === 'creators'
                      ? 'bg-white border-neutral-200 text-neutral-900 shadow-sm'
                      : 'border-transparent text-neutral-400 hover:text-neutral-700'
                  }`}
                >
                  <span className={`h-2 w-2 rounded-full ${activeTab === 'creators' ? 'bg-[#ff4fa3]' : 'bg-neutral-300'}`} />
                  <div>
                    <span className="block text-xs font-semibold font-sans">Enterprise Creator Agencies</span>
                    <span className="block text-[10px] font-mono text-neutral-400 mt-0.5">Visual narratives scheduling, newsletters, stream outlines</span>
                  </div>
                </button>
              </div>
            </div>

            {/* Right Visual State (Bespoke Screen Cards showing what they can do) */}
            <div className="lg:col-span-7">
              <div className="bg-white rounded-2xl border border-neutral-200 shadow-xl overflow-hidden p-6 relative">
                <div className="absolute top-4 right-4 text-[9px] font-mono text-[#ff4fa3] flex items-center gap-1.5 bg-[#ff4fa3]/5 px-2 py-0.5 rounded border border-[#ff4fa3]/10">
                  <Sparkles className="h-3 w-3" /> ACTIVE SYSTEM MODEL
                </div>

                <AnimatePresence mode="wait">
                  {activeTab === 'retail' && (
                    <motion.div
                      key="retail"
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -10 }}
                      transition={{ duration: 0.3 }}
                      className="space-y-4"
                    >
                      <h4 className="text-base font-semibold font-sans text-neutral-800">E-Commerce Narrative Matrix</h4>
                      <p className="text-xs text-neutral-500 font-sans max-w-md">
                        Our dynamic commerce engine maps target user statistics, seasonality parameters, and visual details to write highly styled product captions:
                      </p>
                      
                      <div className="rounded-xl border border-neutral-100 p-4 bg-neutral-50 flex flex-col gap-2 text-xs">
                        <div className="flex justify-between items-center text-[10px] font-mono text-neutral-400 border-b border-neutral-200/50 pb-1.5">
                          <span>TRIGGER: NEW PRODUCT ADDED</span>
                          <span className="text-emerald-500 font-semibold">AUTOMATED CAPTION COMPLETE</span>
                        </div>
                        <p className="font-sans font-medium text-neutral-600 italic">
                          "Discover our handcrafted Obsidian Leather Tote. Seamlessly balanced with organic structural edges, crafted with water-resistant stitching. Designed for the executive nomad who refuses compromises."
                        </p>
                        <div className="flex justify-between items-center text-[10px] font-mono mt-1 text-neutral-400">
                          <span>Target Channels: Shopify, Instagram</span>
                          <span>Score Estimate: 9.8 / 10 Match</span>
                        </div>
                      </div>
                    </motion.div>
                  )}

                  {activeTab === 'vc' && (
                    <motion.div
                      key="vc"
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -10 }}
                      transition={{ duration: 0.3 }}
                      className="space-y-4"
                    >
                      <h4 className="text-base font-semibold font-sans text-neutral-800">Venture Brand Autopilot</h4>
                      <p className="text-xs text-neutral-500 font-sans max-w-md">
                        Maintain precise executive tone across portfolio directories. Synthesize quarterly updates, and auto-generate executive profiles flawlessly:
                      </p>

                      <div className="rounded-xl border border-neutral-100 p-4 bg-neutral-50 flex flex-col gap-2 text-xs">
                        <div className="flex justify-between items-center text-[10px] font-mono text-neutral-400 border-b border-neutral-200/50 pb-1.5">
                          <span>TRIGGER: QUARTERLY PORTFOLIO AUDIT</span>
                          <span className="text-indigo-500 font-semibold">REPORTS GENERATED</span>
                        </div>
                        <p className="font-sans font-medium text-neutral-600 italic">
                          "Our investments in Q1 2026 reflect a deep dedication to hyper-clean cloud infrastructures. Total active venture metrics tracked positive with an average of 42.1% growth across SaaS holdings."
                        </p>
                      </div>
                    </motion.div>
                  )}

                  {activeTab === 'creators' && (
                    <motion.div
                      key="creators"
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -10 }}
                      transition={{ duration: 0.3 }}
                      className="space-y-4"
                    >
                      <h4 className="text-base font-semibold font-sans text-neutral-800">Agency Narrative Scheduler</h4>
                      <p className="text-xs text-neutral-500 font-sans max-w-md">
                        Coordinate scripts write-ups, email sequences, and scheduled thread lists in one shared control deck with zero overlap issues:
                      </p>

                      <div className="rounded-xl border border-neutral-100 p-4 bg-neutral-50 flex flex-col gap-2 text-xs font-sans">
                        <div className="flex justify-between items-center text-[10px] font-mono text-neutral-400 border-b border-neutral-200/50 pb-1.5">
                          <span>CHANNELS: SUBSTACK, YOUTUBE, X</span>
                          <span className="text-amber-500 font-semibold">SYNCHRONIZED READY</span>
                        </div>
                        <ol className="list-decimal list-inside space-y-1 mt-1 text-neutral-600">
                          <li>Generate video script outline based on 2026 tech trends</li>
                          <li>Compose customized Substack newsletter campaign</li>
                          <li>Autofreeze X platform threads loop</li>
                        </ol>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
                
              </div>
            </div>
          </div>
          
        </div>
      </section>

      {/* ── SECTION 3: PRICING (Interactive Monthly/Annual Toggle) ── */}
      <section id="pricing" className="py-20 px-4 md:px-8 max-w-7xl mx-auto w-full">
        <div className="text-center mb-16">
          <span className="text-[10px] font-mono tracking-widest uppercase text-[#ff4fa3] font-semibold bg-[#ff4fa3]/10 px-3 py-1 rounded-full">
            03 // PRICING
          </span>
          <h2 className="text-3xl md:text-4xl font-display font-medium text-neutral-950 mt-4 tracking-tight">
            Transparent Scaling Plans
          </h2>
          <p className="text-sm text-neutral-500 font-sans mt-3 max-w-lg mx-auto">
            Select the plan matching your organization's depth constraints. All plans include automated model retraining.
          </p>

          {/* Pricing Toggle Switch */}
          <div className="mt-8 flex items-center justify-center gap-3">
            <span className={`text-xs font-semibold ${!isAnnual ? 'text-neutral-900' : 'text-neutral-400'}`}>
              Pay Monthly
            </span>
            <button
              onClick={() => setIsAnnual(!isAnnual)}
              className="relative inline-flex h-6 w-11 items-center rounded-full bg-neutral-200 transition-colors cursor-pointer"
            >
              <span
                className={`inline-block h-4.5 w-4.5 transform rounded-full bg-white transition-transform ${
                  isAnnual ? 'translate-x-5.5' : 'translate-x-1'
                }`}
              />
            </button>
            <span className={`text-xs font-semibold flex items-center gap-1 ${isAnnual ? 'text-neutral-900' : 'text-neutral-400'}`}>
              Pay Annually
              <span className="bg-gradient-to-r from-[#ff4fa3] to-[#ff78c5] text-white text-[9px] font-mono px-1.5 py-0.5 rounded">
                SAVE 20%
              </span>
            </span>
          </div>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* Card 1: Starter */}
          <div className="rounded-2xl border border-neutral-200 bg-white p-6 sm:p-8 flex flex-col justify-between hover:border-neutral-300 transition-shadow hover:shadow-lg relative group">
            <div>
              <span className="text-xs font-mono text-neutral-400 font-bold uppercase tracking-widest">
                01 // DESIGNER
              </span>
              <h3 className="text-xl font-display font-semibold text-neutral-900 mt-2">Starter Suite</h3>
              <p className="text-xs text-neutral-500 font-sans mt-2">
                Ideal for independent specialists looking to automate basic queues.
              </p>
              
              {/* Dynamic Price */}
              <div className="mt-6 flex items-baseline gap-1">
                <span className="text-3xl font-display font-black text-neutral-900">
                  ${isAnnual ? '79' : '99'}
                </span>
                <span className="text-xs text-neutral-400 font-sans">/ month</span>
              </div>

              <ul className="mt-8 space-y-3 text-xs font-sans text-neutral-600">
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-emerald-500" />
                  <span>Up to 150,000 words generated</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-emerald-500" />
                  <span>3 Connected Brand Voices</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-emerald-500" />
                  <span>Standard calendar scheduler</span>
                </li>
              </ul>
            </div>

            <button className="mt-8 w-full py-2.5 rounded-full text-xs font-semibold border border-neutral-200 bg-white hover:bg-neutral-50 transition-colors">
              Choose Starter Suite
            </button>
          </div>

          {/* Card 2: Pro (Premium highlighted) */}
          <div className="rounded-2xl border-2 border-[#ff4fa3] bg-white p-6 sm:p-8 flex flex-col justify-between shadow-[0_12px_40px_rgba(255,79,163,0.1)] relative group">
            <span className="absolute -top-3 right-6 rounded-full bg-gradient-to-r from-[#ff4fa3] to-[#ff78c5] text-white px-3 py-1 text-[9px] font-mono uppercase tracking-widest font-bold">
              MOST EXQUISITE
            </span>

            <div>
              <span className="text-xs font-mono text-[#ff4fa3] font-bold uppercase tracking-widest">
                02 // EXECUTIVE
              </span>
              <h3 className="text-xl font-display font-semibold text-neutral-900 mt-2">Constently Pro</h3>
              <p className="text-xs text-neutral-500 font-sans mt-2">
                Perfect for elite portfolios and high-performance teams.
              </p>

              {/* Dynamic Price */}
              <div className="mt-6 flex items-baseline gap-1">
                <span className="text-3xl font-display font-black text-neutral-900">
                  ${isAnnual ? '199' : '249'}
                </span>
                <span className="text-xs text-neutral-400 font-sans">/ month</span>
              </div>

              <ul className="mt-8 space-y-3 text-xs font-sans text-neutral-600">
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-[#ff4fa3]" />
                  <span className="font-medium text-[#ff4fa3]">Unlimited words generated</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-[#ff4fa3]" />
                  <span>Uncapped Connected voices</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-[#ff4fa3]" />
                  <span>Custom theme & CSS extensions</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-[#ff4fa3]" />
                  <span>Priority engine speed training</span>
                </li>
              </ul>
            </div>

            <button className="mt-8 w-full py-2.5 rounded-full text-xs font-semibold text-white gradient-bg shadow-sm hover:opacity-90 transition-opacity">
              Upgrade to Pro Suite
            </button>
          </div>

          {/* Card 3: Enterprise */}
          <div className="rounded-2xl border border-neutral-200 bg-white p-6 sm:p-8 flex flex-col justify-between hover:border-neutral-300 transition-shadow hover:shadow-lg relative group">
            <div>
              <span className="text-xs font-mono text-neutral-400 font-bold uppercase tracking-widest">
                03 // MAJESTIC
              </span>
              <h3 className="text-xl font-display font-semibold text-neutral-900 mt-2">Global Scale</h3>
              <p className="text-xs text-neutral-500 font-sans mt-2">
                Designed for global holding groups needing unified security.
              </p>

              {/* Dynamic Price */}
              <div className="mt-6 flex items-baseline gap-1">
                <span className="text-3xl font-display font-black text-neutral-900">
                  Custom
                </span>
              </div>

              <ul className="mt-8 space-y-3 text-xs font-sans text-neutral-600">
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-emerald-500" />
                  <span>SLA uptime guarantee (99.99%)</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-emerald-500" />
                  <span>SSO & Enterprise credential vaults</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-emerald-500" />
                  <span>Dedicated machine learning coach</span>
                </li>
              </ul>
            </div>

            <button className="mt-8 w-full py-2.5 rounded-full text-xs font-semibold border border-neutral-200 bg-white hover:bg-neutral-50 transition-colors">
              Contact Deal Team
            </button>
          </div>
          
        </div>
      </section>

      {/* ── SECTION 4: RESOURCES (Premium Journals) ── */}
      <section id="resources" className="bg-neutral-50/70 border-t border-b border-neutral-200/60 py-20 px-4 md:px-8 w-full">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-16">
            <div>
              <span className="text-[10px] font-mono tracking-widest uppercase text-[#ff4fa3] font-semibold bg-[#ff4fa3]/10 px-3 py-1 rounded-full">
                04 // KNOWLEDGEBASE
              </span>
              <h2 className="text-3xl md:text-4xl font-display font-medium text-neutral-950 mt-4 tracking-tight">
                Luxury Content Insights
              </h2>
            </div>
            <a href="#resources" className="text-xs font-mono text-[#ff4fa3] font-bold flex items-center gap-1 hover:gap-1.5 transition-all mt-4 sm:mt-0">
              Browse all library items <ArrowUpRight className="h-3.5 w-3.5" />
            </a>
          </div>

          {/* Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            
            {/* Guide 1 */}
            <div className="rounded-2xl border border-neutral-200 bg-white overflow-hidden group hover:border-[#ff78c5]/40 transition-colors">
              <div className="h-48 overflow-hidden relative">
                <img
                  src="https://picsum.photos/seed/editorial/600/400"
                  alt="Minimal luxury editorial backdrop"
                  className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute bottom-3 left-3 bg-white text-[9px] font-mono px-2 py-0.5 rounded uppercase">
                  REPORTS
                </span>
              </div>
              <div className="p-6">
                <span className="text-[10px] font-mono text-[#ff4fa3]">May 28 • 5 min read</span>
                <h3 className="text-sm font-semibold font-sans text-neutral-950 mt-2 group-hover:text-[#ff4fa3] transition-colors leading-snug">
                  Unocking Absolute Voice Consistency Across holding brands
                </h3>
                <p className="text-xs text-neutral-500 font-sans mt-3">
                  How modern ML transformers align writing constraints perfectly with historical copy vaults.
                </p>
              </div>
            </div>

            {/* Guide 2 */}
            <div className="rounded-2xl border border-neutral-200 bg-white overflow-hidden group hover:border-[#ff78c5]/40 transition-colors">
              <div className="h-48 overflow-hidden relative">
                <img
                  src="https://picsum.photos/seed/architecture/600/400"
                  alt="High-end structural lines"
                  className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute bottom-3 left-3 bg-white text-[9px] font-mono px-2 py-0.5 rounded TYPE_SPEC">
                  METRICS
                </span>
              </div>
              <div className="p-6">
                <span className="text-[10px] font-mono text-[#ff4fa3]">May 15 • 8 min read</span>
                <h3 className="text-sm font-semibold font-sans text-neutral-950 mt-2 group-hover:text-[#ff4fa3] transition-colors leading-snug">
                  The Decline of Generic Copier Clutter & The Rise of calibrating copy 
                </h3>
                <p className="text-xs text-neutral-500 font-sans mt-3">
                  Why simple AI generators damage luxury brand equity, and why deep voice layers are vital.
                </p>
              </div>
            </div>

            {/* Guide 3 */}
            <div className="rounded-2xl border border-neutral-200 bg-white overflow-hidden group hover:border-[#ff78c5]/40 transition-colors">
              <div className="h-48 overflow-hidden relative">
                <img
                  src="https://picsum.photos/seed/workspace/600/400"
                  alt="Macbook styled beautifully"
                  className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute bottom-3 left-3 bg-white text-[9px] font-mono px-2 py-0.5 rounded uppercase">
                  BENCHMARK
                </span>
              </div>
              <div className="p-6">
                <span className="text-[10px] font-mono text-[#ff4fa3]">April 30 • 12 min read</span>
                <h3 className="text-sm font-semibold font-sans text-neutral-950 mt-2 group-hover:text-[#ff4fa3] transition-colors leading-snug">
                  How Constently AI boosted luxury holding conversion by 34.2%
                </h3>
                <p className="text-xs text-neutral-500 font-sans mt-3">
                  Under the hood look at our generative neural weights and formatting rules in active trials.
                </p>
              </div>
            </div>
            
          </div>
        </div>
      </section>

      {/* ── SECTION 5: CONTACT (Interactive Form) ── */}
      <section id="contact" className="py-24 px-4 md:px-8 max-w-4xl mx-auto w-full text-center relative">
        <div className="absolute inset-0 bg-gradient-to-r from-[#ff4fa3]/4 to-transparent blur-3xl pointer-events-none -y-10" />

        <div className="rounded-2xl border border-neutral-200/80 bg-white p-8 sm:p-12 shadow-2xl relative overflow-hidden">
          {/* Top Brand Tagline Accent */}
          <div className="flex h-1.5 bg-gradient-to-r from-[#ff4fa3] to-[#ff78c5] absolute top-0 left-0 right-0 animate-pulse" />

          <span className="text-[10px] font-mono tracking-widest uppercase text-[#ff4fa3] font-semibold bg-[#ff4fa3]/10 px-3 py-1 rounded-full">
            05 // PARTNERSHIPS
          </span>
          <h2 className="text-3xl md:text-4xl font-display font-medium text-neutral-950 mt-4 tracking-tight">
            Secure Your Private Access
          </h2>
          <p className="text-sm text-neutral-500 font-sans mt-3 max-w-md mx-auto leading-relaxed">
            Invite slots remain limited. Type your executive details below to connect with our platform partnership division.
          </p>

          <div className="mt-8 max-w-md mx-auto relative min-h-[50px]">
            <AnimatePresence mode="wait">
              {!submitted ? (
                <motion.form
                  key="contact-form"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onSubmit={handleContactSubmit}
                  className="flex flex-col sm:flex-row gap-2 relative"
                >
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="partner@yourluxurybrand.com"
                    className="flex-1 px-5 py-3 rounded-full border border-neutral-200 text-xs font-sans placeholder-neutral-400 outline-none focus:border-[#ff4fa3] focus:ring-1 focus:ring-[#ff4fa3] transition-colors"
                  />
                  <button
                    type="submit"
                    disabled={loading}
                    className="shrink-0 px-6 py-3 rounded-full text-xs font-bold text-white gradient-bg shadow-sm transition-all hover:scale-102 flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        <span>Verifying Account...</span>
                      </>
                    ) : (
                      <>
                        <Send className="h-3.5 w-3.5" />
                        <span>Request Access Invite</span>
                      </>
                    )}
                  </button>
                </motion.form>
              ) : (
                <motion.div
                  key="contact-success"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex flex-col items-center justify-center p-6 rounded-2xl bg-emerald-50 border border-emerald-200/50 text-emerald-800"
                >
                  <CheckCircle className="h-8 w-8 text-emerald-500 animate-bounce mb-3" />
                  <h3 className="text-sm font-semibold font-sans">Executive Request Logged</h3>
                  <p className="text-xs text-emerald-600 font-sans mt-1 max-w-[280px]">
                    We have reserved your invitation. Our partnership coordinator will email you within 2 business hours.
                  </p>
                  <button
                    onClick={() => setSubmitted(false)}
                    className="text-[10px] font-mono mt-4 text-emerald-700 underline font-semibold"
                  >
                    Submit another email
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* ── FOOTER CORE ── */}
      <footer className="border-t border-neutral-200 bg-white py-12 px-4 md:px-8 text-center text-xs font-sans text-neutral-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <span className="font-display font-black tracking-widest text-[#ff4fa3]">
              CONSTENTLY
            </span>
            <span className="text-[10px] text-neutral-300">|</span>
            <span>© 2026 Constently Technologies, Inc. All rights reserved.</span>
          </div>
          <div className="flex items-center gap-4 font-mono text-[10px]">
            <a href="#home" className="hover:text-neutral-600">Privacy Policy</a>
            <a href="#home" className="hover:text-neutral-600">Terms of Use</a>
            <span className="text-[#ff78c5] font-semibold flex items-center gap-1">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Node Global Live
            </span>
          </div>
        </div>
      </footer>
      
    </div>
  );
}
