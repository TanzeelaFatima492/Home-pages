/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { User, Settings, CreditCard, LogOut, ChevronRight, Sparkles, Server } from 'lucide-react';

interface ProfileDropdownProps {
  isOpen: boolean;
  onClose: () => void;
  userEmail: string;
}

export default function ProfileDropdown({ isOpen, onClose, userEmail }: ProfileDropdownProps) {
  if (!isOpen) return null;

  return (
    <div id="profile-dropdown" className="absolute right-0 top-18 z-50 w-64 overflow-hidden rounded-2xl bg-white/70 backdrop-blur-xl border border-white/60 shadow-2xl">
      {/* Decorative Gradient Bar */}
      <div className="h-1 bg-gradient-to-r from-[#ff4fa3] to-[#ff78c5]" />

      {/* Profile Header Card */}
      <div className="p-4 border-b border-neutral-100 bg-gradient-to-b from-[#ff4fa3]/2 to-transparent">
        <div className="flex items-center gap-3">
          <div className="relative">
            <img
              src="https://picsum.photos/seed/kashmiri/120/120"
              alt="User profile"
              className="h-10 w-10 rounded-full border border-neutral-200 object-cover"
              referrerPolicy="no-referrer"
            />
            <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full border border-white bg-emerald-500" />
          </div>
          <div className="min-w-0">
            <h4 className="text-xs font-semibold text-neutral-800 font-sans truncate">
              Kashmiri Rajpoot
            </h4>
            <p className="text-[10px] text-neutral-400 font-mono truncate">
              {userEmail || 'kashmiri@constently.ai'}
            </p>
          </div>
        </div>

        {/* Pro Badge */}
        <div className="mt-3 flex items-center justify-between rounded-lg bg-neutral-900 px-2.5 py-1.5 text-[10px] text-white font-mono">
          <span className="flex items-center gap-1">
            <Sparkles className="h-3 w-3 text-[#ff78c5] animate-pulse" />
            <span>CONSTENTLY PRO</span>
          </span>
          <span className="font-sans font-bold text-[#ff78c5]">ACTIVE</span>
        </div>
      </div>

      {/* Menu Options */}
      <div className="p-1">
        <button
          onClick={onClose}
          className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-xs font-medium text-neutral-600 hover:bg-neutral-50 hover:text-neutral-900 transition-colors"
        >
          <span className="flex items-center gap-2">
            <User className="h-3.5 w-3.5 text-neutral-400" />
            <span>My Workspace</span>
          </span>
          <ChevronRight className="h-3 w-3 text-neutral-400" />
        </button>

        <button
          onClick={onClose}
          className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-xs font-medium text-neutral-600 hover:bg-neutral-50 hover:text-neutral-900 transition-colors"
        >
          <span className="flex items-center gap-2">
            <CreditCard className="h-3.5 w-3.5 text-neutral-400" />
            <span>Billing & Usage</span>
          </span>
          <ChevronRight className="h-3 w-3 text-neutral-400" />
        </button>

        <button
          onClick={onClose}
          className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-xs font-medium text-neutral-600 hover:bg-neutral-50 hover:text-[#ff4fa3] transition-colors"
        >
          <span className="flex items-center gap-2">
            <Settings className="h-3.5 w-3.5 text-neutral-400" />
            <span>Integrations</span>
          </span>
          <ChevronRight className="h-3 w-3 text-neutral-400" />
        </button>
      </div>

      {/* Footer Metrics */}
      <div className="border-t border-neutral-100 bg-neutral-50/50 p-3 flex flex-col gap-1.5 font-mono text-[10px] text-neutral-400">
        <div className="flex justify-between">
          <span>API Requests</span>
          <span className="font-semibold text-neutral-700">924k / 1.5M</span>
        </div>
        <div className="h-1 w-full bg-neutral-200 rounded-full overflow-hidden">
          <div className="h-full bg-gradient-to-r from-[#ff4fa3] to-[#ff78c5] w-[62%]" />
        </div>
        <div className="flex justify-between items-center mt-1 text-[9px] text-neutral-400">
          <span className="flex items-center gap-1">
            <Server className="h-2.5 w-2.5 text-emerald-500" />
            <span>Node Status: Live</span>
          </span>
          <span>Reset in 12h</span>
        </div>
      </div>

      {/* Sign Out */}
      <div className="border-t border-neutral-100 p-1">
        <button
          onClick={onClose}
          className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs font-medium text-red-500 hover:bg-red-50 hover:text-red-700 transition-colors"
        >
          <LogOut className="h-3.5 w-3.5" />
          <span>Sign out of Workspace</span>
        </button>
      </div>
    </div>
  );
}
