/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, Calendar, TrendingUp, CheckCircle, Bell, BellRing, Trash2 } from 'lucide-react';
import { NotificationItem } from '../types';

interface NotificationPanelProps {
  notifications: NotificationItem[];
  isOpen: boolean;
  onMarkAllRead: () => void;
  onClearAll: () => void;
  onClose: () => void;
}

export default function NotificationPanel({
  notifications,
  isOpen,
  onMarkAllRead,
  onClearAll,
  onClose,
}: NotificationPanelProps) {
  if (!isOpen) return null;

  return (
    <div id="notification-panel" className="absolute right-0 top-18 z-50 w-80 sm:w-96 overflow-hidden rounded-2xl bg-white/70 backdrop-blur-xl border border-white/60 shadow-2xl">
      {/* Pink Highlight Header */}
      <div className="bg-gradient-to-r from-[#ff4fa3]/5 to-[#ff78c5]/5 px-4 py-3 flex items-center justify-between border-b border-neutral-100">
        <div className="flex items-center gap-2">
          <BellRing className="h-4 w-4 text-[#ff4fa3] animate-pulse" />
          <span className="text-xs font-sans font-semibold text-neutral-800 tracking-tight">
            Notifications
          </span>
          {notifications.some(n => n.unread) && (
            <span className="flex h-2 w-2 rounded-full bg-[#ff4fa3]" />
          )}
        </div>
        <div className="flex gap-2 text-[10px] font-mono">
          <button
            onClick={onMarkAllRead}
            disabled={!notifications.some(n => n.unread)}
            className="text-[#ff4fa3] hover:text-[#ff78c5] font-semibold transition-colors disabled:text-neutral-300"
          >
            Mark read
          </button>
          <span className="text-neutral-300">|</span>
          <button
            onClick={onClearAll}
            disabled={notifications.length === 0}
            className="text-neutral-400 hover:text-red-500 transition-colors disabled:text-neutral-200"
          >
            Clear all
          </button>
        </div>
      </div>

      {/* Notifications Scroll Box */}
      <div className="max-h-[300px] overflow-y-auto">
        {notifications.length > 0 ? (
          notifications.map((notif) => {
            let iconElement = <Sparkles className="h-4 w-4 text-[#ff4fa3]" />;
            if (notif.type === 'success') {
              iconElement = <CheckCircle className="h-4 w-4 text-emerald-500" />;
            } else if (notif.type === 'alert') {
              iconElement = <TrendingUp className="h-4 w-4 text-indigo-500" />;
            }
            return (
              <div
                key={notif.id}
                className={`flex gap-3 px-4 py-3 border-b border-neutral-100 transition-colors ${
                  notif.unread ? 'bg-[#ff4fa3]/2' : 'hover:bg-neutral-50/50'
                }`}
              >
                <div className={`mt-0.5 rounded-lg p-1.5 h-7 w-7 flex items-center justify-center ${
                  notif.unread ? 'bg-[#ff4fa3]/10' : 'bg-neutral-100'
                }`}>
                  {iconElement}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-start gap-1">
                    <p className={`text-xs font-medium font-sans text-neutral-800 truncate`}>
                      {notif.title}
                    </p>
                    <span className="text-[9px] font-mono text-neutral-400 shrink-0">
                      {notif.time}
                    </span>
                  </div>
                  <p className="text-[11px] text-neutral-500 font-sans mt-0.5 leading-relaxed">
                    {notif.description}
                  </p>
                  {notif.unread && (
                    <span className="inline-block mt-1 text-[9px] font-mono px-1.5 py-0.2 rounded-sm bg-[#ff4fa3]/10 text-[#ff4fa3]">
                      NEW ACTIVE
                    </span>
                  )}
                </div>
              </div>
            );
          })
        ) : (
          <div className="py-12 flex flex-col items-center justify-center text-center">
            <div className="rounded-full bg-neutral-50 p-3 text-neutral-300">
              <Bell className="h-5 w-5" />
            </div>
            <p className="text-xs font-medium text-neutral-500 mt-2">All quiet for now</p>
            <p className="text-[10px] text-neutral-400 mt-1">We will notify you on campaign events.</p>
          </div>
        )}
      </div>

      {/* Luxury Footer */}
      <div className="bg-neutral-50 px-4 py-2 border-t border-neutral-100 text-center">
        <a
          href="#resources"
          onClick={onClose}
          className="inline-block text-[10px] font-mono text-neutral-500 hover:text-[#ff4fa3] transition-colors"
        >
          View all automation workflows →
        </a>
      </div>
    </div>
  );
}
