/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Sparkles, Command, ArrowRight, CornerDownLeft, X } from 'lucide-react';
import { SearchResult } from '../types';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (sectionId: string) => void;
}

const mockResults: SearchResult[] = [
  { id: 'features-copywriter', title: 'AI Copywriting Assistant', category: 'Feature', url: 'features' },
  { id: 'features-seo', title: 'Automated SEO Optimizer', category: 'Feature', url: 'features' },
  { id: 'features-scheduler', title: 'Visual Narrative Scheduler', category: 'Feature', url: 'features' },
  { id: 'solutions-retail', title: 'Dynamic E-Commerce Personalization', category: 'Solution', url: 'solutions' },
  { id: 'solutions-vc', title: 'Venture Capital Brand Automation', category: 'Solution', url: 'solutions' },
  { id: 'pricing-plans', title: 'Flexible Growth & Scale Pricing', category: 'Resource', url: 'pricing' },
  { id: 'resources-trends', title: 'Content Evolution Guide 2026', category: 'Resource', url: 'resources' },
  { id: 'resources-casestudy', title: 'How Constently Boosted Leads by 420%', category: 'Resource', url: 'resources' },
];

export default function SearchModal({ isOpen, onClose, onNavigate }: SearchModalProps) {
  const [query, setQuery] = useState('');
  const [activeIndex, setActiveIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-focus input when opened
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
      setActiveIndex(0);
      setQuery('');
    }
  }, [isOpen]);

  // Handle Hotkeys
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        if (isOpen) onClose();
        else onClose(); // This will trigger parent toggle
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const filtered = mockResults.filter((item) =>
    item.title.toLowerCase().includes(query.toLowerCase()) ||
    item.category.toLowerCase().includes(query.toLowerCase())
  );

  const handleSelect = (index: number) => {
    if (filtered[index]) {
      onNavigate(filtered[index].url);
      onClose();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActiveIndex((prev) => (prev + 1) % Math.max(1, filtered.length));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActiveIndex((prev) => (prev - 1 + filtered.length) % Math.max(1, filtered.length));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      handleSelect(activeIndex);
    } else if (e.key === 'Escape') {
      e.preventDefault();
      onClose();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div id="search-modal" className="fixed inset-0 z-50 flex items-start justify-center pt-[12vh]">
          {/* Backdrop Blur */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-neutral-950/40 backdrop-blur-md"
          />

          {/* Modal Card */}
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.96 }}
            transition={{ type: 'spring', damping: 25, stiffness: 220 }}
            className="relative w-full max-w-2xl overflow-hidden rounded-2xl bg-white/75 backdrop-blur-xl border border-white/60 shadow-2xl"
          >
            {/* Top Pink Gradient Decorative Line */}
            <div className="h-1 bg-gradient-to-r from-[#ff4fa3] to-[#ff78c5]" />

            {/* Input Wrapper */}
            <div className="flex items-center gap-3 border-b border-neutral-100 px-4 py-4">
              <Search className="h-5 w-5 text-neutral-400" />
              <input
                ref={inputRef}
                type="text"
                placeholder="Search features, guides, services... (Press esc)"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setActiveIndex(0);
                }}
                onKeyDown={handleKeyDown}
                className="flex-1 bg-transparent text-neutral-800 placeholder-neutral-400 outline-none font-sans text-base"
              />
              <div className="flex items-center gap-1.5 rounded-md border border-neutral-200 bg-neutral-50 px-1.5 py-0.5 text-[10px] font-mono text-neutral-500">
                <Command className="h-2.5 w-2.5" /> K
              </div>
              <button
                onClick={onClose}
                className="rounded-full p-1 text-neutral-400 hover:bg-neutral-50 hover:text-neutral-600 transition-colors"
                aria-label="Close search"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Results */}
            <div className="max-h-[360px] overflow-y-auto p-2">
              <div className="px-3 py-1.5 text-[11px] font-mono font-medium uppercase tracking-wider text-neutral-400 flex items-center justify-between">
                <span>{query ? 'Search Results' : 'Suggested Directions'}</span>
                {query && <span>{filtered.length} found</span>}
              </div>

              {filtered.length > 0 ? (
                filtered.map((item, index) => {
                  const isActive = index === activeIndex;
                  return (
                    <div
                      key={item.id}
                      onClick={() => handleSelect(index)}
                      onMouseEnter={() => setActiveIndex(index)}
                      className={`flex cursor-pointer items-center justify-between rounded-xl px-4 py-3 transition-all duration-200 ${
                        isActive
                          ? 'bg-neutral-50 shadow-sm border-l-4 border-[#ff4fa3]'
                          : 'border-l-4 border-transparent hover:bg-neutral-50/50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`rounded-lg p-2 transition-colors ${
                          isActive ? 'bg-[#ff4fa3]/10 text-[#ff4fa3]' : 'bg-neutral-100 text-neutral-500'
                        }`}>
                          <Sparkles className="h-4 w-4" />
                        </div>
                        <div>
                          <span className="block text-sm font-medium text-neutral-800 font-sans">
                            {item.title}
                          </span>
                          <span className={`inline-block mt-0.5 text-[10px] font-mono px-2 py-0.5 rounded-full ${
                            item.category === 'Feature' ? 'bg-indigo-50 text-indigo-600' :
                            item.category === 'Solution' ? 'bg-emerald-50 text-emerald-600' :
                            'bg-amber-50 text-amber-600'
                          }`}>
                            {item.category}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        {isActive && (
                          <motion.span
                            initial={{ opacity: 0, x: -5 }}
                            animate={{ opacity: 1, x: 0 }}
                            className="text-xs text-neutral-400 flex items-center gap-1 font-mono"
                          >
                            Jump to <CornerDownLeft className="h-3 w-3" />
                          </motion.span>
                        )}
                        <ArrowRight className={`h-4 w-4 transition-transform ${
                          isActive ? 'text-[#ff4fa3] translate-x-0.5' : 'text-neutral-300'
                        }`} />
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-center text-neutral-500">
                  <div className="rounded-full bg-neutral-100 p-3 text-neutral-400 mb-2">
                    <Search className="h-5 w-5" />
                  </div>
                  <p className="text-sm font-medium">No results for "{query}"</p>
                  <p className="text-xs text-neutral-400 mt-1 max-w-[280px]">
                    Try searching for things like 'SEO', 'pricing', 'VC', or 'scheduler'.
                  </p>
                </div>
              )}
            </div>

            {/* Sticky Search Footer */}
            <div className="bg-neutral-50/80 border-t border-neutral-100 px-4 py-2 text-[11px] font-mono text-neutral-400 flex justify-between items-center">
              <span className="flex items-center gap-1.5">
                <span className="rounded border border-neutral-200 bg-white px-1 py-0.5 shadow-xs">↑↓</span> Move
              </span>
              <span className="flex items-center gap-1.5">
                <span className="rounded border border-neutral-200 bg-white px-2 py-0.5 shadow-xs">Enter</span> Select
              </span>
              <span className="flex items-center gap-1.5">
                <span className="rounded border border-neutral-200 bg-white px-1.5 py-0.5 shadow-xs">Esc</span> Quit
              </span>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
