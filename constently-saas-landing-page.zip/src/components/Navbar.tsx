/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Home,
  Sparkles,
  Cpu,
  Bookmark,
  Layers,
  HelpCircle,
  Menu,
  X,
  Search,
  Bell,
  Mail,
  Box,
  CreditCard,
  BookOpen,
  ArrowRight
} from 'lucide-react';
import { NavItem, NavbarSettings, NotificationItem } from '../types';
import logoUrl from '../assets/images/logo_constently_1780230553411.png';

// Define Navbar options matching the center section request
const NAV_ITEMS: NavItem[] = [
  { id: 'home', label: 'Home', href: '#home', icon: Home },
  { id: 'features', label: 'Features', href: '#features', icon: Box },
  { id: 'solutions', label: 'Solutions', href: '#solutions', icon: Cpu },
  { id: 'pricing', label: 'Pricing', href: '#pricing', icon: CreditCard },
  { id: 'resources', label: 'Resources', href: '#resources', icon: BookOpen },
  { id: 'contact', label: 'Contact', href: '#contact', icon: Mail },
];

interface NavbarProps {
  settings: NavbarSettings;
  setSettings: React.Dispatch<React.SetStateAction<NavbarSettings>>;
  inspectorMode: boolean;
  onSearchOpen: () => void;
  notifications: NotificationItem[];
  onNotificationsToggle: () => void;
  isNotificationsOpen: boolean;
  onProfileToggle: () => void;
  isProfileOpen: boolean;
}

export default function Navbar({
  settings,
  setSettings,
  inspectorMode,
  onSearchOpen,
  notifications,
  onNotificationsToggle,
  isNotificationsOpen,
  onProfileToggle,
  isProfileOpen,
}: NavbarProps) {
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeItem, setActiveItem] = useState('home');
  const [hasScrolled, setHasScrolled] = useState(false);
  const unreadCount = notifications.filter((n) => n.unread).length;

  // Track window scroll to tweak capsule density on scroll
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setHasScrolled(true);
      } else {
        setHasScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Update active navigation item based on current active section (scroll spy)
  useEffect(() => {
    if (settings.activeSection) {
      setActiveItem(settings.activeSection);
    }
  }, [settings.activeSection]);

  const handleNavClick = (itemId: string, href: string) => {
    setActiveItem(itemId);
    setSettings((prev) => ({ ...prev, activeSection: itemId }));
    setMobileMenuOpen(false);

    // Scroll to section manually
    const targetElement = document.querySelector(href);
    if (targetElement) {
      targetElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <>
      {/* 🚀 Entrance Animation & Floating Layout Container */}
      <motion.nav
        initial={{ opacity: 0, y: -25 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className={`${
          settings.sticky ? 'sticky top-0 z-50' : 'relative z-50'
        } w-full transition-all duration-300 py-6 px-4 md:px-8`}
        style={{
          paddingTop: settings.layout === 'capsule' ? (hasScrolled ? '12px' : '24px') : '0',
          paddingBottom: settings.layout === 'capsule' ? (hasScrolled ? '12px' : '24px') : '0',
        }}
      >
        <div
          className={`mx-auto transition-all duration-500 relative glass-navbar ${
            settings.layout === 'capsule'
              ? 'max-w-7xl rounded-full'
              : 'w-full'
          } ${
            settings.borderPinkGradient ? 'gradient-border-pink' : ''
          }`}
          style={{
            '--blur-amount': `${settings.blur}px`,
          } as React.CSSProperties}
        >
          {/* Main Flex Row */}
          <div className="flex items-center justify-between h-18 px-4 sm:px-6 md:px-8 lg:px-10">
            
            {/* ── LEFT SECTION: Logo & Brand ── */}
            <div
              id="navbar-left"
              onClick={() => handleNavClick('home', '#home')}
              className={`flex items-center gap-3 cursor-pointer shrink-0 py-2 rounded-xl transition-all relative ${
                inspectorMode ? 'outline-dashed outline-1 outline-blue-500 hover:after:content-["logo_container"] hover:after:absolute hover:after:-top-6 hover:after:left-0 hover:after:bg-blue-500 hover:after:text-white hover:after:text-[8px] hover:after:font-mono hover:after:px-1 hover:after:rounded' : ''
              }`}
            >
              {/* Floating Animated Logo Container */}
              <div 
                className="relative h-10 w-10 flex items-center justify-center shrink-0"
                style={{
                  animation: `float ${settings.floatingSpeed}s ease-in-out infinite`,
                }}
              >
                {/* Embedded Glow Ring */}
                {settings.glowEnabled && (
                  <div className="absolute inset-0 bg-[#ff4fa3]/20 rounded-full blur-md animate-pulse" />
                )}
                <img
                  src={logoUrl}
                  alt="Constently gradient circular logo"
                  className="h-9 w-9 rounded-full border border-[#ff78c5]/40 object-cover shadow-sm bg-white"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    // Fallback to stylized SVG in case image file is busy
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
                {/* Backup vector symbol built with pure CSS/SVG */}
                <span className="absolute inset-0 flex items-center justify-center bg-transparent pointer-events-none">
                  <div className="h-4 w-4 bg-gradient-to-tr from-[#ff4fa3] to-[#ff78c5] rounded-full hidden" />
                </span>
              </div>

              {/* Brand Typography */}
              <div className="flex flex-col min-w-[120px]">
                <span className="text-sm font-display font-black tracking-widest text-neutral-900 flex items-center gap-1 leading-none">
                  CONSTENTLY
                  <span className="inline-block h-1.5 w-1.5 rounded-full bg-gradient-to-r from-[#ff4fa3] to-[#ff78c5]" />
                </span>
                <span className="text-[9px] font-sans font-medium uppercase tracking-wider text-neutral-400 mt-0.5 leading-none">
                  AI Powered Content Automation
                </span>
              </div>
            </div>

            {/* ── CENTER SECTION: Navigation Items ── */}
            <div
              id="navbar-center"
              className={`hidden lg:flex items-center gap-1.5 ${
                inspectorMode ? 'outline-dashed outline-1 outline-green-500 relative hover:after:content-["nav_menu_spacing_gap-1.5"] hover:after:absolute hover:after:-top-6 hover:after:left-0 hover:after:bg-green-500 hover:after:text-white hover:after:text-[8px] hover:after:font-mono hover:after:px-1 hover:after:rounded' : ''
              }`}
            >
              {NAV_ITEMS.map((item) => {
                const isActive = activeItem === item.id;
                const Icon = item.icon;

                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id, item.href)}
                    onMouseEnter={() => setHoveredId(item.id)}
                    onMouseLeave={() => setHoveredId(null)}
                    className={`relative flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold tracking-wide font-sans transition-all duration-350 cursor-pointer ${
                      isActive
                        ? 'text-[#ff4fa3]'
                        : 'text-neutral-500 hover:text-neutral-900'
                    }`}
                  >
                    {/* Hover Glow & Backdrop Pill Slider */}
                    {settings.hoverPillEffect && hoveredId === item.id && !isActive && (
                      <motion.div
                        layoutId="nav-hover-pill"
                        transition={{ type: 'spring', stiffness: 350, damping: 28 }}
                        className="absolute inset-0 rounded-full bg-[#ff78c5]/6 border border-[#ff78c5]/15 shadow-sm"
                        style={{
                          boxShadow: settings.glowEnabled ? '0 0 12px rgba(255, 120, 197, 0.15)' : 'none'
                        }}
                      />
                    )}

                    {/* Active Gradient Pill */}
                    {isActive && (
                      <motion.div
                        layoutId="nav-active-pill"
                        transition={{ type: 'spring', stiffness: 300, damping: 25 }}
                        className="absolute inset-0 rounded-full nav-item-active"
                      />
                    )}

                    <span className="relative z-10 flex items-center gap-1.5">
                      {/* Icon with Hover upward movement */}
                      <Icon
                        className={`h-3.8 w-3.8 transition-all duration-300 ${
                          hoveredId === item.id && !isActive ? '-translate-y-0.5 text-[#ff4fa3]' : ''
                        } ${isActive ? 'text-[#ff4fa3]' : 'text-neutral-500'}`}
                      />
                      
                      {/* Text */}
                      <span className="relative">
                        {item.label}
                        
                        {/* Hover Underline effect requested (for inactive buttons) */}
                        {hoveredId === item.id && !isActive && (
                          <motion.span
                            layoutId="hover-underline"
                            className="absolute -bottom-1 left-0 right-0 h-0.5 bg-gradient-to-r from-[#ff4fa3] to-[#ff78c5]"
                            transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                          />
                        )}
                      </span>
                    </span>
                  </button>
                );
              })}
            </div>

            {/* ── RIGHT SECTION: Interactions ── */}
            <div
              id="navbar-right"
              className={`flex items-center gap-2 sm:gap-3.5 relative ${
                inspectorMode ? 'outline-dashed outline-1 outline-amber-500 hover:after:content-["cta_actions"] hover:after:absolute hover:after:-top-6 hover:after:right-0 hover:after:bg-amber-500 hover:after:text-white hover:after:text-[8px] hover:after:font-mono hover:after:px-1 hover:after:rounded' : ''
              }`}
            >
              {/* A. Search Trigger */}
              <button
                onClick={onSearchOpen}
                className="group relative rounded-full p-2 text-neutral-400 hover:bg-neutral-50 hover:text-neutral-800 transition-all duration-200"
                aria-label="Search items"
              >
                <Search className="h-4.5 w-4.5 transition-transform group-hover:scale-110" />
                <span className="absolute -top-1 -right-1 bg-neutral-900 text-white rounded px-1 text-[8px] font-mono opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow">
                  ⌘K
                </span>
              </button>

              {/* B. Notifications Trigger */}
              <div className="relative">
                <button
                  onClick={onNotificationsToggle}
                  className={`group relative rounded-full p-2 text-neutral-400 hover:bg-neutral-50 hover:text-neutral-800 transition-all duration-200 ${
                    isNotificationsOpen ? 'bg-neutral-50 text-neutral-900' : ''
                  }`}
                  aria-label="View alerts"
                >
                  <Bell className="h-4.5 w-4.5 transition-transform group-hover:rotate-12" />
                  {unreadCount > 0 && (
                    <span className="absolute top-1.5 right-1.5 flex h-2 w-2 rounded-full bg-[#ff4fa3]">
                      <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#ff78c5] opacity-75" />
                    </span>
                  )}
                </button>
              </div>

              {/* C. User profile trigger */}
              <div className="relative">
                <button
                  onClick={onProfileToggle}
                  className={`flex items-center hover:scale-105 transition-transform duration-200 rounded-full border p-0.5 ${
                    isProfileOpen ? 'border-[#ff4fa3] bg-[#ff4fa3]/5 shadow-sm' : 'border-neutral-200'
                  }`}
                >
                  <img
                    src="https://picsum.photos/seed/kashmiri/120/120"
                    alt="Kashmiri avatar"
                    className="h-7 w-7 rounded-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </button>
              </div>

              {/* D. Premium CTA Button */}
              <a
                href="#contact"
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick('contact', '#contact');
                }}
                className="hidden sm:inline-flex items-center gap-1.5 px-5 py-2.5 rounded-full text-xs font-semibold tracking-wide font-sans text-white gradient-bg shadow-sm transition-all duration-300 hover:scale-102 hover:shadow-[0_12px_24px_-8px_rgba(255,79,163,0.5)] active:scale-98"
              >
                <span>Join Waitlist</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </a>

              {/* E. Mobile Menu Toggle */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 text-neutral-500 hover:bg-neutral-50 rounded-full hover:text-neutral-900 transition-colors"
                aria-label="Toggle mobile dynamic nav menu"
              >
                {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </button>
            </div>
          </div>

          {/* 🚨 Dynamic Responsive Specs Overlay: displays only when inspectorMode is on */}
          {inspectorMode && (
            <div className="absolute -bottom-5 left-1/3 right-1/3 text-center pointer-events-none">
              <span className="inline-block bg-neutral-900 border border-neutral-800 text-[9px] font-mono text-[#ff78c5] px-2.5 py-0.5 rounded-full shadow-lg">
                Height: 72px • Gap: 24px • Backdrop-Blur: {settings.blur}px
              </span>
            </div>
          )}
        </div>
      </motion.nav>

      {/* ── MOBILE DRAWER OVERLAY ── */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="fixed inset-x-4 top-[90px] z-40 lg:hidden overflow-hidden rounded-2xl bg-white/95 backdrop-blur-xl border border-neutral-200/90 shadow-2xl p-4 flex flex-col gap-4"
          >
            {/* Header branding */}
            <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
              <div className="flex flex-col">
                <span className="text-xs font-display font-black tracking-widest text-[#ff4fa3]">
                  CONSTENTLY
                </span>
                <span className="text-[8px] font-sans font-medium text-neutral-400 mt-0.5">
                  AI Powered Content Automation
                </span>
              </div>
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="rounded-full p-1 text-neutral-400 hover:bg-neutral-50"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* List Links */}
            <div className="flex flex-col gap-1">
              {NAV_ITEMS.map((item) => {
                const isActive = activeItem === item.id;
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id, item.href)}
                    className={`flex items-center gap-3 w-full px-4 py-3 rounded-xl text-sm font-semibold text-left transition-all ${
                      isActive
                        ? 'bg-[#ff4fa3]/10 text-[#ff4fa3] border-l-4 border-[#ff4fa3]'
                        : 'text-neutral-600 hover:bg-neutral-50 hover:text-neutral-900 border-l-4 border-transparent'
                    }`}
                  >
                    <Icon className="h-4.5 w-4.5" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Footer Buttons */}
            <div className="border-t border-neutral-100 pt-3 flex flex-col gap-2">
              <button
                onClick={() => {
                  onSearchOpen();
                  setMobileMenuOpen(false);
                }}
                className="flex items-center justify-between w-full px-4 py-2.5 rounded-xl text-xs font-semibold text-neutral-500 bg-neutral-50"
              >
                <span className="flex items-center gap-2">
                  <Search className="h-4 w-4 text-neutral-400" />
                  <span>Search Docs...</span>
                </span>
                <span className="text-[10px] bg-white px-2 py-0.5 border border-neutral-250 rounded">⌘K</span>
              </button>

              <a
                href="#contact"
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick('contact', '#contact');
                }}
                className="flex items-center justify-center gap-2 w-full py-3 rounded-full text-xs font-semibold text-white gradient-bg shadow-sm"
              >
                <span>Join Content Revolution</span>
                <ArrowRight className="h-4 w-4" />
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
