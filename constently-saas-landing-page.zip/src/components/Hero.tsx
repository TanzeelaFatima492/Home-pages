/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, Play, ArrowRight, Layers, ShieldCheck, Database, Zap, Cpu } from 'lucide-react';

export default function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-[90vh] flex flex-col items-center justify-center pt-8 pb-16 overflow-hidden md:px-6 w-full"
    >
      {/* ── BACKGROUND ORNAMENTATION ── */}
      {/* 1. Futuristic Grid Overlay */}
      <div className="absolute inset-0 grid-overlay -z-10 pointer-events-none" />
      
      {/* 2. Soft Glowing Pink/Purple Radial Orbs */}
      <div className="absolute top-[10%] left-[20%] w-[400px] h-[400px] bg-gradient-to-tr from-[#ff4fa3] to-purple-600 rounded-full blur-[120px] opacity-[0.12] -z-10 pointer-events-none" />
      <div className="absolute bottom-[20%] right-[10%] w-[350px] h-[350px] bg-gradient-to-tr from-indigo-500 to-[#ff78c5] rounded-full blur-[100px] opacity-[0.1] -z-10 pointer-events-none" />

      {/* ── CENTRAL CONTROLLER ── */}
      <div className="max-w-5xl mx-auto px-4 text-center mt-6">
        
        {/* A. Elegant Premium Badge */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2, duration: 0.6 }}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white border border-neutral-200/80 shadow-[0_4px_12px_rgba(0,0,0,0.03)] mb-6 text-xs text-neutral-800 font-sans"
        >
          <span className="flex h-2 w-2 rounded-full bg-gradient-to-r from-[#ff4fa3] to-[#ff78c5] animate-ping" />
          <span className="flex h-2 w-2 rounded-full bg-gradient-to-r from-[#ff4fa3] to-[#ff78c5] absolute" />
          <span className="font-mono text-[10px] uppercase font-bold tracking-wider text-neutral-500">
            LAUNCHING V2.0 FOR ENTERPRISE
          </span>
          <span className="text-neutral-300">|</span>
          <span className="text-[#ff4fa3] font-semibold flex items-center gap-0.5">
            Learn what's new <ArrowRight className="h-3 w-3" />
          </span>
        </motion.div>

        {/* B. Display Typography */}
        <motion.h1
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.7 }}
          className="text-4xl sm:text-5xl md:text-6xl font-display font-bold tracking-tight text-neutral-900 leading-[1.08] max-w-4xl mx-auto"
        >
          The Luxury Standard for{' '}
          <span className="gradient-text tracking-tighter">AI Content Automation</span>
        </motion.h1>

        {/* C. Subheading / Tagline */}
        <motion.p
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.7 }}
          className="mt-6 text-sm sm:text-base md:text-lg text-neutral-500 font-sans font-normal max-w-2xl mx-auto leading-relaxed"
        >
          Constently is the premier orchestrating automation engine tailored for luxury brands. Build, schedule, and optimize human-quality visual copy and media channels at unmatched speed.
        </motion.p>

        {/* D. Call To Action Form */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.7 }}
          className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3 max-w-md mx-auto"
        >
          <div className="relative w-full">
            <input
              type="email"
              placeholder="Enter your executive email"
              className="w-full px-5 py-3 rounded-full bg-white border border-neutral-200 text-xs font-sans placeholder-neutral-400 outline-none focus:border-[#ff4fa3] focus:ring-1 focus:ring-[#ff4fa3] transition-colors shadow-sm"
            />
          </div>
          <button className="w-full sm:w-auto shrink-0 px-6 py-3 rounded-full text-xs font-bold text-white gradient-bg hover:shadow-lg transition-all duration-300 hover:scale-102 flex items-center justify-center gap-1">
            <span>Request Invite</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </motion.div>

        {/* E. High-End Stats Ribbon */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 200 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-14 grid grid-cols-2 sm:grid-cols-4 gap-6 sm:gap-4 max-w-3xl mx-auto border-t border-neutral-200/80 pt-8"
        >
          <div className="text-center">
            <span className="block text-2xl md:text-3xl font-display font-bold text-neutral-900">420%</span>
            <span className="block text-[10px] font-mono uppercase tracking-wider text-neutral-400 mt-1">Lead Growth</span>
          </div>
          <div className="text-center">
            <span className="block text-2xl md:text-3xl font-display font-bold text-neutral-900">$14M+</span>
            <span className="block text-[10px] font-mono uppercase tracking-wider text-neutral-400 mt-1">SaaS Revenue</span>
          </div>
          <div className="text-center">
            <span className="block text-2xl md:text-3xl font-display font-bold text-[#ff4fa3]">99.98%</span>
            <span className="block text-[10px] font-mono uppercase tracking-wider text-neutral-400 mt-1">AI Accuracy</span>
          </div>
          <div className="text-center">
            <span className="block text-2xl md:text-3xl font-display font-bold text-neutral-900">30B+</span>
            <span className="block text-[10px] font-mono uppercase tracking-wider text-neutral-400 mt-1">Words Decoded</span>
          </div>
        </motion.div>
      </div>

      {/* ── F. PREMIUM VISUAL CANVAS SHAPE (Dashboard Platform Mockup) ── */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6, duration: 0.8 }}
        className="w-full max-w-5xl px-4 mt-16 relative"
      >
        {/* Soft Shadow Base glow behind dashboard */}
        <div className="absolute inset-x-12 -top-6 bottom-12 bg-gradient-to-r from-[#ff4fa3] to-[#ff78c5] rounded-3xl blur-[40px] opacity-[0.1] -z-10" />

        {/* Glassmorphic Dashboard Body */}
        <div className="bg-white/80 rounded-2xl border border-neutral-200/80 p-3 sm:p-5 shadow-2xl backdrop-blur-md">
          {/* Dashboard Header Bar */}
          <div className="flex items-center justify-between border-b border-neutral-100 pb-3 mb-4 text-xs font-mono">
            <div className="flex items-center gap-1.5">
              <span className="h-3 w-3 rounded-full bg-rose-400" />
              <span className="h-3 w-3 rounded-full bg-amber-400" />
              <span className="h-3 w-3 rounded-full bg-emerald-400" />
            </div>
            <div className="flex items-center gap-2 rounded bg-neutral-50 px-4 py-1 text-neutral-400 text-[10px]">
              <span>https://console.constently.ai/workspace_alpha</span>
            </div>
            <div className="flex items-center gap-1 text-[#ff4fa3]">
              <Sparkles className="h-3.5 w-3.5" />
              <span className="text-[10px] font-bold uppercase tracking-wider">AI Synced</span>
            </div>
          </div>

          {/* Dummy Workspace Layout */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* Column 1: Pipeline Control */}
            <div className="rounded-xl border border-neutral-200/60 p-4 bg-neutral-50/50 flex flex-col justify-between min-h-[140px] hover:border-[#ff78c5]/40 transition-colors">
              <div>
                <span className="text-[10px] font-mono text-[#ff4fa3] uppercase font-bold tracking-wider">01 // AUTOPILOT ENGINE</span>
                <h3 className="text-sm font-semibold text-neutral-800 font-sans mt-1">Global Narratives Pipeline</h3>
              </div>
              <div className="mt-4 flex gap-2">
                <span className="h-1 bg-[#ff4fa3] rounded-full flex-1" />
                <span className="h-1 bg-[#ff4fa3] rounded-full flex-1" />
                <span className="h-1 bg-neutral-200 rounded-full flex-1" />
              </div>
              <div className="mt-2 flex justify-between items-center text-[10px] font-mono text-neutral-400">
                <span>Generating Campaign</span>
                <span className="text-[#ff4fa3] font-bold">66%</span>
              </div>
            </div>

            {/* Column 2: Performance Analyzer */}
            <div className="rounded-xl border border-neutral-200/60 p-4 bg-neutral-50/50 flex flex-col justify-between min-h-[140px] hover:border-[#ff78c5]/40 transition-colors">
              <div>
                <span className="text-[10px] font-mono text-neutral-500 uppercase font-bold tracking-wider">02 // GENERATIVE MATRIX</span>
                <h3 className="text-sm font-semibold text-neutral-800 font-sans mt-1">Interactive Content Reach</h3>
              </div>
              <div className="mt-4 flex items-end gap-1.5 h-12">
                <div className="bg-neutral-200 h-[20%] w-full rounded-sm" />
                <div className="bg-neutral-200 h-[45%] w-full rounded-sm" />
                <div className="bg-[#ff78c5]/40 h-[60%] w-full rounded-sm" />
                <div className="bg-[#ff4fa3] h-[95%] w-full rounded-sm animate-pulse" />
                <div className="bg-neutral-200 h-[50%] w-full rounded-sm" />
              </div>
              <div className="flex justify-between items-center text-[10px] font-mono text-neutral-400 mt-2">
                <span>Total Reach</span>
                <span className="font-semibold text-neutral-700">+112.4k</span>
              </div>
            </div>

            {/* Column 3: Active Agents */}
            <div className="rounded-xl border border-[#ff4fa3]/20 p-4 bg-gradient-to-tr from-[#ff4fa3]/5 to-[#ff78c5]/2 flex flex-col justify-between min-h-[140px] hover:border-[#ff4fa3]/40 transition-colors">
              <div>
                <span className="text-[10px] font-mono text-[#ff4fa3] uppercase font-bold tracking-wider flex items-center gap-1">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  03 // LIVE DEPLOYMENTS
                </span>
                <h3 className="text-sm font-semibold text-neutral-800 font-sans mt-1">Corporate Voice Agent</h3>
              </div>
              <div className="mt-4 text-[10px] font-mono text-neutral-500 italic">
                "Writing highly calibrated, SEO-optimized copy matching luxury editorial standard..."
              </div>
              <div className="mt-2 flex justify-between items-center text-[10px] font-mono text-neutral-400 border-t border-dashed border-neutral-200 pt-2">
                <span>Active Channels</span>
                <span className="text-[#ff4fa3] font-bold">9 Active Bots</span>
              </div>
            </div>
            
          </div>
        </div>
      </motion.div>
    </section>
  );
}
