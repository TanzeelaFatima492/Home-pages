/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { NavbarSettings, NotificationItem } from './types';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import FeatureSections from './components/FeatureSections';
import SettingsPanel from './components/SettingsPanel';
import SearchModal from './components/SearchModal';
import NotificationPanel from './components/NotificationPanel';
import ProfileDropdown from './components/ProfileDropdown';
import { BellRing, CheckCircle, Sparkles } from 'lucide-react';

const INITIAL_SETTINGS: NavbarSettings = {
  layout: 'capsule',
  blur: 16,
  glowEnabled: true,
  borderPinkGradient: true,
  floatingSpeed: 4,
  activeSection: 'home',
  sticky: true,
  accentGradient: 'linear-gradient(135deg, #ff4fa3 0%, #ff78c5 100%)',
  hoverPillEffect: true,
};

const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'n1',
    title: 'Autopilot Engine Engaged',
    description: 'Workspace campaign Retargeting Matrix completed successfully.',
    time: '2m ago',
    unread: true,
    type: 'success',
  },
  {
    id: 'n2',
    title: 'Model Retrained',
    description: 'Luxury voice weights retrained using spring catalog copies.',
    time: '1h ago',
    unread: true,
    type: 'info',
  },
  {
    id: 'n3',
    title: 'Trend Pool Scraped',
    description: 'Instagram luxury trends scraped. 12 content directives loaded.',
    time: '4h ago',
    unread: false,
    type: 'alert',
  },
];

export default function App() {
  const [settings, setSettings] = useState<NavbarSettings>(INITIAL_SETTINGS);
  const [inspectorMode, setInspectorMode] = useState(false);

  // States for navbar overlays
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  // Notification items state
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);

  // Scroll Spy Observer to track currently visible section
  useEffect(() => {
    const sections = ['home', 'features', 'solutions', 'pricing', 'resources', 'contact'];
    
    const observers = sections.map((id) => {
      const el = document.getElementById(id);
      if (!el) return null;

      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              setSettings((prev) => ({ ...prev, activeSection: id }));
            }
          });
        },
        {
          rootMargin: '-35% 0px -45% 0px', // Trigger when section occupies the active midpoint
        }
      );
      
      observer.observe(el);
      return { el, observer };
    });

    return () => {
      observers.forEach((pair) => {
        if (pair) {
          pair.observer.unobserve(pair.el);
        }
      });
    };
  }, []);

  // Handlers for dynamic dropdown items
  const handleMarkAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, unread: false })));
  };

  const handleClearAllNotifications = () => {
    setNotifications([]);
  };

  // Safe navigation handler inside search
  const handleNavigateFromSearch = (sectionId: string) => {
    setSettings((prev) => ({ ...prev, activeSection: sectionId }));
    const target = document.getElementById(sectionId);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="min-h-screen mesh-gradient-bg text-neutral-800 overflow-x-hidden selection:bg-[#ff78c5]/20 selection:text-[#ff4fa3]">
      
      {/* Dynamic Background Layout Grids */}
      <div className="absolute top-0 inset-x-0 h-[640px] bg-gradient-to-b from-white via-slate-50/50 to-transparent pointer-events-none -z-10" />

      {/* ── PREMIUM FLOATING GLASS NAVIGATION SYSTEM ── */}
      <div className="relative">
        <Navbar
          settings={settings}
          setSettings={setSettings}
          inspectorMode={inspectorMode}
          onSearchOpen={() => setIsSearchOpen(true)}
          notifications={notifications}
          onNotificationsToggle={() => {
            setIsNotificationsOpen(!isNotificationsOpen);
            setIsProfileOpen(false); // Close Profile Dropdown
          }}
          isNotificationsOpen={isNotificationsOpen}
          onProfileToggle={() => {
            setIsProfileOpen(!isProfileOpen);
            setIsNotificationsOpen(false); // Close Notification Tray
          }}
          isProfileOpen={isProfileOpen}
        />

        {/* Floating Absolute Overlays triggered relative to the Navbar */}
        <div className="max-w-7xl mx-auto px-4 md:px-8 relative">
          <div className="relative">
            {/* Notification drop */}
            <NotificationPanel
              notifications={notifications}
              isOpen={isNotificationsOpen}
              onMarkAllRead={handleMarkAllNotificationsRead}
              onClearAll={handleClearAllNotifications}
              onClose={() => setIsNotificationsOpen(false)}
            />

            {/* Profile Dropdown panel */}
            <ProfileDropdown
              isOpen={isProfileOpen}
              onClose={() => setIsProfileOpen(false)}
              userEmail="kashmirirajpoot128@gmail.com"
            />
          </div>
        </div>
      </div>

      {/* ── CENTRAL VISUAL LANDING PAGE CORE ── */}
      <main className="relative">
        {/* Hero Section of Startup */}
        <Hero />

        {/* Features, Solutions, Pricing, Resources, Contact and footer templates */}
        <FeatureSections />
      </main>

      {/* ── FLOATING LAB CUSTOMIZER PANEL ── */}
      <SettingsPanel
        settings={settings}
        setSettings={setSettings}
        inspectorMode={inspectorMode}
        setInspectorMode={setInspectorMode}
      />

      {/* ── COMMAND K SEARCH MODAL OVERLAY ── */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onNavigate={handleNavigateFromSearch}
      />

      {/* Live notification ribbon overlay at bottom-left */}
      <div className="fixed bottom-6 left-6 z-40 hidden sm:flex items-center gap-2.5 rounded-full bg-white border border-neutral-100 px-4 py-2 shadow-xl backdrop-blur-md hover:scale-102 transition-transform cursor-pointer">
        <span className="flex h-2.5 w-2.5 rounded-full bg-gradient-to-r from-[#ff4fa3] to-[#ff78c5] animate-pulse" />
        <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-neutral-500">
          DESIGN LAB ACTIVE
        </span>
      </div>
    </div>
  );
}
