import React, { createContext, useState, ReactNode, FC } from 'react';
import type { Product, WishlistContextType } from '../types';

export const WishlistContext = createContext<WishlistContextType | undefined>(undefined);

export const WishlistProvider: FC<{ children: ReactNode }> = ({ children }) => {
  const [wishlist, setWishlist] = useState<Product[]>([]);

  const addToWishlist = (product: Product) => {
    setWishlist((prevWishlist) => {
      if (prevWishlist.find((item) => item.id === product.id)) {
        return prevWishlist;
      }
      return [...prevWishlist, product];
    });
  };

  const removeFromWishlist = (productId: number) => {
    setWishlist((prevWishlist) => prevWishlist.filter((item) => item.id !== productId));
  };
  
  const isInWishlist = (productId: number) => {
    return wishlist.some(item => item.id === productId);
  };

  const getItemCount = () => {
    return wishlist.length;
  };

  return (
    <WishlistContext.Provider
      value={{ wishlist, addToWishlist, removeFromWishlist, isInWishlist, getItemCount }}
    >
      {children}
    </WishlistContext.Provider>
  );
};
