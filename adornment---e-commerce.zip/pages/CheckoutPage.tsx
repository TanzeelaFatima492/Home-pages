
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../hooks/useCart';

const CheckoutPage: React.FC = () => {
  const { cart, clearCart } = useCart();
  const navigate = useNavigate();
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shipping = 250;
  const total = subtotal + shipping;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, you would process the payment and order here.
    clearCart();
    navigate('/confirmation');
  };

  if (cart.length === 0) {
      // Redirect to home if cart is empty
      React.useEffect(() => {
          navigate('/');
      }, [navigate]);
      return null;
  }

  return (
    <div className="container mx-auto px-6 py-12">
      <h1 className="text-4xl font-bold text-center text-text-dark mb-8">Checkout 📦</h1>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div className="bg-white p-8 rounded-lg shadow-lg">
          <h2 className="text-2xl font-bold mb-6">Shipping Information</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">Full Name</label>
              <input type="text" id="name" required className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-accent focus:border-accent sm:text-sm p-2" />
            </div>
            <div>
              <label htmlFor="address" className="block text-sm font-medium text-gray-700">Address</label>
              <input type="text" id="address" required className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-accent focus:border-accent sm:text-sm p-2" />
            </div>
            <div>
              <label htmlFor="city" className="block text-sm font-medium text-gray-700">City</label>
              <input type="text" id="city" required className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-accent focus:border-accent sm:text-sm p-2" />
            </div>
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700">Phone Number</label>
              <input type="tel" id="phone" required className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-accent focus:border-accent sm:text-sm p-2" />
            </div>
            <div className="pt-4">
                <h3 className="text-lg font-medium text-gray-900">Payment Method</h3>
                <div className="mt-4">
                    <div className="flex items-center">
                        <input id="cod" name="payment-method" type="radio" defaultChecked className="focus:ring-accent h-4 w-4 text-accent border-gray-300"/>
                        <label htmlFor="cod" className="ml-3 block text-sm font-medium text-gray-700">Cash on Delivery (COD)</label>
                    </div>
                </div>
            </div>
            <button type="submit" className="w-full bg-accent text-white font-bold py-3 mt-6 rounded-md hover:bg-opacity-80 transition-all duration-300">
              Place Order
            </button>
          </form>
        </div>
        <div className="bg-white p-8 rounded-lg shadow-lg h-fit">
          <h2 className="text-2xl font-bold mb-6">Your Order</h2>
          <div className="space-y-4">
            {cart.map(item => (
              <div key={item.id} className="flex justify-between items-center">
                <div className="flex items-center">
                  <img src={item.image} alt={item.name} className="w-12 h-12 rounded-md mr-4" />
                  <div>
                    <p className="font-semibold">{item.name}</p>
                    <p className="text-sm text-gray-500">Qty: {item.quantity}</p>
                  </div>
                </div>
                <p>PKR {(item.price * item.quantity).toLocaleString()}</p>
              </div>
            ))}
          </div>
          <div className="mt-6 pt-6 border-t space-y-2">
            <div className="flex justify-between">
              <p>Subtotal:</p>
              <p>PKR {subtotal.toLocaleString()}</p>
            </div>
            <div className="flex justify-between">
              <p>Shipping:</p>
              <p>PKR {shipping.toLocaleString()}</p>
            </div>
            <div className="flex justify-between font-bold text-lg pt-2">
              <p>Total:</p>
              <p>PKR {total.toLocaleString()}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;
