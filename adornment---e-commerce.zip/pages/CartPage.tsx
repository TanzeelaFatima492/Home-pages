
import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../hooks/useCart';
import { TrashIcon, PlusIcon, MinusIcon } from '../constants';
import type { CartItem } from '../types';

const CartItemRow: React.FC<{ item: CartItem }> = ({ item }) => {
  const { updateQuantity, removeFromCart } = useCart();
  return (
    <div className="flex items-center justify-between py-4 border-b">
        <div className="flex items-center w-2/5 sm:w-1/2">
            <img src={item.image} alt={item.name} className="w-16 h-16 sm:w-20 sm:h-20 object-cover rounded-md mr-4" />
            <div>
                <h3 className="font-semibold text-text-dark text-sm sm:text-base">{item.name}</h3>
                <p className="text-text-light text-xs sm:text-sm">PKR {item.price.toLocaleString()}</p>
            </div>
        </div>
        <div className="flex items-center border rounded-md w-1/4 sm:w-1/6 justify-center">
            <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="p-1 sm:p-2 hover:bg-gray-100"><MinusIcon className="w-4 h-4" /></button>
            <span className="px-2 sm:px-4 font-bold text-sm sm:text-base">{item.quantity}</span>
            <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="p-1 sm:p-2 hover:bg-gray-100"><PlusIcon className="w-4 h-4" /></button>
        </div>
        <p className="font-bold w-1/5 sm:w-1/6 text-center text-sm sm:text-base">PKR {(item.price * item.quantity).toLocaleString()}</p>
        <button onClick={() => removeFromCart(item.id)} className="text-red-500 hover:text-red-700 w-auto sm:w-1/12 text-center">
            <TrashIcon className="w-5 h-5 inline" />
        </button>
    </div>
  );
};

const CartPage: React.FC = () => {
  const { cart } = useCart();
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shipping = 250; // Flat rate for Pakistan
  const total = subtotal + shipping;

  if (cart.length === 0) {
    return (
      <div className="container mx-auto text-center py-20">
        <h2 className="text-3xl font-bold mb-4">Your Cart is Empty 🛒</h2>
        <p className="text-text-light mb-8">Looks like you haven't added anything to your cart yet.</p>
        <Link to="/products" className="bg-accent text-white font-bold py-3 px-8 rounded-full hover:bg-opacity-80 transition-all duration-300">
          Start Shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 sm:px-6 py-12">
      <h1 className="text-4xl font-bold text-center text-text-dark mb-8">Your Shopping Cart</h1>
      <div className="bg-white rounded-lg shadow-lg p-4 sm:p-6">
        <div className="hidden sm:flex items-center justify-between font-bold text-text-light border-b pb-4 mb-4">
            <p className="w-1/2">Product</p>
            <p className="w-1/6 text-center">Quantity</p>
            <p className="w-1/6 text-center">Total</p>
            <p className="w-1/12 text-center">Remove</p>
        </div>
        {cart.map(item => <CartItemRow key={item.id} item={item} />)}
        <div className="mt-8 flex flex-col md:flex-row justify-between items-start">
            <div className="w-full md:w-1/2 mb-6 md:mb-0">
                <h3 className="text-lg font-semibold mb-2">Have a coupon?</h3>
                <div className="flex">
                    <input type="text" placeholder="Enter coupon code" className="border rounded-l-md p-2 w-full focus:ring-accent focus:border-accent" />
                    <button className="bg-primary text-accent font-bold px-4 rounded-r-md hover:bg-accent hover:text-white transition-colors">Apply</button>
                </div>
            </div>
            <div className="w-full md:w-2/5">
                <div className="bg-secondary/50 p-6 rounded-lg">
                    <h2 className="text-xl font-bold mb-4">Order Summary</h2>
                    <div className="flex justify-between mb-2">
                        <p>Subtotal:</p>
                        <p>PKR {subtotal.toLocaleString()}</p>
                    </div>
                    <div className="flex justify-between mb-4">
                        <p>Shipping:</p>
                        <p>PKR {shipping.toLocaleString()}</p>
                    </div>
                    <div className="flex justify-between font-bold text-lg border-t pt-4">
                        <p>Total:</p>
                        <p>PKR {total.toLocaleString()}</p>
                    </div>
                    <Link to="/checkout">
                        <button className="w-full bg-accent text-white font-bold py-3 mt-6 rounded-md hover:bg-opacity-80 transition-all duration-300">
                            Proceed to Checkout
                        </button>
                    </Link>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default CartPage;
