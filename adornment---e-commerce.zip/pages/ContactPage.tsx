
import React from 'react';

const ContactPage: React.FC = () => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert("Thank you for your message! We'll get back to you soon. 😊");
  };

  return (
    <div className="container mx-auto px-6 py-12">
      <h1 className="text-4xl font-bold text-center text-text-dark mb-8">Get In Touch 💌</h1>
      <p className="text-center text-text-light max-w-2xl mx-auto mb-12">
        Have a question, a comment, or just want to say hi? We'd love to hear from you! Fill out the form below or reach out to us through our social channels.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="bg-white p-8 rounded-lg shadow-lg">
          <h2 className="text-2xl font-bold mb-6">Send us a Message</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">Your Name</label>
              <input type="text" id="name" required className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-accent focus:border-accent sm:text-sm p-2" />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">Your Email</label>
              <input type="email" id="email" required className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-accent focus:border-accent sm:text-sm p-2" />
            </div>
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-700">Message</label>
              <textarea id="message" rows={4} required className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-accent focus:border-accent sm:text-sm p-2"></textarea>
            </div>
            <button type="submit" className="w-full bg-accent text-white font-bold py-3 mt-4 rounded-md hover:bg-opacity-80 transition-all duration-300">
              Send Message
            </button>
          </form>
        </div>
        <div className="space-y-6">
          <div className="bg-white p-8 rounded-lg shadow-lg">
            <h3 className="text-xl font-bold mb-2">Email Us</h3>
            <p className="text-accent">hello@adornment.pk</p>
          </div>
          <div className="bg-white p-8 rounded-lg shadow-lg">
            <h3 className="text-xl font-bold mb-2">Follow Us on Social Media</h3>
            <p className="text-text-light">Find us on Instagram and Facebook for updates, new products, and behind-the-scenes content!</p>
            <p className="text-accent mt-2">@adornment.pk</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;
