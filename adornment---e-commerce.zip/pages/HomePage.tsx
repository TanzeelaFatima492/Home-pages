
import React from 'react';
import { Link } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import { products } from '../data/products';

const HeroSection: React.FC = () => (
  <div className="bg-primary">
    <div className="container mx-auto px-6 py-16 md:py-24 text-center">
      <h1 className="text-4xl md:text-6xl font-bold text-white mb-4 leading-tight">Adorn Your Reading Moments 📚</h1>
      <p className="text-lg md:text-xl text-white/90 mb-8">
        Discover handcrafted treasures that add a touch of magic to your everyday.
      </p>
      <Link
        to="/products"
        className="bg-accent text-white font-bold py-3 px-8 rounded-full hover:bg-white hover:text-accent transition-all duration-300 transform hover:scale-105"
      >
        Shop Now
      </Link>
    </div>
  </div>
);

const FeaturedProducts: React.FC = () => {
  const featured = products.slice(0, 3);
  return (
    <div className="container mx-auto px-6 py-16">
      <h2 className="text-3xl font-bold text-center text-text-dark mb-8">Featured Products ✨</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {featured.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
};

const HomePage: React.FC = () => {
  return (
    <div>
      <HeroSection />
      <FeaturedProducts />
    </div>
  );
};

export default HomePage;
