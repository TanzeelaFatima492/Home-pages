
import React from 'react';

const AboutPage: React.FC = () => {
  return (
    <div className="bg-white">
      <div className="container mx-auto px-6 py-16">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-accent mb-4">About Adornment ✨</h1>
          <p className="text-lg text-text-light mb-8">
            Adorning your everyday moments with a touch of elegance and joy.
          </p>
        </div>
        <div className="max-w-4xl mx-auto mt-10 text-text-dark space-y-6 text-left">
          <p>
            Welcome to Adornment, your little corner of the internet for beautifully crafted goods. Based in the heart of Pakistan, we are a small team passionate about creating items that bring a smile to your face. From the page of your favorite book to the sip of your morning coffee, we believe that beauty lies in the details. 💖
          </p>
          <p>
            Our journey began with a simple idea: to create high-quality, aesthetically pleasing products that people would love to own and gift. We started with bookmarks, for the avid readers who deserve something special to mark their literary adventures. 📚 Then came our magnetic bookmarks - tiny, mighty companions that never let you lose your spot.
          </p>
          <p>
            And now, we're thrilled to introduce our glass tumblers! 🥤 Perfect for your iced teas, coffees, or just water, they are designed to make your hydration moments a little more stylish.
          </p>
          <p>
            Everything at Adornment is made with love, care, and a keen eye for detail. We are proud to be a Pakistani brand and are so grateful for every single customer who supports our dream. Thank you for being here!
          </p>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;
