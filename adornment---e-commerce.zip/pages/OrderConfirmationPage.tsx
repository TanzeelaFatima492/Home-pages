
import React from 'react';
import { Link } from 'react-router-dom';

const OrderConfirmationPage: React.FC = () => {
  return (
    <div className="container mx-auto text-center py-20 px-6">
      <div className="bg-white p-10 rounded-lg shadow-lg max-w-2xl mx-auto">
        <h1 className="text-4xl font-bold text-accent mb-4">Thank You! 🎉</h1>
        <p className="text-lg text-text-dark mb-6">Your order has been placed successfully.</p>
        <p className="text-text-light mb-8">
          We've received your order and will begin processing it right away. You will receive an email confirmation shortly.
          For Cash on Delivery orders, please have the exact amount ready.
        </p>
        <Link 
          to="/products" 
          className="bg-primary text-accent font-bold py-3 px-8 rounded-full hover:bg-accent hover:text-white transition-all duration-300"
        >
          Continue Shopping
        </Link>
      </div>
    </div>
  );
};

export default OrderConfirmationPage;
