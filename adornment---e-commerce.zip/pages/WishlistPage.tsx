import React from 'react';
import { Link } from 'react-router-dom';
import { useWishlist } from '../hooks/useWishlist';
import ProductCard from '../components/ProductCard';

const WishlistPage: React.FC = () => {
  const { wishlist } = useWishlist();

  if (wishlist.length === 0) {
    return (
      <div className="container mx-auto text-center py-20 px-6">
        <div className="bg-white p-10 rounded-lg shadow-lg max-w-2xl mx-auto">
            <h2 className="text-3xl font-bold mb-4">Your Wishlist is Empty ❤️</h2>
            <p className="text-text-light mb-8">Looks like you haven't added anything you love yet. Click the heart on any product to save it here!</p>
            <Link to="/products" className="bg-accent text-white font-bold py-3 px-8 rounded-full hover:bg-opacity-80 transition-all duration-300">
            Find Your Favorites
            </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-6 py-12">
      <h1 className="text-4xl font-bold text-center text-text-dark mb-8">My Wishlist</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
        {wishlist.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
};

export default WishlistPage;
