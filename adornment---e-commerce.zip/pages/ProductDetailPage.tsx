import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { products } from '../data/products';
import { useCart } from '../hooks/useCart';
import { useWishlist } from '../hooks/useWishlist';
import { PlusIcon, MinusIcon, HeartIcon, StarIcon } from '../constants';
import type { Review } from '../types';


const ProductDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  const [quantity, setQuantity] = useState(1);
  
  const productData = products.find(p => p.id === parseInt(id || ''));
  const [product, setProduct] = useState(productData);

  const [newReview, setNewReview] = useState({ author: '', rating: 0, comment: '' });
  const [hoverRating, setHoverRating] = useState(0);

  if (!product) {
    return (
      <div className="container mx-auto text-center py-20">
        <h2 className="text-2xl font-bold">Product not found 😥</h2>
        <Link to="/products" className="text-accent hover:underline mt-4 inline-block">Back to Products</Link>
      </div>
    );
  }
  
  const isWished = isInWishlist(product.id);

  const handleWishlistToggle = () => {
    if (isWished) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
  };

  const handleAddToCart = () => {
    addToCart(product, quantity);
  };
  
  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newReview.comment && newReview.author && newReview.rating > 0) {
      const reviewToAdd: Review = {
        id: Date.now(),
        ...newReview,
      };
      // Simulate adding review
      const updatedReviews = [...(product.reviews || []), reviewToAdd];
      setProduct({ ...product, reviews: updatedReviews });
      // Reset form
      setNewReview({ author: '', rating: 0, comment: '' });
      setHoverRating(0);
    }
  };


  return (
    <div className="container mx-auto px-6 py-12">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-start">
        <div>
          <img src={product.image} alt={product.name} className="w-full h-auto rounded-lg shadow-lg" />
        </div>
        <div>
          <h1 className="text-4xl font-bold text-text-dark mb-4">{product.name}</h1>
          <p className="text-3xl font-bold text-accent mb-4">PKR {product.price.toLocaleString()}</p>
          
          {product.rating && (
            <div className="flex items-center mb-4">
              {[...Array(5)].map((_, i) => (
                <StarIcon key={i} className={`w-5 h-5 ${i < Math.round(product.rating!) ? 'text-yellow-400' : 'text-gray-300'}`} />
              ))}
              <a href="#reviews" className="text-sm text-gray-600 ml-2 hover:underline">({product.reviews?.length || 0} reviews)</a>
            </div>
          )}
          
          <p className="text-text-light mb-8">{product.description}</p>
          
          <div className="flex items-center space-x-4 mb-8">
            <span className="font-semibold">Quantity:</span>
            <div className="flex items-center border rounded-md">
              <button onClick={() => setQuantity(q => Math.max(1, q - 1))} className="p-2 hover:bg-gray-100"><MinusIcon className="w-4 h-4" /></button>
              <span className="px-4 font-bold">{quantity}</span>
              <button onClick={() => setQuantity(q => q + 1)} className="p-2 hover:bg-gray-100"><PlusIcon className="w-4 h-4" /></button>
            </div>
          </div>

          <div className="flex items-stretch space-x-4">
            <button
              onClick={handleAddToCart}
              className="flex-grow bg-primary text-accent font-bold py-3 px-6 rounded-md hover:bg-accent hover:text-white transition-colors duration-300 text-lg"
            >
              Add to Cart 🛒
            </button>
            <button
              onClick={handleWishlistToggle}
              className="p-3 border-2 rounded-md hover:border-accent transition-colors"
              aria-label={isWished ? 'Remove from wishlist' : 'Add to wishlist'}
            >
              <HeartIcon className="w-6 h-6 text-accent" fill={isWished ? 'currentColor' : 'none'} />
            </button>
          </div>
        </div>
      </div>

      <div id="reviews" className="mt-16 pt-10 border-t">
        <h2 className="text-3xl font-bold text-text-dark mb-8 text-center">Reviews & Ratings</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="space-y-6 max-h-96 overflow-y-auto pr-4">
            {product.reviews && product.reviews.length > 0 ? (
              product.reviews.map(review => (
                <div key={review.id} className="bg-white p-6 rounded-lg shadow-sm">
                  <div className="flex items-center mb-2">
                    {[...Array(5)].map((_, i) => (
                      <StarIcon key={i} className={`w-4 h-4 ${i < review.rating ? 'text-yellow-400' : 'text-gray-300'}`} />
                    ))}
                    <h4 className="font-bold text-text-dark ml-3">{review.author}</h4>
                  </div>
                  <p className="text-text-light">{review.comment}</p>
                </div>
              ))
            ) : (
              <p className="text-center text-text-light mt-4">No reviews yet. Be the first to review this product!</p>
            )}
          </div>
          <div className="bg-white p-8 rounded-lg shadow-lg h-fit">
            <h3 className="text-2xl font-bold mb-6">Write a Review</h3>
            <form onSubmit={handleReviewSubmit} className="space-y-4">
              <div>
                <label htmlFor="author" className="block text-sm font-medium text-gray-700">Your Name</label>
                <input type="text" id="author" value={newReview.author} onChange={e => setNewReview({...newReview, author: e.target.value})} required className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-accent focus:border-accent sm:text-sm p-2" />
              </div>
              <div >
                <label className="block text-sm font-medium text-gray-700">Your Rating</label>
                <div className="flex items-center mt-1">
                  {[...Array(5)].map((_, i) => (
                    <StarIcon
                      key={i}
                      className={`w-6 h-6 cursor-pointer ${ (hoverRating || newReview.rating) > i ? 'text-yellow-400' : 'text-gray-300'}`}
                      onClick={() => setNewReview({...newReview, rating: i + 1})}
                      onMouseEnter={() => setHoverRating(i + 1)}
                      onMouseLeave={() => setHoverRating(0)}
                    />
                  ))}
                </div>
              </div>
              <div>
                <label htmlFor="comment" className="block text-sm font-medium text-gray-700">Your Review</label>
                <textarea id="comment" value={newReview.comment} onChange={e => setNewReview({...newReview, comment: e.target.value})} rows={4} required className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-accent focus:border-accent sm:text-sm p-2"></textarea>
              </div>
              <button type="submit" className="w-full bg-accent text-white font-bold py-3 mt-2 rounded-md hover:bg-opacity-80 transition-all duration-300">
                Submit Review
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailPage;
