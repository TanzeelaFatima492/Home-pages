
import React, { useState } from 'react';
import ProductCard from '../components/ProductCard';
import { products } from '../data/products';
import type { Product } from '../types';

const ProductsPage: React.FC = () => {
  const [filter, setFilter] = useState<string>('All');
  const categories = ['All', ...Array.from(new Set(products.map(p => p.category)))];

  const filteredProducts = filter === 'All'
    ? products
    : products.filter(p => p.category === filter);

  return (
    <div className="container mx-auto px-6 py-12">
      <h1 className="text-4xl font-bold text-center text-text-dark mb-8">Our Collection 🛍️</h1>
      
      <div className="flex justify-center mb-8 space-x-2 md:space-x-4">
        {categories.map(category => (
          <button
            key={category}
            onClick={() => setFilter(category)}
            className={`px-4 py-2 rounded-full font-semibold transition-colors duration-300 ${
              filter === category
                ? 'bg-accent text-white'
                : 'bg-white text-text-dark hover:bg-primary/50'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
        {filteredProducts.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
};

export default ProductsPage;
