import React from 'react';
import { Link } from 'react-router-dom';
import type { Product } from '../types';
import { useCart } from '../hooks/useCart';
import { useWishlist } from '../hooks/useWishlist';
import { HeartIcon, StarIcon } from '../constants';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();

  const isWished = isInWishlist(product.id);

  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent link navigation
    if (isWished) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden transform hover:-translate-y-1 transition-all duration-300 group relative">
      <button
        onClick={handleWishlistToggle}
        className="absolute top-3 right-3 bg-white/70 rounded-full p-2 z-10 hover:bg-white transition-colors"
        aria-label={isWished ? 'Remove from wishlist' : 'Add to wishlist'}
      >
        <HeartIcon className="w-5 h-5 text-accent" fill={isWished ? 'currentColor' : 'none'} />
      </button>
      <Link to={`/product/${product.id}`} className="block">
        <img src={product.image} alt={product.name} className="w-full h-56 object-cover" />
      </Link>
      <div className="p-4 flex flex-col">
        <h3 className="text-lg font-semibold text-text-dark mb-1 h-14 flex-grow">{product.name}</h3>
        {product.rating && (
          <div className="flex items-center mb-2">
            {[...Array(5)].map((_, i) => (
              <StarIcon key={i} className={`w-4 h-4 ${i < Math.round(product.rating!) ? 'text-yellow-400' : 'text-gray-300'}`} />
            ))}
            <span className="text-xs text-gray-500 ml-1">({product.reviews?.length || 0})</span>
          </div>
        )}
        <p className="text-accent font-bold text-xl mb-4">PKR {product.price.toLocaleString()}</p>
        <button
          onClick={() => addToCart(product)}
          className="w-full bg-primary text-accent font-bold py-2 px-4 rounded-md hover:bg-accent hover:text-white transition-colors duration-300 mt-auto"
        >
          Add to Cart 🛒
        </button>
      </div>
    </div>
  );
};

export default ProductCard;
