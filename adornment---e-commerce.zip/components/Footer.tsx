
import React from 'react';
import { Link } from 'react-router-dom';
import NewsletterSignup from './NewsletterSignup';

const Footer: React.FC = () => {
  return (
    <>
      <NewsletterSignup />
      <footer className="bg-secondary border-t border-primary/50">
        <div className="container mx-auto px-6 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-xl font-bold text-accent mb-4">Adornment ✨</h3>
              <p className="text-text-light">
                Beautifully crafted bookmarks, tumblers, and more to adorn your moments. Made with ❤️ in Pakistan.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-text-dark mb-4">Quick Links</h3>
              <ul>
                <li><Link to="/" className="text-text-light hover:text-accent">Home</Link></li>
                <li><Link to="/products" className="text-text-light hover:text-accent">Products</Link></li>
                <li><Link to="/about" className="text-text-light hover:text-accent">About Us</Link></li>
                <li><Link to="/contact" className="text-text-light hover:text-accent">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-text-dark mb-4">Follow Us</h3>
              <div className="flex space-x-4">
                <a href="#" className="text-text-light hover:text-accent">Facebook</a>
                <a href="#" className="text-text-light hover:text-accent">Instagram</a>
                <a href="#" className="text-text-light hover:text-accent">Pinterest</a>
              </div>
            </div>
          </div>
          <div className="mt-8 pt-4 border-t border-primary/50 text-center text-text-light">
            <p>&copy; {new Date().getFullYear()} Adornment. All Rights Reserved.</p>
          </div>
        </div>
      </footer>
    </>
  );
};

export default Footer;