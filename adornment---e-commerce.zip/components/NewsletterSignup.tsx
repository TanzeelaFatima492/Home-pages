import React, { useState } from 'react';

const NewsletterSignup: React.FC = () => {
  const [email, setEmail] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      alert(`Thank you for subscribing with ${email}! 💖`);
      setEmail('');
    }
  };

  return (
    <div className="bg-highlight py-12 mt-16">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-3xl font-bold text-accent mb-2">Stay in the Loop ✨</h2>
        <p className="text-text-light mb-6 max-w-lg mx-auto">
          Get the latest on new arrivals, special offers, and more from Adornment.
        </p>
        <form onSubmit={handleSubmit} className="max-w-md mx-auto flex shadow-md rounded-md">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Your email address"
            required
            className="w-full p-3 rounded-l-md border-gray-300 focus:ring-accent focus:border-accent"
            aria-label="Email address for newsletter"
          />
          <button
            type="submit"
            className="bg-accent text-white font-bold py-3 px-6 rounded-r-md hover:bg-opacity-80 transition-colors"
          >
            Subscribe
          </button>
        </form>
      </div>
    </div>
  );
};

export default NewsletterSignup;
