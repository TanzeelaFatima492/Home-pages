import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../hooks/useCart';
import { useWishlist } from '../hooks/useWishlist';
import { ShoppingCartIcon, HeartIcon } from '../constants';

const Header: React.FC = () => {
  const { getItemCount: getCartItemCount } = useCart();
  const { getItemCount: getWishlistItemCount } = useWishlist();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const cartItemCount = getCartItemCount();
  const wishlistItemCount = getWishlistItemCount();

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Products', path: '/products' },
    { name: 'About Us', path: '/about' },
    { name: 'Contact', path: '/contact' },
  ];

  return (
    <header className="bg-secondary/80 backdrop-blur-sm sticky top-0 z-50 shadow-md">
      <div className="container mx-auto px-6 py-4 flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold text-accent">
          Adornment ✨
        </Link>
        <nav className="hidden md:flex items-center space-x-8">
          {navLinks.map((link) => (
            <Link key={link.name} to={link.path} className="text-text-dark hover:text-accent transition duration-300">
              {link.name}
            </Link>
          ))}
        </nav>
        <div className="flex items-center space-x-4">
            <Link to="/wishlist" className="relative text-text-dark hover:text-accent transition duration-300">
                <HeartIcon className="h-6 w-6" />
                {wishlistItemCount > 0 && (
                    <span className="absolute -top-2 -right-2 bg-accent text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {wishlistItemCount}
                    </span>
                )}
            </Link>
            <Link to="/cart" className="relative text-text-dark hover:text-accent transition duration-300">
                <ShoppingCartIcon className="h-6 w-6" />
                {cartItemCount > 0 && (
                    <span className="absolute -top-2 -right-2 bg-accent text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {cartItemCount}
                    </span>
                )}
            </Link>
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden text-text-dark focus:outline-none"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7"></path>
              </svg>
            </button>
        </div>
      </div>
      {isMenuOpen && (
        <div className="md:hidden bg-secondary">
          <nav className="flex flex-col items-center py-4 space-y-4">
          {navLinks.map((link) => (
            <Link key={link.name} to={link.path} onClick={() => setIsMenuOpen(false)} className="text-text-dark hover:text-accent transition duration-300">
              {link.name}
            </Link>
          ))}
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
