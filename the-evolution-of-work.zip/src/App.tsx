/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef } from "react";
import { motion, useScroll, useTransform } from "motion/react";
import { Hammer, Keyboard, Monitor, Code, ArrowRight, MousePointer2 } from "lucide-react";
import { cn } from "./lib/utils";

const SECTIONS = [
  {
    id: "intro",
    title: "The Evolution of Work",
    subtitle: "A journey through human productivity",
    icon: null,
    color: "bg-[#f5f5f0]",
    textColor: "text-[#4a4a40]",
    accent: "border-[#5a5a40]",
    description: "Scroll to begin the journey through time.",
    theme: "sepia",
  },
  {
    id: "manual",
    title: "The Manual Era",
    subtitle: "Strength & Craft",
    icon: Hammer,
    color: "bg-[#e8e4d9]",
    textColor: "text-[#5d4037]",
    accent: "border-[#8d6e63]",
    description: "For centuries, work was defined by physical labor. Tools like the hammer were extensions of human muscle, building the foundations of civilization one strike at a time.",
    theme: "sepia",
    tool: "Hammer",
  },
  {
    id: "mechanical",
    title: "The Mechanical Era",
    subtitle: "Precision & Scale",
    icon: Keyboard,
    color: "bg-[#d7ccc8]",
    textColor: "text-[#3e2723]",
    accent: "border-[#5d4037]",
    description: "The industrial revolution shifted focus to machines. The typewriter transformed communication, bringing standardized precision to the written word and accelerating the pace of business.",
    theme: "vintage",
    tool: "Typewriter",
  },
  {
    id: "digital",
    title: "The Digital Era",
    subtitle: "Logic & Information",
    icon: Monitor,
    color: "bg-[#e3f2fd]",
    textColor: "text-[#0d47a1]",
    accent: "border-[#1976d2]",
    description: "Computers redefined the landscape again. Physical tools became digital interfaces. Information became the primary currency, and the world shrunk as connectivity exploded.",
    theme: "modern",
    tool: "Computer",
  },
  {
    id: "automation",
    title: "The Automation Era",
    subtitle: "Code & Intelligence",
    icon: Code,
    color: "bg-[#0a0a0a]",
    textColor: "text-[#00ff41]",
    accent: "border-[#00ff41]",
    description: "Today, we don't just use tools; we build systems that work for us. React and modern automation allow us to transition from manual clicks to automated intelligence.",
    theme: "cyberpunk",
    tool: "React Code",
  },
  {
    id: "cta",
    title: "Evolve Your Business",
    subtitle: "From Manual to Automated",
    icon: null,
    color: "bg-white",
    textColor: "text-black",
    accent: "border-black",
    description: "Work has evolved, and your business should too. I help modern companies transition from 'manual' processes to 'automated' React applications.",
    theme: "minimal",
  },
];

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
  });

  // Map vertical scroll to horizontal translation
  const x = useTransform(scrollYProgress, [0, 1], ["0%", `-${(SECTIONS.length - 1) * 100}%`]);

  return (
    <main className="relative bg-neutral-900">
      {/* Scrollable container that provides height for vertical scrolling */}
      <div ref={containerRef} className="h-[600vh] relative">
        {/* Sticky container for horizontal content */}
        <div className="sticky top-0 h-screen overflow-hidden flex items-center">
          <motion.div style={{ x }} className="flex h-full w-full">
            {SECTIONS.map((section, index) => (
              // @ts-expect-error - key is handled by React
              <Section key={section.id} section={section} index={index} />
            ))}
          </motion.div>
        </div>
      </div>

      {/* Progress Indicator */}
      <div className="fixed bottom-8 left-1/2 -translate-x-1/2 flex gap-2 z-50">
        {SECTIONS.map((_, i) => (
          <motion.div
            key={i}
            className="h-1 rounded-full bg-white/20"
            style={{
              width: 24,
              backgroundColor: useTransform(
                scrollYProgress,
                [i / (SECTIONS.length - 1) - 0.05, i / (SECTIONS.length - 1), i / (SECTIONS.length - 1) + 0.05],
                ["rgba(255,255,255,0.2)", "rgba(255,255,255,1)", "rgba(255,255,255,0.2)"]
              ),
            }}
          />
        ))}
      </div>

      {/* Scroll Hint */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="fixed bottom-8 right-8 flex items-center gap-2 text-white/50 text-sm font-mono"
      >
        <span>SCROLL</span>
        <MousePointer2 className="w-4 h-4 animate-bounce" />
      </motion.div>
    </main>
  );
}

function Section({ section, index }: { section: any; index: number }) {
  const Icon = section.icon;

  return (
    <section
      className={cn(
        "min-w-full h-full flex flex-col items-center justify-center relative px-8 md:px-24 overflow-hidden",
        section.color,
        section.textColor
      )}
    >
      {/* Parallax Background Elements */}
      <ParallaxBackground theme={section.theme} />

      <div className="max-w-4xl w-full z-10 space-y-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="space-y-2"
        >
          <span className="text-xs uppercase tracking-[0.3em] font-mono opacity-60">
            Phase 0{index + 1}
          </span>
          <h2 className={cn(
            "text-5xl md:text-8xl font-black tracking-tighter leading-none",
            section.theme === "sepia" && "font-serif italic",
            section.theme === "cyberpunk" && "font-mono uppercase text-glow"
          )}>
            {section.title}
          </h2>
          <p className="text-xl md:text-2xl font-medium opacity-80 italic">
            {section.subtitle}
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="space-y-6"
          >
            <p className="text-lg md:text-xl leading-relaxed opacity-90">
              {section.description}
            </p>
            {section.id === "cta" && (
              <button className="px-8 py-4 bg-black text-white rounded-full font-bold hover:scale-105 transition-transform flex items-center gap-2 group">
                Start Your Evolution
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            )}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8, rotate: -10 }}
            whileInView={{ opacity: 1, scale: 1, rotate: 0 }}
            transition={{ type: "spring", stiffness: 100, delay: 0.6 }}
            className="flex justify-center"
          >
            {Icon ? (
              <div className={cn(
                "p-12 rounded-3xl border-2 flex items-center justify-center shadow-2xl bg-white/10 backdrop-blur-sm",
                section.accent
              )}>
                <Icon className="w-32 h-32 md:w-48 md:h-48" strokeWidth={1} />
              </div>
            ) : section.id === "intro" ? (
              <div className="relative">
                <div className="absolute -inset-4 bg-black/5 rounded-full blur-2xl animate-pulse" />
                <div className="w-48 h-48 md:w-64 md:h-64 rounded-full border-4 border-dashed border-black/20 flex items-center justify-center animate-[spin_20s_linear_infinite]">
                  <div className="w-full h-[1px] bg-black/20" />
                  <div className="w-[1px] h-full bg-black/20 absolute" />
                </div>
                <div className="absolute inset-0 flex items-center justify-center">
                   <div className="w-12 h-12 bg-black rounded-full" />
                </div>
              </div>
            ) : null}
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function ParallaxBackground({ theme }: { theme: string }) {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-20">
      {theme === "sepia" && (
        <>
          <FloatingElement className="top-[10%] left-[5%] text-8xl font-serif">木</FloatingElement>
          <FloatingElement className="bottom-[20%] right-[10%] text-9xl font-serif opacity-10">石</FloatingElement>
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/paper-fibers.png')] opacity-30" />
        </>
      )}
      {theme === "vintage" && (
        <>
          <FloatingElement className="top-[15%] right-[20%] text-7xl font-mono">A B C</FloatingElement>
          <FloatingElement className="bottom-[10%] left-[15%] text-8xl font-mono opacity-20">Q W E R T Y</FloatingElement>
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-20" />
        </>
      )}
      {theme === "modern" && (
        <>
          <div className="absolute top-0 left-0 w-full h-full grid grid-cols-12 gap-4">
            {Array.from({ length: 48 }).map((_, i) => (
              <div key={i} className="h-24 border-l border-t border-blue-500/10" />
            ))}
          </div>
          <FloatingElement className="top-[40%] right-[30%] w-32 h-32 rounded-full border border-blue-500/20">
            <div />
          </FloatingElement>
        </>
      )}
      {theme === "cyberpunk" && (
        <>
          <div className="absolute inset-0 bg-[linear-gradient(rgba(0,255,65,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,65,0.05)_1px,transparent_1px)] bg-[size:20px_20px]" />
          <FloatingElement className="top-[20%] left-[10%] text-green-500 font-mono text-xl">{"<div />"}</FloatingElement>
          <FloatingElement className="bottom-[30%] right-[15%] text-green-500 font-mono text-xl">{"useEffect(() => {})"}</FloatingElement>
          <FloatingElement className="top-[60%] left-[40%] text-green-500 font-mono text-xl">{"const [work, setWork] = useState()"}</FloatingElement>
        </>
      )}
    </div>
  );
}

function FloatingElement({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <motion.div
      animate={{
        y: [0, -20, 0],
        rotate: [0, 5, 0],
      }}
      transition={{
        duration: 5 + Math.random() * 5,
        repeat: Infinity,
        ease: "easeInOut",
      }}
      className={cn("absolute", className)}
    >
      {children}
    </motion.div>
  );
}
