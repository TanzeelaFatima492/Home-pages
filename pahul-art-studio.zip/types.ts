export interface Product {
  id: string;
  name: string;
  price: number;
  category: 'Calligraphy' | 'Handmade' | 'Digital' | 'Canvas' | 'Cards';
  image: string;
  description: string;
  featured?: boolean;
}

export interface CartItem extends Product {
  quantity: number;
}

export type PageView = 'HOME' | 'SHOP' | 'ABOUT' | 'CONTACT';

export interface AiResponse {
  text: string;
  ideas?: string[];
}