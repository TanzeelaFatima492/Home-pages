import React, { useState } from 'react';
import { ShoppingBag, Menu, X, Search, Palette } from 'lucide-react';
import { CartItem, PageView } from '../types';

interface NavbarProps {
  cartCount: number;
  onCartClick: () => void;
  onNavigate: (page: PageView) => void;
  currentPage: PageView;
}

export const Navbar: React.FC<NavbarProps> = ({ cartCount, onCartClick, onNavigate, currentPage }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navLinks: { label: string; value: PageView }[] = [
    { label: 'Home', value: 'HOME' },
    { label: 'Shop', value: 'SHOP' },
    { label: 'About', value: 'ABOUT' },
    { label: 'Custom Orders', value: 'CONTACT' },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-pahul-mustard/30 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          
          {/* Logo */}
          <div 
            className="flex-shrink-0 flex items-center cursor-pointer"
            onClick={() => onNavigate('HOME')}
          >
            <Palette className="h-8 w-8 text-pahul-gold mr-2" />
            <span className="font-serif text-2xl font-bold text-stone-900 tracking-tight">
              Pahul <span className="text-pahul-mustard">Art</span> Studio
            </span>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex space-x-8 items-center">
            {navLinks.map((link) => (
              <button
                key={link.value}
                onClick={() => onNavigate(link.value)}
                className={`font-sans text-sm font-medium transition-colors duration-200 uppercase tracking-wider ${
                  currentPage === link.value 
                    ? 'text-pahul-red border-b-2 border-pahul-red' 
                    : 'text-stone-600 hover:text-pahul-mustard'
                }`}
              >
                {link.label}
              </button>
            ))}
          </div>

          {/* Icons */}
          <div className="flex items-center space-x-4">
            <button className="p-2 text-stone-600 hover:text-pahul-mustard transition-colors">
              <Search className="h-5 w-5" />
            </button>
            <button 
              className="p-2 text-stone-600 hover:text-pahul-mustard transition-colors relative"
              onClick={onCartClick}
            >
              <ShoppingBag className="h-5 w-5" />
              {cartCount > 0 && (
                <span className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/4 -translate-y-1/4 bg-pahul-red rounded-full">
                  {cartCount}
                </span>
              )}
            </button>
            <button 
              className="md:hidden p-2 text-stone-600"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-b border-gray-100 absolute w-full">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navLinks.map((link) => (
              <button
                key={link.value}
                onClick={() => {
                  onNavigate(link.value);
                  setIsMenuOpen(false);
                }}
                className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-stone-700 hover:text-pahul-mustard hover:bg-stone-50"
              >
                {link.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};