import React, { useState } from 'react';
import { Sparkles, X, Send, Loader2 } from 'lucide-react';
import { generateArtIdeas, generateCalligraphyQuote } from '../services/geminiService';

interface AiAssistantProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AiAssistant: React.FC<AiAssistantProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'IDEAS' | 'QUOTES'>('IDEAS');
  const [input, setInput] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    setLoading(true);
    setResult('');

    if (activeTab === 'IDEAS') {
      const response = await generateArtIdeas(input);
      setResult(response);
    } else {
      const response = await generateCalligraphyQuote(input);
      setResult(response);
    }

    setLoading(false);
  };

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-stone-900/60 backdrop-blur-sm" onClick={onClose} />
      
      <div className="relative bg-white rounded-lg shadow-2xl w-full max-w-lg overflow-hidden border border-pahul-gold/30">
        
        {/* Header */}
        <div className="bg-pahul-mustard/10 p-6 border-b border-pahul-mustard/20 flex justify-between items-center">
          <div className="flex items-center text-pahul-red">
            <Sparkles className="h-5 w-5 mr-2 text-pahul-mustard" />
            <h3 className="font-serif text-xl font-bold text-stone-900">Pahul's AI Muse</h3>
          </div>
          <button onClick={onClose} className="text-stone-500 hover:text-stone-800">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-100">
          <button 
            onClick={() => { setActiveTab('IDEAS'); setResult(''); setInput(''); }}
            className={`flex-1 py-3 text-sm font-medium transition-colors ${activeTab === 'IDEAS' ? 'text-pahul-mustard border-b-2 border-pahul-mustard bg-yellow-50' : 'text-stone-500 hover:bg-stone-50'}`}
          >
            Art Concept Generator
          </button>
          <button 
            onClick={() => { setActiveTab('QUOTES'); setResult(''); setInput(''); }}
            className={`flex-1 py-3 text-sm font-medium transition-colors ${activeTab === 'QUOTES' ? 'text-pahul-mustard border-b-2 border-pahul-mustard bg-yellow-50' : 'text-stone-500 hover:bg-stone-50'}`}
          >
            Calligraphy Quotes
          </button>
        </div>

        {/* Body */}
        <div className="p-6 min-h-[300px] flex flex-col">
          <p className="text-stone-600 mb-4 text-sm">
            {activeTab === 'IDEAS' 
              ? "Describe a feeling, occasion, or person, and I'll suggest a custom handmade art piece."
              : "Enter a theme (e.g., 'Peace', 'Wedding', 'Success') to generate a beautiful calligraphy quote."}
          </p>

          <form onSubmit={handleSubmit} className="relative mb-6">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={activeTab === 'IDEAS' ? "e.g., A housewarming gift for a nature lover..." : "e.g., Gratitude, Love, Sikh History..."}
              className="w-full pl-4 pr-12 py-3 border border-stone-300 rounded-md focus:ring-2 focus:ring-pahul-mustard focus:border-transparent outline-none text-stone-800 placeholder-stone-400 bg-stone-50"
            />
            <button 
              type="submit" 
              disabled={loading || !input.trim()}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 p-2 bg-pahul-red text-white rounded-full hover:bg-red-900 disabled:opacity-50 transition-colors"
            >
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </button>
          </form>

          <div className="flex-1 bg-stone-50 rounded-lg p-4 border border-stone-100 overflow-y-auto max-h-60">
            {result ? (
              <div className="prose prose-stone prose-sm max-w-none">
                <h4 className="text-pahul-mustard font-serif mb-2">Here's some inspiration:</h4>
                <div className="whitespace-pre-wrap text-stone-700">{result}</div>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-stone-400 text-sm italic">
                <Sparkles className="h-8 w-8 mb-2 opacity-20" />
                Awaiting your creative spark...
              </div>
            )}
          </div>
        </div>
        
        <div className="bg-gray-50 p-3 text-center text-xs text-stone-400 border-t border-gray-100">
          AI suggestions are powered by Gemini and intended for inspiration.
        </div>
      </div>
    </div>
  );
};