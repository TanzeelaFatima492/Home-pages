import React from 'react';
import { Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-stone-900 text-white py-12 border-t border-pahul-mustard">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-2xl font-serif font-bold text-pahul-mustard mb-4">Pahul Art Studio</h3>
            <p className="text-stone-400 text-sm leading-relaxed">
              Handcrafted art, calligraphy, and digital designs inspired by Indian heritage and modern aesthetics.
            </p>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-stone-400 text-sm">
              <li><a href="#" className="hover:text-pahul-pink">Shop All</a></li>
              <li><a href="#" className="hover:text-pahul-pink">About the Artist</a></li>
              <li><a href="#" className="hover:text-pahul-pink">Shipping Policy</a></li>
              <li><a href="#" className="hover:text-pahul-pink">Custom Orders</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-4">Newsletter</h4>
            <p className="text-stone-400 text-sm mb-4">Subscribe for new art drops and exclusive offers.</p>
            <div className="flex">
              <input 
                type="email" 
                placeholder="Your email" 
                className="bg-stone-800 text-white px-4 py-2 outline-none border border-stone-700 focus:border-pahul-mustard w-full"
              />
              <button className="bg-pahul-mustard text-stone-900 px-4 py-2 font-bold hover:bg-yellow-500">
                Join
              </button>
            </div>
          </div>
        </div>
        
        <div className="border-t border-stone-800 mt-12 pt-8 text-center text-stone-500 text-sm flex items-center justify-center">
          <p>Made with <Heart className="inline h-4 w-4 text-pahul-red mx-1" /> in India. &copy; {new Date().getFullYear()} Pahul Art Studio.</p>
        </div>
      </div>
    </footer>
  );
};