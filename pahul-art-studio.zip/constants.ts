import { Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Golden Temple Silhouette',
    price: 1200, // INR assumed
    category: 'Canvas',
    image: 'https://picsum.photos/400/400?random=1',
    description: 'A stunning gold-leaf silhouette of the Golden Temple on a deep crimson background.',
    featured: true,
  },
  {
    id: '2',
    name: 'Ik Onkar Calligraphy Frame',
    price: 850,
    category: 'Calligraphy',
    image: 'https://picsum.photos/400/400?random=2',
    description: 'Hand-lettered Ik Onkar symbol surrounded by intricate floral mandala patterns.',
    featured: true,
  },
  {
    id: '3',
    name: 'Floral Wedding Invitation Suite',
    price: 5000,
    category: 'Cards',
    image: 'https://picsum.photos/400/400?random=3',
    description: 'Customizable wedding cards featuring traditional pink and red roses with gold accents.',
  },
  {
    id: '4',
    name: 'Digital Mandala Pack',
    price: 450,
    category: 'Digital',
    image: 'https://picsum.photos/400/400?random=4',
    description: 'High-resolution vector mandalas ready for print or digital use.',
  },
  {
    id: '5',
    name: 'Mustard Fields Acrylic',
    price: 2500,
    category: 'Handmade',
    image: 'https://picsum.photos/400/400?random=5',
    description: 'Textured acrylic painting capturing the vibrancy of Punjab’s mustard fields.',
  },
  {
    id: '6',
    name: 'Custom Name Calligraphy',
    price: 600,
    category: 'Calligraphy',
    image: 'https://picsum.photos/400/400?random=6',
    description: 'Your name written in elegant calligraphy script with gold dusting.',
  },
  {
    id: '7',
    name: 'Royal Elephant Greeting Cards',
    price: 350,
    category: 'Cards',
    image: 'https://picsum.photos/400/400?random=7',
    description: 'Set of 5 greeting cards featuring royal Indian elephants.',
  },
  {
    id: '8',
    name: 'Abstract Rose Garden',
    price: 3200,
    category: 'Canvas',
    image: 'https://picsum.photos/400/400?random=8',
    description: 'Large canvas featuring abstract roses in hues of pink, red, and gold.',
  },
];

export const CATEGORIES = ['All', 'Calligraphy', 'Handmade', 'Digital', 'Canvas', 'Cards'];