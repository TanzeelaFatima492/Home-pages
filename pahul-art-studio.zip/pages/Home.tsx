import React from 'react';
import { ArrowRight, Star } from 'lucide-react';
import { PRODUCTS } from '../constants';
import { Product, PageView } from '../types';

interface HomeProps {
  onNavigate: (page: PageView) => void;
  onAddToCart: (product: Product) => void;
  onOpenAi: () => void;
}

export const Home: React.FC<HomeProps> = ({ onNavigate, onAddToCart, onOpenAi }) => {
  const featuredProducts = PRODUCTS.filter(p => p.featured);

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <div className="relative bg-stone-900 text-white overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1582560475093-453146f93445?auto=format&fit=crop&q=80&w=2000" 
            alt="Art background" 
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-stone-900 via-stone-900/80 to-transparent"></div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 md:py-48">
          <div className="max-w-2xl">
            <h1 className="text-4xl md:text-6xl font-serif font-bold mb-6 leading-tight">
              Where <span className="text-pahul-mustard">Tradition</span> Meets <span className="text-pahul-pink">Soulful Art</span>
            </h1>
            <p className="text-lg md:text-xl text-stone-300 mb-10 font-light">
              Explore our collection of handcrafted mandalas, bespoke calligraphy, and vibrant Indian art that tells a story in every stroke.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button 
                onClick={() => onNavigate('SHOP')}
                className="px-8 py-4 bg-pahul-mustard text-stone-900 font-bold uppercase tracking-wide hover:bg-yellow-500 transition-all shadow-lg shadow-yellow-900/20"
              >
                Shop Collection
              </button>
              <button 
                onClick={onOpenAi}
                className="px-8 py-4 bg-transparent border border-white text-white font-bold uppercase tracking-wide hover:bg-white hover:text-stone-900 transition-all flex items-center justify-center"
              >
                <Star className="h-5 w-5 mr-2 text-pahul-mustard" />
                Get AI Inspiration
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Featured Section */}
      <div className="py-20 bg-white flower-pattern">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-serif font-bold text-stone-900 mb-4">Featured Masterpieces</h2>
            <div className="h-1 w-20 bg-pahul-mustard mx-auto"></div>
            <p className="mt-4 text-stone-600 max-w-2xl mx-auto">
              Hand-picked favorites from our studio, crafted with passion and precision using traditional gold leaf techniques.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {featuredProducts.map((product) => (
              <div key={product.id} className="group">
                <div className="relative overflow-hidden bg-stone-200 rounded-lg aspect-[4/5] mb-4 shadow-md">
                  <img 
                    src={product.image} 
                    alt={product.name} 
                    className="h-full w-full object-cover transform group-hover:scale-105 transition-transform duration-500"
                  />
                  <button 
                    onClick={() => onAddToCart(product)}
                    className="absolute bottom-4 right-4 bg-white text-stone-900 p-3 rounded-full shadow-lg translate-y-full opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300 hover:bg-pahul-red hover:text-white"
                  >
                    <ArrowRight className="h-5 w-5" />
                  </button>
                </div>
                <h3 className="text-xl font-serif font-medium text-stone-900 group-hover:text-pahul-red transition-colors">{product.name}</h3>
                <p className="text-pahul-mustard font-bold mt-1">₹{product.price}</p>
              </div>
            ))}
          </div>
          
          <div className="mt-16 text-center">
             <button 
                onClick={() => onNavigate('SHOP')}
                className="inline-flex items-center text-stone-900 border-b-2 border-pahul-red hover:text-pahul-red transition-colors pb-1 font-medium uppercase tracking-wider"
              >
                View All Products <ArrowRight className="ml-2 h-4 w-4" />
              </button>
          </div>
        </div>
      </div>

      {/* About Snippet */}
      <div className="bg-pahul-red text-white py-20">
         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-10 md:mb-0 pr-0 md:pr-10">
               <h2 className="text-3xl font-serif font-bold mb-6">Art with a Heart</h2>
               <p className="text-stone-100 leading-relaxed mb-6">
                 Pahul Art Studio is an Indian-owned creative space dedicated to preserving the beauty of handwritten calligraphy and traditional motifs. Each stroke is a meditation, each color a prayer.
               </p>
               <button onClick={() => onNavigate('ABOUT')} className="px-6 py-3 bg-white text-pahul-red font-bold hover:bg-stone-100 transition-colors">
                 Meet the Artist
               </button>
            </div>
            <div className="md:w-1/2 relative">
               <div className="border-4 border-pahul-mustard p-2 rounded-lg transform rotate-2">
                  <img 
                    src="https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?auto=format&fit=crop&q=80&w=800" 
                    alt="Artist working" 
                    className="rounded w-full shadow-2xl transform -rotate-2"
                  />
               </div>
            </div>
         </div>
      </div>
    </div>
  );
};