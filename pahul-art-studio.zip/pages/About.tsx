import React from 'react';
import { Mail, Instagram, Facebook } from 'lucide-react';

export const About: React.FC = () => {
  return (
    <div className="bg-white min-h-screen">
       {/* Header */}
       <div className="bg-stone-900 py-20 text-center text-white">
         <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4">The Artist Behind Pahul</h1>
         <p className="text-stone-400 max-w-xl mx-auto px-4">Connecting heritage with contemporary aesthetics.</p>
       </div>

       <div className="max-w-5xl mx-auto px-4 py-16 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
             <div>
               <img 
                 src="https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&q=80&w=800"
                 alt="Artist studio"
                 className="rounded-lg shadow-2xl border-8 border-white"
               />
             </div>
             <div>
               <h2 className="text-3xl font-serif font-bold text-stone-900 mb-6">Sat Sri Akal & Namaste</h2>
               <p className="text-stone-600 mb-4 leading-relaxed">
                 Welcome to Pahul Art Studio. Based in the heart of India, this studio is a labor of love, born from a passion for intricate patterns, vibrant colors, and the timeless beauty of Gurmukhi and English calligraphy.
               </p>
               <p className="text-stone-600 mb-4 leading-relaxed">
                 The name <strong>"Pahul"</strong> signifies a new beginning or initiation. Through my art, I aim to bring a fresh perspective to traditional Indian aesthetics, blending deep reds, mustard golds, and floral motifs into everyday life.
               </p>
               <p className="text-stone-600 mb-8 leading-relaxed">
                 Whether it's a custom wedding invitation, a spiritual canvas for your home, or a digital print, every piece is created with mindfulness and joy.
               </p>

               <div className="flex space-x-4">
                 <a href="#" className="p-3 bg-stone-100 rounded-full text-stone-600 hover:bg-pahul-pink hover:text-white transition-colors">
                   <Instagram className="h-5 w-5" />
                 </a>
                 <a href="#" className="p-3 bg-stone-100 rounded-full text-stone-600 hover:bg-blue-600 hover:text-white transition-colors">
                   <Facebook className="h-5 w-5" />
                 </a>
                 <a href="mailto:hello@pahulart.com" className="p-3 bg-stone-100 rounded-full text-stone-600 hover:bg-pahul-mustard hover:text-white transition-colors">
                   <Mail className="h-5 w-5" />
                 </a>
               </div>
             </div>
          </div>

          {/* Custom Orders Section */}
          <div className="mt-20 bg-stone-50 rounded-2xl p-8 md:p-12 text-center border border-pahul-mustard/20">
             <h3 className="text-2xl font-serif font-bold text-stone-900 mb-4">Have a Special Request?</h3>
             <p className="text-stone-600 max-w-2xl mx-auto mb-8">
               I love working on commissions! Whether you need a custom calligraphy quote, a family tree, or a specific painting, let's create something unique together. Use our AI Assistant for ideas or contact me directly.
             </p>
             <button className="bg-pahul-red text-white px-8 py-3 font-bold rounded hover:bg-red-800 transition-colors shadow-md">
               Contact for Commissions
             </button>
          </div>
       </div>
    </div>
  );
};