import React, { useState } from 'react';
import { Filter, ShoppingCart } from 'lucide-react';
import { PRODUCTS, CATEGORIES } from '../constants';
import { Product } from '../types';

interface ShopProps {
  onAddToCart: (product: Product) => void;
}

export const Shop: React.FC<ShopProps> = ({ onAddToCart }) => {
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredProducts = activeCategory === 'All' 
    ? PRODUCTS 
    : PRODUCTS.filter(p => p.category === activeCategory);

  return (
    <div className="min-h-screen bg-pahul-cream py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        
        <div className="text-center mb-12">
          <h1 className="text-4xl font-serif font-bold text-stone-900 mb-4">The Collection</h1>
          <p className="text-stone-600">Handmade with love, delivered with care.</p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                activeCategory === cat
                  ? 'bg-pahul-red text-white shadow-lg shadow-red-900/20'
                  : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {filteredProducts.map((product) => (
            <div key={product.id} className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-xl transition-shadow duration-300 border border-stone-100 group">
              <div className="relative aspect-square overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                   <button 
                    onClick={() => onAddToCart(product)}
                    className="bg-white text-stone-900 px-6 py-3 rounded-full font-bold flex items-center hover:bg-pahul-mustard transition-colors transform translate-y-4 group-hover:translate-y-0 duration-300"
                   >
                     <ShoppingCart className="h-4 w-4 mr-2" /> Add to Cart
                   </button>
                </div>
              </div>
              <div className="p-5">
                <div className="text-xs text-pahul-red font-bold uppercase tracking-wide mb-1">{product.category}</div>
                <h3 className="text-lg font-serif font-medium text-stone-900 mb-2 line-clamp-1">{product.name}</h3>
                <p className="text-stone-500 text-sm line-clamp-2 mb-4">{product.description}</p>
                <div className="flex items-center justify-between pt-4 border-t border-stone-100">
                   <span className="text-xl font-bold text-stone-900">₹{product.price}</span>
                   <button 
                    className="text-stone-400 hover:text-pahul-mustard transition-colors"
                    onClick={() => onAddToCart(product)}
                   >
                     <span className="sr-only">Add to cart</span>
                     <ShoppingCart className="h-5 w-5" />
                   </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-20">
            <p className="text-stone-500 text-lg">No products found in this category.</p>
            <button 
              onClick={() => setActiveCategory('All')} 
              className="mt-4 text-pahul-mustard hover:underline"
            >
              View all items
            </button>
          </div>
        )}
      </div>
    </div>
  );
};