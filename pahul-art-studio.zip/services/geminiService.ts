import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const generateArtIdeas = async (userPrompt: string): Promise<string> => {
  try {
    const model = 'gemini-2.5-flash';
    const prompt = `
      You are a creative art consultant for "Pahul Art Studio", an Indian art studio specializing in calligraphy, mandalas, and handmade crafts. 
      The user wants an idea for a custom art piece or a gift.
      
      User request: "${userPrompt}"
      
      Provide 3 distinct, creative, and culturally rich art concepts (e.g., "A Gold-Leaf Waheguru Calligraphy on Deep Crimson Canvas"). 
      Keep the tone elegant, artistic, and helpful. Format the response as a clean list.
    `;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
    });

    return response.text || "I couldn't generate ideas at this moment. Please try again.";
  } catch (error) {
    console.error("Error generating art ideas:", error);
    return "Our creative muse is taking a short break. Please check your connection or try again later.";
  }
};

export const generateCalligraphyQuote = async (theme: string): Promise<string> => {
  try {
    const model = 'gemini-2.5-flash';
    const prompt = `
      Suggest a beautiful, meaningful short quote suitable for calligraphy art based on the theme: "${theme}".
      Include an option in English and one in Punjabi or Hindi (with translation) if appropriate for the theme.
      Keep it short (under 15 words) suitable for a wall frame.
    `;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
    });
    
    return response.text || "Beauty lies in simplicity.";
  } catch (error) {
    console.error(error);
    return "Art speaks where words fail.";
  }
};