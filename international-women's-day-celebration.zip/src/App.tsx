/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Heart, 
  Users, 
  Globe, 
  Award, 
  Mail, 
  Instagram, 
  Twitter, 
  Facebook, 
  Linkedin,
  ChevronRight,
  Menu,
  X,
  Quote
} from 'lucide-react';

// --- Components ---

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const navLinks = [
    { name: 'Home', href: '#' },
    { name: 'About', href: '#about' },
    { name: 'Inspiration', href: '#inspiration' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className="fixed w-full z-50 bg-white/80 backdrop-blur-md border-b border-purple-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex-shrink-0 flex items-center gap-2">
            <Heart className="text-pink-500 fill-pink-500" size={24} />
            <span className="text-2xl font-display font-bold bg-gradient-to-r from-purple-600 to-pink-500 bg-clip-text text-transparent">
              IWD 2026
            </span>
          </div>
          
          {/* Desktop Menu */}
          <div className="hidden md:flex space-x-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-purple-900/70 hover:text-purple-600 font-medium transition-colors"
              >
                {link.name}
              </a>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-purple-900 p-2"
            >
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-b border-purple-100 overflow-hidden"
          >
            <div className="px-4 pt-2 pb-6 space-y-2">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setIsOpen(false)}
                  className="block px-3 py-4 text-lg font-medium text-purple-900/80 hover:bg-purple-50 rounded-xl"
                >
                  {link.name}
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-purple-50">
      {/* Background Decorative Elements */}
      <div className="absolute top-0 right-0 -translate-y-1/4 translate-x-1/4 w-[600px] h-[600px] bg-pink-200/30 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 translate-y-1/4 -translate-x-1/4 w-[500px] h-[500px] bg-purple-200/30 rounded-full blur-3xl" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <span className="inline-block px-4 py-1.5 rounded-full bg-purple-100 text-purple-700 text-sm font-bold tracking-wider uppercase mb-6">
              March 8th, 2026
            </span>
            <h1 className="text-6xl md:text-8xl font-display font-bold text-purple-950 leading-tight mb-6">
              International <br />
              <span className="text-pink-600 italic">Women's</span> Day
            </h1>
            <p className="text-xl text-purple-900/70 max-w-lg mb-10 leading-relaxed">
              Celebrating the social, economic, cultural, and political achievements of women around the world while calling for gender equality.
            </p>
            <div className="flex flex-wrap gap-4">
              <a
                href="#about"
                className="px-8 py-4 bg-purple-600 text-white rounded-full font-bold text-lg hover:bg-purple-700 transition-all shadow-lg shadow-purple-200 flex items-center gap-2 group"
              >
                Learn More
                <ChevronRight className="group-hover:translate-x-1 transition-transform" size={20} />
              </a>
              <a
                href="#inspiration"
                className="px-8 py-4 border-2 border-purple-200 text-purple-900 rounded-full font-bold text-lg hover:bg-white transition-all"
              >
                View Inspiration
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="relative"
          >
            <div className="relative z-10 rounded-3xl overflow-hidden shadow-2xl border-8 border-white">
              <img
                src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=1000"
                alt="Empowered Women"
                className="w-full h-[600px] object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            {/* Floating Stats */}
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -bottom-6 -left-6 bg-white p-6 rounded-2xl shadow-xl z-20 border border-purple-50"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center text-pink-600">
                  <Globe size={24} />
                </div>
                <div>
                  <p className="text-xs text-purple-500 font-bold uppercase tracking-wider">Global Impact</p>
                  <p className="text-xl font-bold text-purple-950">190+ Countries</p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const About = () => {
  return (
    <section id="about" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="order-2 lg:order-1">
            <div className="grid grid-cols-2 gap-4">
              <img
                src="https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&q=80&w=500"
                alt="Women Working"
                className="rounded-2xl h-64 w-full object-cover shadow-lg"
                referrerPolicy="no-referrer"
              />
              <img
                src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&q=80&w=500"
                alt="Women Collaborating"
                className="rounded-2xl h-64 w-full object-cover shadow-lg mt-8"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
          
          <div className="order-1 lg:order-2">
            <h2 className="text-4xl font-display font-bold text-purple-950 mb-6">
              Why We Celebrate <br />
              <span className="text-pink-600 italic">International Women's Day</span>
            </h2>
            <p className="text-lg text-purple-900/70 mb-6 leading-relaxed">
              International Women's Day (IWD) is a global day celebrating the social, economic, cultural, and political achievements of women. The day also marks a call to action for accelerating women's equality.
            </p>
            <p className="text-lg text-purple-900/70 mb-8 leading-relaxed">
              IWD has occurred for well over a century, with the first IWD gathering in 1911 supported by over a million people. Today, IWD belongs to all groups collectively everywhere. IWD is not country, group or organization specific.
            </p>
            
            <div className="space-y-4">
              {[
                { icon: <Award />, title: "Recognizing Achievement", desc: "Honoring the progress made by women in all fields." },
                { icon: <Users />, title: "Building Community", desc: "Connecting women across borders to share experiences." },
                { icon: <Globe />, title: "Driving Change", desc: "Advocating for policy changes and social equality." }
              ].map((item, i) => (
                <div key={i} className="flex gap-4 p-4 rounded-2xl hover:bg-purple-50 transition-colors group">
                  <div className="flex-shrink-0 w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center text-purple-600 group-hover:bg-purple-600 group-hover:text-white transition-colors">
                    {item.icon}
                  </div>
                  <div>
                    <h4 className="font-bold text-purple-950">{item.title}</h4>
                    <p className="text-purple-900/60 text-sm">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const Inspiration = () => {
  const women = [
    {
      name: "Marie Curie",
      role: "Physicist & Chemist",
      desc: "The first woman to win a Nobel Prize and the only person to win Nobel Prizes in two different scientific fields.",
      img: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=500"
    },
    {
      name: "Malala Yousafzai",
      role: "Activist",
      desc: "A Pakistani activist for female education and the youngest Nobel Prize laureate.",
      img: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=500"
    },
    {
      name: "Kamala Harris",
      role: "Politician",
      desc: "The first female, first African American, and first South Asian American Vice President of the United States.",
      img: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?auto=format&fit=crop&q=80&w=500"
    }
  ];

  return (
    <section id="inspiration" className="py-24 bg-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-4xl font-display font-bold text-purple-950 mb-4">Inspirational Leaders</h2>
          <p className="text-lg text-purple-900/70">
            Meet the women who changed the course of history through their courage, intellect, and unwavering spirit.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {women.map((woman, i) => (
            <motion.div
              key={i}
              whileHover={{ y: -10 }}
              className="bg-white rounded-3xl overflow-hidden shadow-xl border border-purple-100 group"
            >
              <div className="h-72 overflow-hidden">
                <img
                  src={woman.img}
                  alt={woman.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="p-8">
                <span className="text-pink-500 text-sm font-bold uppercase tracking-widest mb-2 block">{woman.role}</span>
                <h3 className="text-2xl font-display font-bold text-purple-950 mb-4">{woman.name}</h3>
                <p className="text-purple-900/70 leading-relaxed mb-6">
                  {woman.desc}
                </p>
                <button className="text-purple-600 font-bold flex items-center gap-2 hover:gap-3 transition-all">
                  Read Story <ChevronRight size={18} />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Message = () => {
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900 to-pink-800" />
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]" />
      </div>
      
      <div className="max-w-4xl mx-auto px-4 relative z-10 text-center">
        <Quote className="text-pink-400 mx-auto mb-8 opacity-50" size={64} />
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-3xl md:text-5xl font-display italic font-medium text-white leading-tight mb-8"
        >
          "There is no limit to what we, as women, can accomplish."
        </motion.h2>
        <p className="text-pink-200 font-bold tracking-widest uppercase">— Michelle Obama</p>
      </div>
    </section>
  );
};

const Gallery = () => {
  const images = [
    "https://images.unsplash.com/photo-1484863137850-59afcfe05386?auto=format&fit=crop&q=80&w=600",
    "https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&q=80&w=600",
    "https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?auto=format&fit=crop&q=80&w=600",
    "https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&q=80&w=600",
    "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&q=80&w=600",
    "https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&q=80&w=600"
  ];

  return (
    <section id="gallery" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-display font-bold text-purple-950 mb-4">Empowerment Gallery</h2>
          <p className="text-lg text-purple-900/70">Moments of strength, unity, and celebration.</p>
        </div>
        
        <div className="columns-1 md:columns-2 lg:columns-3 gap-6 space-y-6">
          {images.map((src, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="relative group cursor-pointer overflow-hidden rounded-3xl"
            >
              <img
                src={src}
                alt={`Gallery ${i}`}
                className="w-full object-cover group-hover:scale-110 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-purple-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <Heart className="text-white fill-white" size={32} />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Contact = () => {
  const [formState, setFormState] = useState({ name: '', email: '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
    setFormState({ name: '', email: '', message: '' });
  };

  return (
    <section id="contact" className="py-24 bg-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-[3rem] shadow-2xl overflow-hidden grid lg:grid-cols-2">
          <div className="p-12 lg:p-20 bg-purple-600 text-white flex flex-col justify-between">
            <div>
              <h2 className="text-4xl font-display font-bold mb-6">Get in Touch</h2>
              <p className="text-purple-100 text-lg mb-12">
                Have questions or want to collaborate for the next International Women's Day event? We'd love to hear from you.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
                    <Mail size={24} />
                  </div>
                  <span>hello@iwd2026.org</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
                    <Globe size={24} />
                  </div>
                  <span>www.internationalwomensday.com</span>
                </div>
              </div>
            </div>
            
            <div className="flex gap-4 mt-12">
              {[Instagram, Twitter, Facebook, Linkedin].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-white hover:text-purple-600 transition-all">
                  <Icon size={20} />
                </a>
              ))}
            </div>
          </div>
          
          <div className="p-12 lg:p-20">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-bold text-purple-900 uppercase tracking-wider mb-2">Full Name</label>
                <input
                  type="text"
                  required
                  value={formState.name}
                  onChange={(e) => setFormState({...formState, name: e.target.value})}
                  className="w-full px-6 py-4 bg-purple-50 border border-purple-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                  placeholder="Jane Doe"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-purple-900 uppercase tracking-wider mb-2">Email Address</label>
                <input
                  type="email"
                  required
                  value={formState.email}
                  onChange={(e) => setFormState({...formState, email: e.target.value})}
                  className="w-full px-6 py-4 bg-purple-50 border border-purple-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                  placeholder="jane@example.com"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-purple-900 uppercase tracking-wider mb-2">Message</label>
                <textarea
                  rows={4}
                  required
                  value={formState.message}
                  onChange={(e) => setFormState({...formState, message: e.target.value})}
                  className="w-full px-6 py-4 bg-purple-50 border border-purple-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all resize-none"
                  placeholder="How can we help?"
                />
              </div>
              <button
                type="submit"
                className="w-full py-5 bg-purple-600 text-white rounded-2xl font-bold text-lg hover:bg-purple-700 transition-all shadow-lg shadow-purple-200"
              >
                {submitted ? 'Message Sent!' : 'Send Message'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="py-12 bg-white border-t border-purple-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2">
            <Heart className="text-pink-500 fill-pink-500" size={20} />
            <span className="text-xl font-display font-bold text-purple-950">IWD 2026</span>
          </div>
          
          <p className="text-purple-900/50 text-sm">
            © 2026 International Women's Day. All rights reserved.
          </p>
          
          <div className="flex gap-6">
            <a href="#" className="text-purple-900/50 hover:text-purple-600 transition-colors">Privacy Policy</a>
            <a href="#" className="text-purple-900/50 hover:text-purple-600 transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

// --- Main App ---

export default function App() {
  return (
    <div className="min-h-screen font-sans text-purple-950 selection:bg-purple-200 selection:text-purple-900">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Inspiration />
        <Message />
        <Gallery />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
