import { 
  Lightbulb, 
  TrendingUp, 
  ShieldCheck, 
  Users, 
  BarChart3, 
  Cpu 
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";

const services = [
  {
    icon: Lightbulb,
    title: "Strategic Planning",
    description: "Develop comprehensive roadmaps aligned with your business goals and market opportunities.",
    color: "bg-indigo-100 text-indigo-600"
  },
  {
    icon: TrendingUp,
    title: "Growth Strategy",
    description: "Identify and capitalize on new market opportunities to accelerate sustainable business growth.",
    color: "bg-emerald-100 text-emerald-600"
  },
  {
    icon: ShieldCheck,
    title: "Risk Management",
    description: "Proactively identify potential risks and implement robust mitigation strategies.",
    color: "bg-rose-100 text-rose-600"
  },
  {
    icon: Users,
    title: "Organizational Design",
    description: "Optimize your team structure and culture to improve efficiency and employee satisfaction.",
    color: "bg-amber-100 text-amber-600"
  },
  {
    icon: BarChart3,
    title: "Data Analytics",
    description: "Transform raw data into actionable insights that drive informed decision-making.",
    color: "bg-blue-100 text-blue-600"
  },
  {
    icon: Cpu,
    title: "Digital Transformation",
    description: "Modernize your operations and leverage technology to stay ahead of the competition.",
    color: "bg-purple-100 text-purple-600"
  }
];

export default function Services() {
  return (
    <section className="py-20 bg-slate-50">
      <div className="container mx-auto px-4 md:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
            Our Expertise
          </h2>
          <p className="text-lg text-slate-600">
            Comprehensive consulting services tailored to your unique business challenges and objectives.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card 
              key={index} 
              className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-slate-200 bg-white"
            >
              <CardHeader>
                <div className={`w-14 h-14 ${service.color} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  <service.icon className="w-7 h-7" />
                </div>
                <CardTitle className="text-xl">{service.title}</CardTitle>
                <CardDescription className="text-base">
                  {service.description}
                </CardDescription>
              </CardHeader>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}