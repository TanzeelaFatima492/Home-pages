import { Linkedin, Twitter, Mail, MapPin, Phone, Briefcase } from "lucide-react";
import { Button } from "../components/ui/button";

type PageType = "home" | "services" | "about" | "testimonials" | "contact";

interface FooterProps {
  onNavigate: (page: PageType) => void;
}

const footerLinks = [
  { name: "Home", value: "home" as PageType },
  { name: "Services", value: "services" as PageType },
  { name: "About", value: "about" as PageType },
  { name: "Testimonials", value: "testimonials" as PageType },
  { name: "Contact", value: "contact" as PageType },
];

export default function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="bg-slate-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Brand Column */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Briefcase className="w-8 h-8 text-indigo-400" />
              <span className="text-xl font-bold">Apex Consulting</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              Empowering businesses to reach their full potential through strategic insight and innovative solutions.
            </p>
            <div className="flex gap-4 pt-2">
              <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white hover:bg-slate-800">
                <Linkedin className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white hover:bg-slate-800">
                <Twitter className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white hover:bg-slate-800">
                <Mail className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Quick Links Column */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-3">
              {footerLinks.map((link) => (
                <li key={link.name}>
                  <button
                    onClick={() => onNavigate(link.value)}
                    className="text-slate-400 hover:text-indigo-400 transition-colors text-sm flex items-center gap-2 group"
                  >
                    <span className="w-0 h-0.5 bg-indigo-400 transition-all group-hover:w-4"></span>
                    {link.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info Column */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 text-slate-400">
                <MapPin className="w-5 h-5 text-indigo-400 flex-shrink-0 mt-0.5" />
                <span className="text-sm">123 Business Avenue, Suite 100<br />New York, NY 10001</span>
              </li>
              <li className="flex items-center gap-3 text-slate-400">
                <Phone className="w-5 h-5 text-indigo-400 flex-shrink-0" />
                <span className="text-sm">+1 (555) 123-4567</span>
              </li>
              <li className="flex items-center gap-3 text-slate-400">
                <Mail className="w-5 h-5 text-indigo-400 flex-shrink-0" />
                <span className="text-sm">hello@apexconsulting.com</span>
              </li>
            </ul>
          </div>

          {/* Newsletter Column */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Stay Updated</h3>
            <p className="text-slate-400 text-sm mb-4">
              Subscribe to our newsletter for the latest insights and industry news.
            </p>
            <div className="flex gap-2">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 bg-slate-800 border border-slate-700 rounded-md px-3 py-2 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <Button className="bg-indigo-600 hover:bg-indigo-700">
                Join
              </Button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-slate-500 text-sm">
            © 2024 Apex Consulting. All rights reserved.
          </p>
          <div className="flex gap-6 text-sm">
            <button className="text-slate-500 hover:text-slate-300 transition-colors">
              Privacy Policy
            </button>
            <button className="text-slate-500 hover:text-slate-300 transition-colors">
              Terms of Service
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}