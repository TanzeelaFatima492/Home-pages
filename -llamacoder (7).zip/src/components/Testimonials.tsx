import { useState } from "react";
import { Quote, ChevronLeft, ChevronRight, Star } from "lucide-react";
import { Card, CardContent } from "../components/ui/card";
import { Button } from "../components/ui/button";

const testimonials = [
  {
    name: "Sarah Johnson",
    role: "CEO",
    company: "TechVentures Inc.",
    content: "Apex Consulting transformed our business strategy completely. Their insights helped us increase revenue by 40% in just one year. Highly recommended!",
    rating: 5
  },
  {
    name: "Michael Chen",
    role: "Director of Operations",
    company: "Global Logistics Co.",
    content: "The team's expertise in operational efficiency was game-changing. We reduced costs significantly while improving our service quality across the board.",
    rating: 5
  },
  {
    name: "Emily Rodriguez",
    role: "Founder",
    company: "GreenStart Solutions",
    content: "Working with Apex felt like having an extension of our own team. They understood our vision and helped us scale sustainably. Truly exceptional partners.",
    rating: 5
  }
];

export default function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const currentTestimonial = testimonials[currentIndex];

  return (
    <section className="py-20 bg-slate-50">
      <div className="container mx-auto px-4 md:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
            What Our Clients Say
          </h2>
          <p className="text-lg text-slate-600">
            Don't just take our word for it. Here's what industry leaders have to say about working with us.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="border-slate-200 bg-white shadow-lg">
            <CardContent className="p-8 md:p-12">
              <div className="flex flex-col items-center text-center">
                <Quote className="w-12 h-12 text-indigo-200 mb-6" />
                
                <p className="text-xl md:text-2xl text-slate-700 leading-relaxed mb-8">
                  "{currentTestimonial.content}"
                </p>

                <div className="flex gap-1 mb-4">
                  {[...Array(currentTestimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-amber-400 text-amber-400" />
                  ))}
                </div>

                <div className="mb-8">
                  <div className="font-semibold text-slate-900 text-lg">
                    {currentTestimonial.name}
                  </div>
                  <div className="text-slate-600">
                    {currentTestimonial.role}, {currentTestimonial.company}
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <Button 
                    variant="outline" 
                    size="icon" 
                    onClick={prevTestimonial}
                    className="rounded-full hover:bg-slate-100"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </Button>
                  
                  <div className="flex gap-2">
                    {testimonials.map((_, index) => (
                      <button
                        key={index}
                        onClick={() => setCurrentIndex(index)}
                        className={`w-2.5 h-2.5 rounded-full transition-all ${
                          index === currentIndex ? "bg-indigo-600 w-6" : "bg-slate-300"
                        }`}
                      />
                    ))}
                  </div>

                  <Button 
                    variant="outline" 
                    size="icon" 
                    onClick={nextTestimonial}
                    className="rounded-full hover:bg-slate-100"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}