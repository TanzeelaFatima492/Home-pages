import { useState } from "react";
import { Menu, X, Briefcase } from "lucide-react";
import { Button } from "../components/ui/button";
import { cn } from "../lib/utils";

type PageType = "home" | "services" | "about" | "testimonials" | "contact";

const navItems = [
  { name: "Home", value: "home" as PageType },
  { name: "Services", value: "services" as PageType },
  { name: "About", value: "about" as PageType },
  { name: "Testimonials", value: "testimonials" as PageType },
  { name: "Contact", value: "contact" as PageType },
];

interface NavbarProps {
  activePage: PageType;
  onNavigate: (page: PageType) => void;
}

export default function Navbar({ activePage, onNavigate }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);

  const handleNavigate = (page: PageType) => {
    setIsOpen(false);
    onNavigate(page);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <nav className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-sm border-b border-slate-200 z-50 transition-shadow duration-300 hover:shadow-md">
      <div className="container mx-auto px-4 md:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          <button 
            onClick={() => handleNavigate("home")}
            className="flex items-center gap-2 text-slate-900 hover:opacity-80 transition-opacity"
          >
            <Briefcase className="w-8 h-8 text-indigo-600" />
            <span className="text-xl font-bold">Apex Consulting</span>
          </button>

          <div className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              <button
                key={item.name}
                onClick={() => handleNavigate(item.value)}
                className={cn(
                  "relative text-sm font-medium transition-colors group py-1",
                  activePage === item.value
                    ? "text-indigo-600"
                    : "text-slate-600 hover:text-indigo-600"
                )}
              >
                {item.name}
                <span className={cn(
                  "absolute bottom-0 left-0 h-0.5 bg-indigo-600 transition-all duration-300 ease-out",
                  activePage === item.value ? "w-full" : "w-0 group-hover:w-full"
                )}></span>
              </button>
            ))}
            <Button onClick={() => handleNavigate("contact")} className="shadow-sm hover:shadow-md transition-shadow">
              Get Started
            </Button>
          </div>

          <button
            className="md:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-md transition-colors"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden bg-white border-b border-slate-200 animate-in slide-in-from-top-2 duration-200">
          <div className="container mx-auto px-4 py-4 space-y-2">
            {navItems.map((item) => (
              <button
                key={item.name}
                onClick={() => handleNavigate(item.value)}
                className={cn(
                  "block w-full text-left text-sm font-medium py-3 px-4 rounded-md transition-colors",
                  activePage === item.value
                    ? "bg-indigo-50 text-indigo-600"
                    : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                )}
              >
                {item.name}
              </button>
            ))}
            <div className="pt-4">
              <Button className="w-full" onClick={() => handleNavigate("contact")}>
                Get Started
              </Button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}