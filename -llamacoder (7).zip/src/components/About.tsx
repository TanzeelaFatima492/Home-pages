import { Award, Target, Zap, CheckCircle2 } from "lucide-react";
import { Card, CardContent } from "../components/ui/card";
import { Badge } from "../components/ui/badge";

export default function About() {
  const values = [
    {
      icon: Target,
      title: "Results-Driven",
      description: "We focus on measurable outcomes that directly impact your bottom line."
    },
    {
      icon: Award,
      title: "Excellence",
      description: "We maintain the highest standards in every engagement and deliverable."
    },
    {
      icon: Zap,
      title: "Innovation",
      description: "We bring fresh perspectives and cutting-edge solutions to every challenge."
    }
  ];

  return (
    <section className="py-20">
      <div className="container mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Image Column */}
          <div className="relative">
            <div className="aspect-square bg-slate-200 rounded-2xl overflow-hidden relative">
              <div className="absolute inset-0 bg-gradient-to-br from-indigo-500 to-purple-600 opacity-90"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center text-white p-8">
                  <div className="text-6xl font-bold mb-2">15+</div>
                  <div className="text-xl font-medium">Years of Excellence</div>
                </div>
              </div>
            </div>
            
            {/* Floating Badge */}
            <div className="absolute -bottom-6 -right-6 bg-white p-6 rounded-xl shadow-lg border border-slate-100 hidden md:block">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center">
                  <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-slate-900">500+</div>
                  <div className="text-sm text-slate-600">Projects Completed</div>
                </div>
              </div>
            </div>
          </div>

          {/* Content Column */}
          <div className="space-y-8">
            <div>
              <Badge className="mb-4 bg-indigo-100 text-indigo-700 hover:bg-indigo-200">About Us</Badge>
              <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
                Building Success Through Strategic Partnership
              </h2>
              <p className="text-lg text-slate-600 leading-relaxed">
                Founded in 2009, Apex Consulting has grown from a small boutique firm to a global leader in business strategy. Our team of seasoned experts brings decades of experience across industries.
              </p>
              <p className="text-lg text-slate-600 leading-relaxed mt-4">
                We believe in building lasting partnerships with our clients, working side-by-side to navigate challenges and seize opportunities in an ever-evolving business landscape.
              </p>
            </div>

            <div className="space-y-6">
              <h3 className="text-xl font-semibold text-slate-900">Our Core Values</h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {values.map((value, index) => (
                  <Card key={index} className="border-slate-200 bg-slate-50">
                    <CardContent className="p-6">
                      <value.icon className="w-8 h-8 text-indigo-600 mb-3" />
                      <h4 className="font-semibold text-slate-900 mb-2">{value.title}</h4>
                      <p className="text-sm text-slate-600">{value.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}