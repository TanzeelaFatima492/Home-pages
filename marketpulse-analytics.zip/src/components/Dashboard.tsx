import React, { useState, useEffect } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell,
  PieChart,
  Pie,
} from 'recharts';
import {
  TrendingUp,
  Users,
  MousePointer2,
  ShoppingBag,
  FileText,
  Sparkles,
  ArrowUpRight,
  ArrowDownRight,
  Activity,
  BarChart3,
  PieChart as PieChartIcon,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import { cn } from '../lib/utils';
import { trackGoal, trackEvent } from '../services/analytics';
import { generateMarketingInsights, type AnalyticsData } from '../services/gemini';

// Mock Data for Visualization
const MOCK_TRAFFIC_DATA = [
  { date: '2024-03-01', visitors: 1200, bounces: 450 },
  { date: '2024-03-02', visitors: 1500, bounces: 520 },
  { date: '2024-03-03', visitors: 1800, bounces: 610 },
  { date: '2024-03-04', visitors: 1400, bounces: 480 },
  { date: '2024-03-05', visitors: 2100, bounces: 720 },
  { date: '2024-03-06', visitors: 2500, bounces: 850 },
  { date: '2024-03-07', visitors: 2300, bounces: 780 },
];

const MOCK_CONVERSION_DATA = [
  { type: 'Form Submits', count: 145, rate: 3.2, color: '#10b981' },
  { type: 'Product Clicks', count: 890, rate: 12.5, color: '#3b82f6' },
  { type: 'Purchases', count: 42, rate: 0.8, color: '#f59e0b' },
];

const MOCK_TOP_PAGES = [
  { path: '/', views: 4500 },
  { path: '/products', views: 3200 },
  { path: '/blog/marketing-tips', views: 1800 },
  { path: '/pricing', views: 1200 },
];

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444'];

export default function Dashboard() {
  const [insights, setInsights] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'conversions' | 'pages'>('overview');

  const analyticsData: AnalyticsData = {
    traffic: MOCK_TRAFFIC_DATA,
    conversions: MOCK_CONVERSION_DATA,
    topPages: MOCK_TOP_PAGES,
  };

  const handleGenerateInsights = async () => {
    setIsGenerating(true);
    const result = await generateMarketingInsights(analyticsData);
    setInsights(result);
    setIsGenerating(false);
  };

  const handleSimulateAction = (action: string, value?: number) => {
    trackGoal(action, value);
    // In a real app, this would update the state/database
    alert(`Simulated tracking: ${action}`);
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 font-sans p-6 md:p-10">
      <header className="max-w-7xl mx-auto mb-10 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-indigo-600 mb-2">
            <Activity size={20} />
            <span className="text-xs font-bold uppercase tracking-widest">Live Analytics</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-slate-900">
            MarketPulse <span className="text-indigo-600">Dashboard</span>
          </h1>
          <p className="text-slate-500 mt-2 max-w-lg">
            Real-time tracking, goal conversions, and AI-powered marketing insights.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button 
            onClick={handleGenerateInsights}
            disabled={isGenerating}
            className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-medium transition-all shadow-lg shadow-indigo-200 disabled:opacity-50"
          >
            {isGenerating ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Sparkles size={18} />
            )}
            {isGenerating ? 'Analyzing...' : 'Generate AI Insights'}
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Stats Grid */}
        <div className="lg:col-span-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard 
            title="Total Visitors" 
            value="13,800" 
            change="+12.5%" 
            isPositive={true} 
            icon={<Users className="text-blue-600" />} 
          />
          <StatCard 
            title="Conversion Rate" 
            value="4.2%" 
            change="+0.8%" 
            isPositive={true} 
            icon={<TrendingUp className="text-emerald-600" />} 
          />
          <StatCard 
            title="Avg. Session" 
            value="3m 42s" 
            change="-5.2%" 
            isPositive={false} 
            icon={<MousePointer2 className="text-amber-600" />} 
          />
          <StatCard 
            title="Revenue (Est)" 
            value="$4,250" 
            change="+18.2%" 
            isPositive={true} 
            icon={<ShoppingBag className="text-indigo-600" />} 
          />
        </div>

        {/* Main Chart Area */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => setActiveTab('overview')}
                  className={cn(
                    "px-4 py-2 rounded-lg text-sm font-medium transition-colors",
                    activeTab === 'overview' ? "bg-indigo-50 text-indigo-600" : "text-slate-500 hover:bg-slate-50"
                  )}
                >
                  Traffic Overview
                </button>
                <button 
                  onClick={() => setActiveTab('conversions')}
                  className={cn(
                    "px-4 py-2 rounded-lg text-sm font-medium transition-colors",
                    activeTab === 'conversions' ? "bg-indigo-50 text-indigo-600" : "text-slate-500 hover:bg-slate-50"
                  )}
                >
                  Conversions
                </button>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <div className="w-3 h-3 rounded-full bg-indigo-600" /> Visitors
                <div className="w-3 h-3 rounded-full bg-slate-200 ml-2" /> Bounces
              </div>
            </div>

            <div className="h-[350px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                {activeTab === 'overview' ? (
                  <LineChart data={MOCK_TRAFFIC_DATA}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis 
                      dataKey="date" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: '#94a3b8', fontSize: 12 }} 
                      dy={10}
                    />
                    <YAxis 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: '#94a3b8', fontSize: 12 }} 
                    />
                    <Tooltip 
                      contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="visitors" 
                      stroke="#4f46e5" 
                      strokeWidth={3} 
                      dot={{ r: 4, fill: '#4f46e5', strokeWidth: 2, stroke: '#fff' }}
                      activeDot={{ r: 6 }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="bounces" 
                      stroke="#e2e8f0" 
                      strokeWidth={2} 
                      strokeDasharray="5 5"
                      dot={false}
                    />
                  </LineChart>
                ) : (
                  <BarChart data={MOCK_CONVERSION_DATA}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis 
                      dataKey="type" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: '#94a3b8', fontSize: 12 }} 
                      dy={10}
                    />
                    <YAxis 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: '#94a3b8', fontSize: 12 }} 
                    />
                    <Tooltip 
                      contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                    />
                    <Bar dataKey="count" radius={[8, 8, 0, 0]}>
                      {MOCK_CONVERSION_DATA.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Bar>
                  </BarChart>
                )}
              </ResponsiveContainer>
            </div>
          </div>

          {/* Goal Tracking Simulation */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <MousePointer2 size={18} className="text-indigo-600" />
              Goal Tracking Integration
            </h3>
            <p className="text-sm text-slate-500 mb-6">
              Test your GA/GTM integration by simulating real user actions. These events are tracked as goals in your analytics suite.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <button 
                onClick={() => handleSimulateAction('Form Submission')}
                className="flex items-center justify-center gap-2 p-4 rounded-xl border border-slate-100 bg-slate-50 hover:bg-indigo-50 hover:border-indigo-200 transition-all group"
              >
                <FileText size={20} className="text-slate-400 group-hover:text-indigo-600" />
                <span className="font-medium text-slate-700 group-hover:text-indigo-700">Submit Form</span>
              </button>
              <button 
                onClick={() => handleSimulateAction('Product Click')}
                className="flex items-center justify-center gap-2 p-4 rounded-xl border border-slate-100 bg-slate-50 hover:bg-indigo-50 hover:border-indigo-200 transition-all group"
              >
                <MousePointer2 size={20} className="text-slate-400 group-hover:text-indigo-600" />
                <span className="font-medium text-slate-700 group-hover:text-indigo-700">Click Product</span>
              </button>
              <button 
                onClick={() => handleSimulateAction('Purchase', 99.99)}
                className="flex items-center justify-center gap-2 p-4 rounded-xl border border-slate-100 bg-slate-50 hover:bg-indigo-50 hover:border-indigo-200 transition-all group"
              >
                <ShoppingBag size={20} className="text-slate-400 group-hover:text-indigo-600" />
                <span className="font-medium text-slate-700 group-hover:text-indigo-700">Complete Sale</span>
              </button>
            </div>
          </div>
        </div>

        {/* Sidebar / Insights */}
        <div className="lg:col-span-4 space-y-6">
          {/* AI Insights Card */}
          <div className="bg-indigo-900 text-white p-6 rounded-2xl shadow-xl overflow-hidden relative">
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <Sparkles size={120} />
            </div>
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2 relative z-10">
              <Sparkles size={20} className="text-indigo-300" />
              AI Marketing Insights
            </h3>
            
            <div className="relative z-10 min-h-[200px]">
              {insights ? (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="prose prose-invert prose-sm max-w-none"
                >
                  <ReactMarkdown>{insights}</ReactMarkdown>
                </motion.div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full py-10 text-center">
                  <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center mb-4">
                    <Activity size={24} className="text-indigo-300" />
                  </div>
                  <p className="text-indigo-200 text-sm">
                    Click "Generate AI Insights" to analyze your current traffic and conversion patterns.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Top Pages Card */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <BarChart3 size={18} className="text-indigo-600" />
              Top Performing Pages
            </h3>
            <div className="space-y-4">
              {MOCK_TOP_PAGES.map((page, i) => (
                <div key={page.path} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-bold text-slate-400 w-4">{i + 1}</span>
                    <span className="text-sm font-medium text-slate-700 truncate max-w-[150px]">{page.path}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-24 h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-indigo-500" 
                        style={{ width: `${(page.views / MOCK_TOP_PAGES[0].views) * 100}%` }} 
                      />
                    </div>
                    <span className="text-xs font-bold text-slate-500">{page.views.toLocaleString()}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
      
      <footer className="max-w-7xl mx-auto mt-20 pt-10 border-t border-slate-200 text-center text-slate-400 text-sm pb-10">
        <p>© 2024 MarketPulse Analytics Suite. All tracking compliant with GDPR/CCPA.</p>
      </footer>
    </div>
  );
}

function StatCard({ title, value, change, isPositive, icon }: { 
  title: string; 
  value: string; 
  change: string; 
  isPositive: boolean;
  icon: React.ReactNode;
}) {
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
          {icon}
        </div>
        <div className={cn(
          "flex items-center gap-1 text-xs font-bold px-2 py-1 rounded-full",
          isPositive ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-600"
        )}>
          {isPositive ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
          {change}
        </div>
      </div>
      <div>
        <p className="text-slate-500 text-sm font-medium">{title}</p>
        <h4 className="text-2xl font-bold text-slate-900 mt-1">{value}</h4>
      </div>
    </motion.div>
  );
}
