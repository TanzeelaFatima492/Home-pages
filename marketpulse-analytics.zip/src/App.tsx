import React, { useEffect } from 'react';
import Dashboard from './components/Dashboard';
import { initAnalytics } from './services/analytics';

export default function App() {
  useEffect(() => {
    // Initialize Google Analytics & Tag Manager
    initAnalytics();
  }, []);

  return (
    <div className="min-h-screen bg-slate-50">
      <Dashboard />
    </div>
  );
}
