/**
 * Google Analytics & Tag Manager Integration Service
 * 
 * To use this in production:
 * 1. Replace GA_MEASUREMENT_ID and GTM_ID with your actual IDs.
 * 2. Ensure these are set in your environment variables.
 */

const GA_MEASUREMENT_ID = import.meta.env.VITE_GA_MEASUREMENT_ID || 'G-XXXXXXXXXX';
const GTM_ID = import.meta.env.VITE_GTM_ID || 'GTM-XXXXXXX';

export const initAnalytics = () => {
  if (typeof window === 'undefined') return;

  // Google Tag Manager
  (function(w: any, d: any, s: string, l: string, i: string) {
    w[l] = w[l] || [];
    w[l].push({ 'gtm.start': new Date().getTime(), event: 'gtm.js' });
    const f = d.getElementsByTagName(s)[0],
      j = d.createElement(s),
      dl = l != 'dataLayer' ? '&l=' + l : '';
    j.async = true;
    j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
    f.parentNode.insertBefore(j, f);
  })(window, document, 'script', 'dataLayer', GTM_ID);

  // Google Analytics (gtag.js)
  const script = document.createElement('script');
  script.async = true;
  script.src = `https://www.googletagmanager.com/gtag/js?id=${GA_MEASUREMENT_ID}`;
  document.head.appendChild(script);

  window.dataLayer = window.dataLayer || [];
  function gtag(...args: any[]) {
    window.dataLayer.push(arguments);
  }
  (window as any).gtag = gtag;
  gtag('js', new Date());
  gtag('config', GA_MEASUREMENT_ID);
};

// Event Tracking Helpers
export const trackEvent = (eventName: string, params?: object) => {
  if ((window as any).gtag) {
    (window as any).gtag('event', eventName, params);
  }
  console.log(`[Analytics] Event: ${eventName}`, params);
};

export const trackGoal = (goalName: string, value?: number) => {
  trackEvent('conversion', {
    event_category: 'engagement',
    event_label: goalName,
    value: value,
  });
};

declare global {
  interface Window {
    dataLayer: any[];
  }
}
