import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export interface AnalyticsData {
  traffic: { date: string; visitors: number; bounces: number }[];
  conversions: { type: string; count: number; rate: number }[];
  topPages: { path: string; views: number }[];
}

export const generateMarketingInsights = async (data: AnalyticsData) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Analyze this marketing data and provide 3-4 actionable insights for a marketing manager. 
      Focus on conversion optimization and traffic trends.
      
      Data: ${JSON.stringify(data)}
      
      Format the response in clear Markdown with bullet points.`,
    });

    return response.text || "Unable to generate insights at this time.";
  } catch (error) {
    console.error("Gemini Insight Error:", error);
    return "Error generating AI insights. Please check your API configuration.";
  }
};
