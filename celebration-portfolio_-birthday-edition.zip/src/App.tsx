/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import Timeline from "./components/Timeline";
import Dashboard from "./components/Dashboard";
import WishWall from "./components/WishWall";
import GiftGenerator from "./components/GiftGenerator";
import { Mail, Github, Linkedin, ExternalLink, Sparkles } from "lucide-react";

export default function App() {
  return (
    <div className="min-h-screen bg-white selection:bg-indigo-100 selection:text-indigo-900">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-neutral-100">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold">B</div>
            <span className="font-bold tracking-tight text-neutral-900">Celebration.io</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-neutral-500">
            <a href="#timeline" className="hover:text-indigo-600 transition-colors">Timeline</a>
            <a href="#dashboard" className="hover:text-indigo-600 transition-colors">Dashboard</a>
            <a href="#wishwall" className="hover:text-indigo-600 transition-colors">Wish Wall</a>
            <a href="#giftgen" className="hover:text-indigo-600 transition-colors">Gift Gen</a>
          </div>
          <a 
            href="mailto:kashmirirajpoot128@gmail.com" 
            className="px-5 py-2 bg-neutral-900 text-white rounded-full text-sm font-bold hover:bg-neutral-800 transition-all shadow-lg shadow-neutral-200"
          >
            Hire Me
          </a>
        </div>
      </nav>

      {/* Hero Section */}
      <header className="pt-32 pb-20 px-6 overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-xs font-bold uppercase tracking-widest mb-6">
                <Sparkles size={12} />
                The Ultimate Birthday Portfolio
              </div>
              <h1 className="text-6xl md:text-8xl font-bold tracking-tighter text-neutral-900 leading-[0.9] mb-8">
                Celebrating <span className="text-indigo-600">Friendship</span> Through Code.
              </h1>
              <p className="text-xl text-neutral-500 leading-relaxed max-w-lg mb-10">
                A high-performance birthday experience built to showcase React mastery, 
                real-time data, and AI integration. Perfect for friends, even better for business.
              </p>
              <div className="flex flex-wrap gap-4">
                <a href="#timeline" className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-200">
                  Explore the Journey
                </a>
                <a href="#wishwall" className="px-8 py-4 bg-white text-neutral-900 border border-neutral-200 rounded-2xl font-bold hover:bg-neutral-50 transition-all">
                  Leave a Wish
                </a>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.8, rotate: 5 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              transition={{ duration: 1, delay: 0.2 }}
              className="relative"
            >
              <div className="aspect-square bg-indigo-100 rounded-[60px] overflow-hidden shadow-2xl relative z-10">
                <img 
                  src="https://picsum.photos/seed/birthday/1000/1000" 
                  alt="Birthday Celebration" 
                  className="w-full h-full object-cover mix-blend-multiply opacity-80"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-indigo-900/50 to-transparent"></div>
                <div className="absolute bottom-10 left-10 right-10 text-white">
                  <div className="text-4xl font-serif italic mb-2">"Code is temporary, friendship is constant."</div>
                  <div className="text-sm font-mono opacity-80 uppercase tracking-widest">— The Developer</div>
                </div>
              </div>
              <div className="absolute -top-10 -right-10 w-40 h-40 bg-yellow-400 rounded-full blur-3xl opacity-30 animate-pulse"></div>
              <div className="absolute -bottom-10 -left-10 w-60 h-60 bg-indigo-400 rounded-full blur-3xl opacity-20"></div>
            </motion.div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main>
        <Timeline />
        <Dashboard />
        <WishWall />
        <GiftGenerator />
      </main>

      {/* Footer / Hire Me CTA */}
      <footer className="bg-neutral-900 text-white py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-20 items-center">
            <div>
              <h2 className="text-5xl font-bold tracking-tight mb-8">Like what you see? <br/><span className="text-indigo-400">Let's build something together.</span></h2>
              <p className="text-neutral-400 text-lg leading-relaxed mb-10">
                This project demonstrates my ability to handle complex UI, real-time databases, 
                and AI integrations. If you need a custom web application that stands out, 
                I'm currently available for freelance projects.
              </p>
              <div className="flex gap-6">
                <a href="#" className="p-3 bg-neutral-800 rounded-xl hover:bg-neutral-700 transition-colors"><Github size={24} /></a>
                <a href="#" className="p-3 bg-neutral-800 rounded-xl hover:bg-neutral-700 transition-colors"><Linkedin size={24} /></a>
                <a href="mailto:kashmirirajpoot128@gmail.com" className="p-3 bg-neutral-800 rounded-xl hover:bg-neutral-700 transition-colors"><Mail size={24} /></a>
              </div>
            </div>

            <div className="bg-neutral-800 p-10 rounded-[40px] border border-neutral-700 shadow-2xl">
              <h3 className="text-2xl font-bold mb-6">Quick Hire</h3>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-indigo-500/20 rounded-xl flex items-center justify-center text-indigo-400 shrink-0">
                    <ExternalLink size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">SaaS Dashboards</h4>
                    <p className="text-sm text-neutral-400">Complex data visualization and management tools.</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-green-500/20 rounded-xl flex items-center justify-center text-green-400 shrink-0">
                    <ExternalLink size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Real-time Apps</h4>
                    <p className="text-sm text-neutral-400">Chat, collaboration, and live-sync features.</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-purple-500/20 rounded-xl flex items-center justify-center text-purple-400 shrink-0">
                    <ExternalLink size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">AI Integration</h4>
                    <p className="text-sm text-neutral-400">LLM-powered features and smart automation.</p>
                  </div>
                </div>
                <a 
                  href="mailto:kashmirirajpoot128@gmail.com" 
                  className="block w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white text-center font-bold rounded-2xl transition-all mt-8"
                >
                  Start a Project
                </a>
              </div>
            </div>
          </div>

          <div className="mt-20 pt-10 border-t border-neutral-800 flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-indigo-600 rounded flex items-center justify-center text-white text-[10px] font-bold">B</div>
              <span className="text-sm font-bold tracking-tight">Celebration.io</span>
            </div>
            <p className="text-neutral-500 text-sm font-mono">© 2026 Built with React, Tailwind, & ❤️</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
