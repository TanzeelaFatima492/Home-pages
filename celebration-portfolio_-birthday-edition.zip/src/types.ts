export interface Wish {
  id: string;
  author: string;
  message: string;
  color: string;
  createdAt: any;
}

export interface TimelineItem {
  id: string;
  year: string;
  title: string;
  description: string;
  image?: string;
}

export interface FriendStat {
  label: string;
  value: number;
  category: string;
}
