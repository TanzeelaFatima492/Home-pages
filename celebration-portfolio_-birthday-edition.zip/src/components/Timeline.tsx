import { motion } from "motion/react";
import { TimelineItem } from "../types";

const timelineData: TimelineItem[] = [
  {
    id: "1",
    year: "2020",
    title: "The First Meet",
    description: "Met at a local tech meetup. Bonded over a shared love for React and terrible coffee.",
    image: "https://picsum.photos/seed/meetup/800/600"
  },
  {
    id: "2",
    year: "2021",
    title: "First Project Together",
    description: "Built a hackathon project in 48 hours. We didn't win, but we didn't kill each other either.",
    image: "https://picsum.photos/seed/hackathon/800/600"
  },
  {
    id: "3",
    year: "2022",
    title: "The Road Trip",
    description: "Drove 1000 miles across the coast. 3 flat tires, 12 playlists, and 0 regrets.",
    image: "https://picsum.photos/seed/roadtrip/800/600"
  },
  {
    id: "4",
    year: "2023",
    title: "Gaming Marathon",
    description: "Stayed up for 36 hours straight to beat the final boss. We were legends for a day.",
    image: "https://picsum.photos/seed/gaming/800/600"
  },
  {
    id: "5",
    year: "2024",
    title: "The Big Move",
    description: "Helped each other move to new cities. Still connected via Discord every single night.",
    image: "https://picsum.photos/seed/moving/800/600"
  }
];

export default function Timeline() {
  return (
    <section id="timeline" className="py-20 bg-neutral-50">
      <div className="max-w-4xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold tracking-tight text-neutral-900 mb-4">Our Journey</h2>
          <p className="text-neutral-500 italic serif text-lg">A trip down memory lane, built with precision.</p>
        </div>

        <div className="relative border-l-2 border-neutral-200 ml-4 md:ml-0 md:left-1/2">
          {timelineData.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className={`relative mb-12 md:w-1/2 ${index % 2 === 0 ? "md:pr-12 md:text-right md:ml-auto" : "md:pl-12 md:mr-auto"}`}
            >
              <div className={`absolute top-0 w-4 h-4 bg-neutral-900 rounded-full border-4 border-white -left-[9px] md:left-auto ${index % 2 === 0 ? "md:-left-[9px]" : "md:-right-[9px]"}`} />
              
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-neutral-100 hover:shadow-md transition-shadow">
                <span className="text-xs font-mono font-bold text-neutral-400 uppercase tracking-widest">{item.year}</span>
                <h3 className="text-xl font-bold text-neutral-900 mt-1 mb-3">{item.title}</h3>
                <img 
                  src={item.image} 
                  alt={item.title} 
                  className="w-full h-48 object-cover rounded-xl mb-4"
                  referrerPolicy="no-referrer"
                />
                <p className="text-neutral-600 leading-relaxed">{item.description}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-20 text-center">
          <div className="inline-flex items-center px-4 py-2 bg-neutral-900 text-white rounded-full text-xs font-mono">
            <span className="mr-2">⚡</span>
            Built with React & Framer Motion for 60FPS Storytelling
          </div>
        </div>
      </div>
    </section>
  );
}
