import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { motion } from 'motion/react';

const statsData = [
  { label: 'Coffees Shared', value: 3450, color: '#8B4513' },
  { label: 'Gaming Hours', value: 8000, color: '#4B0082' },
  { label: 'Road Trip Miles', value: 12000, color: '#2E8B57' },
  { label: 'Inside Jokes', value: 156, color: '#FFD700' },
  { label: 'Failed Projects', value: 12, color: '#DC143C' },
];

export default function Dashboard() {
  return (
    <section id="dashboard" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-center">
          <div className="lg:col-span-1">
            <h2 className="text-4xl font-bold tracking-tight text-neutral-900 mb-6">The Friendship Dashboard</h2>
            <p className="text-neutral-600 mb-8 leading-relaxed">
              Data doesn't lie. Our friendship has been a high-growth asset since 2020. 
              This visualization proves I can build complex SaaS dashboards for your business.
            </p>
            <div className="space-y-4">
              {statsData.map((stat) => (
                <div key={stat.label} className="flex justify-between items-center p-3 bg-neutral-50 rounded-xl border border-neutral-100">
                  <span className="text-sm font-medium text-neutral-700">{stat.label}</span>
                  <span className="font-mono font-bold text-neutral-900">{stat.value.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-2 h-[400px] bg-neutral-50 p-8 rounded-3xl border border-neutral-200 shadow-inner">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={statsData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e5e5" />
                <XAxis 
                  dataKey="label" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#737373', fontSize: 12 }}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#737373', fontSize: 12 }}
                />
                <Tooltip 
                  cursor={{ fill: 'rgba(0,0,0,0.05)' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                />
                <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                  {statsData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="mt-12 flex justify-center">
          <div className="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-full text-xs font-mono">
            <span className="mr-2">📊</span>
            Powered by Recharts for Enterprise-Grade Data Viz
          </div>
        </div>
      </div>
    </section>
  );
}
