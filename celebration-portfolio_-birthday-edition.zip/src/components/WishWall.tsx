import { useState, useEffect } from 'react';
import { collection, addDoc, onSnapshot, query, orderBy, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { Wish } from '../types';
import { motion, AnimatePresence } from 'motion/react';

const COLORS = [
  'bg-yellow-100 border-yellow-200',
  'bg-blue-100 border-blue-200',
  'bg-green-100 border-green-200',
  'bg-pink-100 border-pink-200',
  'bg-purple-100 border-purple-200',
];

export default function WishWall() {
  const [wishes, setWishes] = useState<Wish[]>([]);
  const [author, setAuthor] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const q = query(collection(db, 'wishes'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const wishesData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Wish[];
      setWishes(wishesData);
    }, (error) => {
      console.error("Firestore Error: ", error);
    });

    return () => unsubscribe();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!author || !message) return;

    setIsSubmitting(true);
    try {
      const randomColor = COLORS[Math.floor(Math.random() * COLORS.length)];
      await addDoc(collection(db, 'wishes'), {
        author,
        message,
        color: randomColor,
        createdAt: serverTimestamp(),
      });
      setAuthor('');
      setMessage('');
    } catch (error) {
      console.error("Error adding wish: ", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="wishwall" className="py-20 bg-neutral-900 text-white">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold tracking-tight mb-4">Virtual Wish Wall</h2>
          <p className="text-neutral-400 italic serif text-lg">Real-time love from around the globe.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
          <div className="lg:col-span-1">
            <div className="bg-neutral-800 p-6 rounded-3xl border border-neutral-700 sticky top-24">
              <h3 className="text-xl font-bold mb-4">Leave a Wish</h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-mono uppercase tracking-widest text-neutral-500 mb-1">Your Name</label>
                  <input 
                    type="text" 
                    value={author}
                    onChange={(e) => setAuthor(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-4 py-2 focus:outline-none focus:border-indigo-500 transition-colors"
                    placeholder="John Doe"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono uppercase tracking-widest text-neutral-500 mb-1">Your Message</label>
                  <textarea 
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-4 py-2 h-32 focus:outline-none focus:border-indigo-500 transition-colors resize-none"
                    placeholder="Happy Birthday! You're the best!"
                    required
                  />
                </div>
                <button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-indigo-500/20"
                >
                  {isSubmitting ? 'Posting...' : 'Post Wish'}
                </button>
              </form>
              <div className="mt-6 pt-6 border-t border-neutral-700">
                <div className="flex items-center text-xs font-mono text-neutral-500">
                  <span className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></span>
                  Live Sync Enabled
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-3">
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              <AnimatePresence mode="popLayout">
                {wishes.map((wish) => (
                  <motion.div
                    key={wish.id}
                    layout
                    initial={{ opacity: 0, scale: 0.8, rotate: -5 }}
                    animate={{ opacity: 1, scale: 1, rotate: (Math.random() * 4 - 2) }}
                    exit={{ opacity: 0, scale: 0.5 }}
                    className={`${wish.color} p-6 rounded-lg border shadow-lg text-neutral-900 relative transform transition-transform hover:scale-105 hover:z-10`}
                  >
                    <div className="absolute top-2 right-2 w-4 h-4 bg-white/50 rounded-full blur-sm"></div>
                    <p className="font-serif italic text-lg mb-4 leading-relaxed">"{wish.message}"</p>
                    <div className="flex justify-between items-end">
                      <span className="font-bold text-sm">— {wish.author}</span>
                      <span className="text-[10px] font-mono text-neutral-500">
                        {wish.createdAt?.toDate ? wish.createdAt.toDate().toLocaleDateString() : 'Just now'}
                      </span>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        </div>

        <div className="mt-20 text-center">
          <div className="inline-flex items-center px-4 py-2 bg-neutral-800 text-neutral-400 rounded-full text-xs font-mono border border-neutral-700">
            <span className="mr-2">🔥</span>
            Real-time Full-Stack Integration with Firebase Firestore
          </div>
        </div>
      </div>
    </section>
  );
}
