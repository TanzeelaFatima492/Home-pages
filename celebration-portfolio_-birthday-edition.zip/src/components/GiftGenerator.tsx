import { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { motion, AnimatePresence } from 'motion/react';

const INTERESTS = [
  { id: 'coding', label: 'Coding', icon: '💻' },
  { id: 'music', label: 'Music', icon: '🎵' },
  { id: 'travel', label: 'Travel', icon: '✈️' },
  { id: 'gaming', label: 'Gaming', icon: '🎮' },
  { id: 'fitness', label: 'Fitness', icon: '🏃' },
  { id: 'cooking', label: 'Cooking', icon: '🍳' },
];

export default function GiftGenerator() {
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [suggestion, setSuggestion] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const toggleTag = (id: string) => {
    setSelectedTags(prev => 
      prev.includes(id) ? prev.filter(t => t !== id) : [...prev, id]
    );
  };

  const generateGift = async () => {
    if (selectedTags.length === 0) return;

    setIsLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Suggest a creative and funny birthday gift for a friend who is interested in: ${selectedTags.join(', ')}. Keep it short and witty.`,
      });
      setSuggestion(response.text || "A high-five and a pizza.");
    } catch (error) {
      console.error("AI Error: ", error);
      setSuggestion("A custom-built React app (like this one!)");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section id="giftgen" className="py-20 bg-indigo-50">
      <div className="max-w-4xl mx-auto px-6">
        <div className="bg-white p-10 rounded-[40px] shadow-xl border border-indigo-100">
          <div className="text-center mb-10">
            <h2 className="text-4xl font-bold tracking-tight text-neutral-900 mb-4">AI Gift Algorithm</h2>
            <p className="text-neutral-600">Select interests to calculate the mathematically perfect gift.</p>
          </div>

          <div className="flex flex-wrap justify-center gap-3 mb-10">
            {INTERESTS.map((interest) => (
              <button
                key={interest.id}
                onClick={() => toggleTag(interest.id)}
                className={`px-6 py-3 rounded-2xl text-sm font-bold transition-all flex items-center gap-2 ${
                  selectedTags.includes(interest.id)
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200 scale-105'
                    : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                }`}
              >
                <span>{interest.icon}</span>
                {interest.label}
              </button>
            ))}
          </div>

          <div className="flex justify-center mb-10">
            <button
              onClick={generateGift}
              disabled={isLoading || selectedTags.length === 0}
              className="px-10 py-4 bg-neutral-900 text-white rounded-2xl font-bold hover:bg-neutral-800 disabled:opacity-50 transition-all flex items-center gap-3"
            >
              {isLoading ? (
                <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
              ) : (
                <span>✨</span>
              )}
              {isLoading ? 'Calculating...' : 'Generate Perfect Gift'}
            </button>
          </div>

          <AnimatePresence mode="wait">
            {suggestion && (
              <motion.div
                key={suggestion}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-indigo-600 p-8 rounded-3xl text-white text-center shadow-2xl shadow-indigo-200"
              >
                <div className="text-xs font-mono uppercase tracking-widest opacity-60 mb-2">AI Recommendation</div>
                <p className="text-2xl font-serif italic leading-relaxed">"{suggestion}"</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="mt-12 text-center">
          <div className="inline-flex items-center px-4 py-2 bg-white text-indigo-600 rounded-full text-xs font-mono border border-indigo-100 shadow-sm">
            <span className="mr-2">🤖</span>
            Powered by Gemini 3 Flash for Complex Logic & Creativity
          </div>
        </div>
      </div>
    </section>
  );
}
