/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { GoogleGenAI } from '@google/genai';

interface Flashcard {
  term: string;
  definition: string;
  flipped?: boolean;
}

// Selectors
const topicInput = document.getElementById('topicInput') as HTMLTextAreaElement;
const generateButton = document.getElementById('generateButton') as HTMLButtonElement;
const flashcardsContainer = document.getElementById('flashcardsContainer') as HTMLDivElement;
const errorMessage = document.getElementById('errorMessage') as HTMLDivElement;
const modeIndicator = document.getElementById('modeIndicator') as HTMLDivElement;
const themeToggle = document.getElementById('themeToggle') as HTMLButtonElement;
const deckActions = document.getElementById('deckActions') as HTMLDivElement;
const shuffleButton = document.getElementById('shuffleButton') as HTMLButtonElement;
const exportButton = document.getElementById('exportButton') as HTMLButtonElement;
const exportCsvButton = document.getElementById('exportCsvButton') as HTMLButtonElement;
const clearButton = document.getElementById('clearButton') as HTMLButtonElement;
const searchInput = document.getElementById('searchInput') as HTMLInputElement;

// State
let currentDeck: Flashcard[] = [];
let filterText: string = '';

// Theme initialization
const savedTheme = localStorage.getItem('theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
document.documentElement.style.colorScheme = savedTheme;

themeToggle.addEventListener('click', () => {
  const currentTheme = document.documentElement.style.colorScheme;
  const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
  document.documentElement.style.colorScheme = newTheme;
  localStorage.setItem('theme', newTheme);
});

// Mode Detection
function detectMode(input: string): 'manual' | 'topic' {
  const trimmed = input.trim();
  if (!trimmed) return 'topic';
  const lines = trimmed.split('\n').filter(l => l.trim().length > 0);
  // Manual mode if multiple lines or if a line contains a colon
  if (lines.length > 1 || trimmed.includes(':')) return 'manual';
  return 'topic';
}

function validateManualInput(input: string): string[] {
  const errors: string[] = [];
  const lines = input.split('\n').filter(l => l.trim().length > 0);
  
  lines.forEach((line, index) => {
    if (!line.includes(':')) {
      errors.push(`Line ${index + 1}: Missing a colon (Expected "Term: Definition")`);
    } else {
      const [term, ...rest] = line.split(':');
      const definition = rest.join(':').trim();
      if (!term.trim()) errors.push(`Line ${index + 1}: Term is empty`);
      if (!definition) errors.push(`Line ${index + 1}: Definition is empty`);
    }
  });
  return errors;
}

// Render Logic
function renderDeck() {
  flashcardsContainer.textContent = '';
  
  if (currentDeck.length === 0) {
    deckActions.classList.add('hidden');
    return;
  }
  
  deckActions.classList.remove('hidden');

  // Filtering
  const filteredDeck = currentDeck.filter(card => {
    const searchLower = filterText.toLowerCase();
    return card.term.toLowerCase().includes(searchLower) || 
           card.definition.toLowerCase().includes(searchLower);
  });
  
  if (filteredDeck.length === 0 && filterText) {
    const emptyMsg = document.createElement('p');
    emptyMsg.textContent = 'No cards match your search.';
    emptyMsg.style.gridColumn = '1 / -1';
    emptyMsg.style.color = 'var(--light-text-secondary)';
    flashcardsContainer.appendChild(emptyMsg);
    return;
  }

  filteredDeck.forEach((card, index) => {
    const cardBtn = document.createElement('button');
    cardBtn.className = `flashcard ${card.flipped ? 'flipped' : ''}`;
    cardBtn.setAttribute('aria-label', `Flashcard ${index + 1}: ${card.term}`);
    
    const inner = document.createElement('div');
    inner.className = 'flashcard-inner';
    
    const front = document.createElement('div');
    front.className = 'flashcard-front';
    const termEl = document.createElement('div');
    termEl.className = 'term';
    termEl.textContent = card.term;
    front.appendChild(termEl);
    
    const back = document.createElement('div');
    back.className = 'flashcard-back';
    const defEl = document.createElement('div');
    defEl.className = 'definition';
    defEl.textContent = card.definition;
    back.appendChild(defEl);
    
    inner.appendChild(front);
    inner.appendChild(back);
    cardBtn.appendChild(inner);
    
    cardBtn.addEventListener('click', () => {
      card.flipped = !card.flipped;
      cardBtn.classList.toggle('flipped');
      saveDeck();
    });
    
    flashcardsContainer.appendChild(cardBtn);
  });
}

function saveDeck() {
  localStorage.setItem('current_deck', JSON.stringify(currentDeck));
}

function loadSavedDeck() {
  const saved = localStorage.getItem('current_deck');
  if (saved) {
    try {
      currentDeck = JSON.parse(saved);
      renderDeck();
    } catch (e) {
      console.error('Failed to load deck', e);
    }
  }
}

// Search Handler
searchInput.addEventListener('input', () => {
  filterText = searchInput.value;
  renderDeck();
});

// Actions
shuffleButton.addEventListener('click', () => {
  for (let i = currentDeck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [currentDeck[i], currentDeck[j]] = [currentDeck[j], currentDeck[i]];
  }
  renderDeck();
  saveDeck();
});

exportButton.addEventListener('click', () => {
  const text = currentDeck.map(c => `${c.term}: ${c.definition}`).join('\n');
  navigator.clipboard.writeText(text).then(() => {
    const originalText = exportButton.textContent;
    exportButton.textContent = 'Copied!';
    setTimeout(() => exportButton.textContent = originalText, 2000);
  });
});

exportCsvButton.addEventListener('click', () => {
  if (currentDeck.length === 0) return;

  // Header row
  let csvContent = "Term,Definition\n";

  // Data rows
  currentDeck.forEach(card => {
    // Escape double quotes by doubling them and wrapping values in double quotes
    const escapedTerm = `"${card.term.replace(/"/g, '""')}"`;
    const escapedDefinition = `"${card.definition.replace(/"/g, '""')}"`;
    csvContent += `${escapedTerm},${escapedDefinition}\n`;
  });

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', 'flashcards.csv');
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
});

clearButton.addEventListener('click', () => {
  if (confirm('Are you sure you want to clear your entire deck?')) {
    currentDeck = [];
    filterText = '';
    searchInput.value = '';
    renderDeck();
    localStorage.removeItem('current_deck');
    errorMessage.textContent = '';
  }
});

topicInput.addEventListener('input', () => {
  const mode = detectMode(topicInput.value);
  modeIndicator.textContent = mode === 'manual' ? '📝 Manual Entry Mode' : '💡 AI Generation Mode';
  modeIndicator.style.opacity = topicInput.value.trim() ? '1' : '0';
});

generateButton.addEventListener('click', async () => {
  const input = topicInput.value.trim();
  if (!input) {
    errorMessage.innerHTML = 'Please enter a topic or manual pairs.';
    return;
  }

  const mode = detectMode(input);
  if (mode === 'manual') {
    const errors = validateManualInput(input);
    if (errors.length > 0) {
      errorMessage.innerHTML = `<strong>Validation Errors:</strong><br>${errors.join('<br>')}`;
      return;
    }
  }

  errorMessage.textContent = '✨ Gemini is crafting your cards...';
  generateButton.disabled = true;

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    let prompt = '';
    
    if (mode === 'manual') {
      prompt = `Review and refine these flashcard pairs. Clean up any typos and ensure high-quality definitions while preserving the original meaning. Output ONLY the refined "Term: Definition" pairs, one per line.
      
      User Input:
      ${input}`;
    } else {
      prompt = `Create a study deck of 8-12 high-quality flashcards for the topic: "${input}". 
      Format: "Term: Definition" per line.
      Example:
      Gravity: A fundamental interaction which causes mutual attraction between all things with mass or energy.`;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    
    const text = response.text || '';
    const newCards: Flashcard[] = text.split('\n')
      .map(line => {
        const parts = line.split(':');
        if (parts.length >= 2) {
          const term = parts[0].trim();
          const definition = parts.slice(1).join(':').trim();
          if (term && definition) return { term, definition };
        }
        return null;
      })
      .filter((c): c is Flashcard => c !== null);

    if (newCards.length > 0) {
      currentDeck = [...newCards, ...currentDeck].slice(0, 100); // Expanded limit for search utility
      errorMessage.textContent = '';
      topicInput.value = '';
      modeIndicator.style.opacity = '0';
      renderDeck();
      saveDeck();
    } else {
      errorMessage.textContent = "Couldn't extract cards. Try being more specific with your topic.";
    }
  } catch (error: any) {
    errorMessage.textContent = `Error: ${error.message || 'The AI is currently unavailable.'}`;
  } finally {
    generateButton.disabled = false;
  }
});

// Initialize
loadSavedDeck();