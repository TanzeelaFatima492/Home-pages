export type CakeCategory = 'wedding' | 'birthday' | 'anniversary' | 'custom';

export interface CakeCategoryInfo {
  id: CakeCategory;
  title: string;
  description: string;
  image: string;
  startingPrice: number;
  popularFlavors: string[];
}

export interface GalleryItem {
  id: string;
  title: string;
  category: CakeCategory;
  description: string;
  image: string;
  tag: string;
  size?: string;
}

export interface Review {
  id: string;
  name: string;
  role?: string;
  rating: number;
  text: string;
  avatar: string;
  cakeStyle: string;
}

export interface InstagramPost {
  id: string;
  image: string;
  likes: number;
  comments: number;
  caption: string;
}

export interface CustomCakeInquiry {
  id: string;
  category: CakeCategory;
  flavor: string;
  frosting: string;
  tiers: number;
  servings: number;
  accents: string[];
  metallicFinish: 'none' | 'rose-gold' | 'gold' | 'silver';
  deliveryDate: string;
  deliveryMethod: 'pickup' | 'delivery';
  fullname: string;
  email: string;
  phone: string;
  notes?: string;
  estimatedPrice: number;
  status: 'pending' | 'reviewed' | 'approved';
  createdAt: string;
}

export interface FlavorOption {
  id: string;
  name: string;
  description: string;
  type: 'base' | 'frosting';
  additionalPrice: number;
}
