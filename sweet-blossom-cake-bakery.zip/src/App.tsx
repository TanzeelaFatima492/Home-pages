import { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import FeaturedSection from './components/FeaturedSection';
import WhyChooseUs from './components/WhyChooseUs';
import GallerySection from './components/GallerySection';
import CustomizerForm from './components/CustomizerForm';
import ReviewsSection from './components/ReviewsSection';
import InstagramFeed from './components/InstagramFeed';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';
import { CakeCategory } from './types';
import { Sparkles, Heart } from 'lucide-react';

export default function App() {
  const [selectedStudioCategory, setSelectedStudioCategory] = useState<CakeCategory>('wedding');
  const [activeSection, setActiveSection] = useState('home');
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');

  // Scroll spy effect to light up transparent navigation headers
  useEffect(() => {
    const sections = [
      'home',
      'featured',
      'why-us',
      'gallery',
      'design-studio',
      'reviews',
      'instagram',
      'contact',
    ];

    const handleScroll = () => {
      const scrollPosition = window.scrollY + 200; // Offset for navbar height

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const top = element.offsetTop;
          const height = element.offsetHeight;

          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Guide user directly to Customizer studio
  const handleFeaturedCategorySelect = (category: CakeCategory) => {
    setSelectedStudioCategory(category);
    const studioElement = document.getElementById('design-studio');
    if (studioElement) {
      studioElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleHeroStudioLaunch = () => {
    setSelectedStudioCategory('wedding');
    const studioElement = document.getElementById('design-studio');
    if (studioElement) {
      studioElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleHeroLearnMore = () => {
    const featuredElement = document.getElementById('featured');
    if (featuredElement) {
      featuredElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setShowToast(true);
    setTimeout(() => {
      setShowToast(false);
    }, 4500);
  };

  return (
    <div className="relative min-h-screen font-sans antialiased text-[#3d3430] selection:bg-rosegold-200 selection:text-rosegold-950">
      
      {/* Premium Sticky Header */}
      <Navbar
        onDesignClick={handleHeroStudioLaunch}
        activeSection={activeSection}
      />

      {/* Main Single-Screen scrolling sections */}
      <main className="w-full">
        
        {/* Section 1: Hero */}
        <HeroSection
          onLearnMoreClick={handleHeroLearnMore}
          onDesignClick={handleHeroStudioLaunch}
        />

        {/* Section 2: Featured Cake Categories */}
        <FeaturedSection
          onCategorySelectInStudio={handleFeaturedCategorySelect}
        />

        {/* Section 3: Value Propositions */}
        <WhyChooseUs />

        {/* Section 4: Design Gallery with Lightbox */}
        <GallerySection />

        {/* Section 5: Custom Cake Studio Form wrapper */}
        <CustomizerForm
          initialCategory={selectedStudioCategory}
          onSuccess={() => {
            triggerToast('Artisan Cake saved to "My Designed Masterpieces" Heart folder!');
          }}
        />

        {/* Section 6: Testimonial reviews carousel */}
        <ReviewsSection />

        {/* Section 7: Curated Square Instagram Posts */}
        <InstagramFeed />

        {/* Section 8: Address location map concierge center */}
        <ContactSection />

      </main>

      {/* Footer Section */}
      <Footer />

      {/* Dynamic Success notifications toast banner */}
      {showToast && (
        <div className="fixed bottom-6 right-6 z-55 max-w-sm glass-panel border border-rosegold-300 bg-white/95 p-4 rounded-2xl shadow-2xl flex items-center gap-3.5 animate-scaleUp">
          <div className="w-8.5 h-8.5 rounded-full bg-blossom-50 border border-blossom-100 flex items-center justify-center shrink-0">
            <Heart className="w-4.5 h-4.5 text-blossom-500 fill-blossom-400" />
          </div>
          <div>
            <h5 className="font-serif text-xs font-bold text-[#3d3430] flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-rosegold-400" />
              Recipe Formulated Successfully
            </h5>
            <p className="text-[10.5px] text-[#8c7366] leading-relaxed mt-0.5">{toastMessage}</p>
          </div>
        </div>
      )}

    </div>
  );
}
