import { CakeCategoryInfo, GalleryItem, Review, InstagramPost, FlavorOption } from './types';

export const CATEGORIES: CakeCategoryInfo[] = [
  {
    id: 'wedding',
    title: 'Wedding Masterpieces',
    description: 'Bespoke, multi-tiered artistic wonders tailored perfectly to encapsulate your eternal love story. Handcrafted with exquisite floral artistry and shimmering detailing.',
    image: '/src/assets/images/wedding_cake_featured_1780230737801.png',
    startingPrice: 350,
    popularFlavors: ['Champagne & Raspberries', 'Madagascar Vanilla Bean', 'Lavender Honey Blossom']
  },
  {
    id: 'birthday',
    title: 'Luxury Birthdays',
    description: 'Celebrate milestones with vibrant, bespoke designs adorned with delicate French macarons, luxurious edible gold elements, and customizable sugar crowns.',
    image: '/src/assets/images/birthday_cake_featured_1780230756362.png',
    startingPrice: 120,
    popularFlavors: ['Belgian Double Chocolate', 'Rose water Pistachio', 'Zesty Lemon Elderflower']
  },
  {
    id: 'anniversary',
    title: 'Romantic Anniversaries',
    description: 'Refined, elegant representations of your shared years. Minimalist clean drapes, delicate silk-styled ribbons, and sparkling metallic brush strokes.',
    image: '/src/assets/images/anniversary_cake_featured_1780230782506.png',
    startingPrice: 150,
    popularFlavors: ['Red Velvet Silk', 'Lavender Honey Blossom', 'Champagne & Raspberries']
  },
  {
    id: 'custom',
    title: 'Bespoke Sculpted Art',
    description: 'Push boundaries of edible imagination. Gravity-defying geometry, textured drapes, hand-piped customized portraits, and complete theme integration.',
    image: '/src/assets/images/custom_cake_featured_1780230804489.png',
    startingPrice: 220,
    popularFlavors: ['Benoit Pistachio Cream', 'Belgian Double Chocolate', 'Organic Zesty Lemon']
  }
];

export const GALLERY: GalleryItem[] = [
  {
    id: 'g1',
    title: 'Blossoming Romance',
    category: 'wedding',
    description: 'Four tiers of smooth white fondant with a cascading trail of delicate blush pink sugar peonies and rose gold gilding.',
    image: 'https://images.unsplash.com/photo-1535141192574-5d4897c13636?w=800&auto=format&fit=crop&q=80',
    tag: 'Signature Wedding',
    size: '4 Tiers • 120 Servings'
  },
  {
    id: 'g2',
    title: 'Gourmet Rose Pastel Macarons',
    category: 'custom',
    description: 'Crisp hand-baked French pastel macarons filled with rose-scented chocolate ganache used for bespoke cake crown styling.',
    image: 'https://images.unsplash.com/photo-1569864358642-9d1684040f43?w=800&auto=format&fit=crop&q=80',
    tag: 'Pastry Art',
    size: 'Handcrafted Bakery'
  },
  {
    id: 'g3',
    title: 'The Golden Hour Cake',
    category: 'birthday',
    description: 'A glowing luxury birthday cake featuring shimmering rose gold leaf streaks, hand-spun caramel cages, and orchids.',
    image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=800&auto=format&fit=crop&q=80',
    tag: 'Premium Birthday',
    size: '2 Tiers • 45 Servings'
  },
  {
    id: 'g4',
    title: 'Chantilly Cream Cupcake Platter',
    category: 'custom',
    description: 'Miniature luxury: fluffy lavender honey cupcakes piped with white rose velvet cream and dusted with edible rose gold flakes.',
    image: 'https://images.unsplash.com/photo-1486427944299-d1955d23e317?w=800&auto=format&fit=crop&q=80',
    tag: 'Boutique Cupcakes',
    size: 'Dozen Set • Custom Toppings'
  },
  {
    id: 'g5',
    title: 'Enchanted Forest Wedding',
    category: 'wedding',
    description: 'Rustic meets luxury with hand-textured birch bark buttercream, gilded green sugar foliage, and fresh forest berries.',
    image: 'https://images.unsplash.com/photo-1522730854338-9b8e055f074d?w=800&auto=format&fit=crop&q=80',
    tag: 'Rustic Chic',
    size: '3 Tiers • 80 Servings'
  },
  {
    id: 'g6',
    title: 'Parisian Spring High Tea',
    category: 'anniversary',
    description: 'Bespoke mini floral cakes with lemon elderflower crumb layers and classic sugar lace wrappers.',
    image: 'https://images.unsplash.com/photo-1517433456452-f9633a875f6f?w=800&auto=format&fit=crop&q=80',
    tag: 'High Tea Catering',
    size: 'Individual Servings'
  }
];

export const REVIEWS: Review[] = [
  {
    id: 'r1',
    name: 'Eleanor Vance',
    role: 'Bride',
    rating: 5,
    text: 'Sweet Blossom crafted our dream wedding cake. The champagne flavor was otherworldly, and the rose gold detailing perfectly mirrored my bridal gown accents. It truly was the absolute centerpiece of our reception.',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    cakeStyle: 'Blossoming Romance 4-Tier'
  },
  {
    id: 'r2',
    name: 'Julian de Silva',
    role: 'Anniversary Celebrant',
    rating: 5,
    text: 'For our 25th anniversary, they created a magnificent minimalist cake that looked more like modern sculpture than dessert. The attention to detail and texture was staggering. Highly recommend the Rose water Pistachio flavor!',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    cakeStyle: 'Silver Elegance Custom Sculpt'
  },
  {
    id: 'r3',
    name: 'Seraphina Hughes',
    role: 'Creative Director',
    rating: 5,
    text: 'Every single milestone event we host has a Sweet Blossom cake. They not only look like absolute works of art worthy of a magazine spread, but they taste incredibly light, fresh, and not overly sugared. Pure Parisian excellence.',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    cakeStyle: 'Luxe Macaron Birthday Drip'
  }
];

export const INSTAGRAM_POSTS: InstagramPost[] = [
  {
    id: 'i1',
    image: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=500&auto=format&fit=crop&q=80',
    likes: 1280,
    comments: 42,
    caption: 'Chiffon clouds and velvety layers. Sourcing only organic Madagascan vanilla beans for this week’s gourmet fillings. ✨🌸 #SweetBlossom'
  },
  {
    id: 'i2',
    image: 'https://images.unsplash.com/photo-1513201099705-a9746e1e201f?w=500&auto=format&fit=crop&q=80',
    likes: 942,
    comments: 15,
    caption: 'Ready for its ride home. We enclose every bespoke creation in a gorgeous rose-gold ribbon-tied boutique delivery box. 🎀🎁 #BoutiqueBakery'
  },
  {
    id: 'i3',
    image: 'https://images.unsplash.com/photo-1558265089-106f363c87ec?w=500&auto=format&fit=crop&q=80',
    likes: 1450,
    comments: 58,
    caption: 'Baking the perfect French macarons to crown our upcoming Spring Collection cakes. Rose water infusion smells like heaven. 🌹🧁 #LaVieEnRose'
  },
  {
    id: 'i4',
    image: 'https://images.unsplash.com/photo-1562266567-247b9f10dde0?w=500&auto=format&fit=crop&q=80',
    likes: 2110,
    comments: 72,
    caption: 'The golden touch. Watch our expert chef hand-apply micro-sheets of organic 24k rose-gold foil to this modern bridal tier. 💫🎂 #CakeArtistry'
  },
  {
    id: 'i5',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=500&auto=format&fit=crop&q=80',
    likes: 852,
    comments: 31,
    caption: 'High tea styling of your dreams. Our custom petite dessert bars include sugar cups, seasonal berries, and lavender macarons. ☕🧁 #LuxuryBakeries'
  },
  {
    id: 'i6',
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=500&auto=format&fit=crop&q=80',
    likes: 1195,
    comments: 47,
    caption: 'Fulfilling orders with fresh whipped swiss meringue frosting. Elegance is in the detail of every hand-drawn rosette. 🍰🌸 #PipingRoses'
  }
];

export const FLAVOR_OPTIONS: FlavorOption[] = [
  { id: 'f1', name: 'Madagascar Vanilla Bean', description: 'Infused with premium whole bean caviar and velvet cream layers.', type: 'base', additionalPrice: 0 },
  { id: 'f2', name: 'Belgian Double Chocolate', description: 'Rich 70% dark cocoa crumb filled with silken whipped chocolate mousse.', type: 'base', additionalPrice: 15 },
  { id: 'f3', name: 'Champagne & Raspberries', description: 'Moist bubbly pink layers paired with fresh organic raspberry compote.', type: 'base', additionalPrice: 25 },
  { id: 'f4', name: 'Lavender Honey Blossom', description: 'Floral lavender cake with light wildfire organic honey buttercream.', type: 'base', additionalPrice: 20 },
  { id: 'f5', name: 'Rose water Pistachio Cream', description: 'Pistachio nut crumb folded with sweet Persian rose essence layers.', type: 'base', additionalPrice: 30 },
  { id: 'f6', name: 'Red Velvet Silk', description: 'Traditional cocoa hint layers with a delicate cream cheese velvet gloss.', type: 'base', additionalPrice: 10 }
];

export const FROSTING_OPTIONS: FlavorOption[] = [
  { id: 'fr1', name: 'Rose Gold Metallic Buttercream', description: 'Silky smooth with a pearlescent blushing golden sheen.', type: 'frosting', additionalPrice: 15 },
  { id: 'fr2', name: 'Swiss Meringue Muted White', description: 'Classic, cloud-soft, ultra-light frosting with clean lines.', type: 'frosting', additionalPrice: 0 },
  { id: 'fr3', name: 'Pink Blossom Satin Gel', description: 'Vibrant strawberry paste whipped with high-shine glazing coat.', type: 'frosting', additionalPrice: 10 },
  { id: 'fr4', name: 'Dark Ganache Truffle', description: 'Decadent melted luxury chocolate glaze covering crumb coat.', type: 'frosting', additionalPrice: 20 }
];

export const ACCENT_OPTIONS = [
  { id: 'ac1', name: 'Edible Rose Gold Leaf', price: 25, icon: '✨' },
  { id: 'ac2', name: 'Sugar Crafted Peonies & Roses', price: 40, icon: '🌸' },
  { id: 'ac3', name: 'Gourmet French Macarons Set', price: 18, icon: '🧁' },
  { id: 'ac4', name: 'Shimmering White Pearl Accents', price: 12, icon: '⚪' },
  { id: 'ac5', name: 'Elegant Waterfall Chocolate Drip', price: 15, icon: '💧' },
  { id: 'ac6', name: 'Fresh Organic Berries Trio', price: 20, icon: '🍓' }
];
