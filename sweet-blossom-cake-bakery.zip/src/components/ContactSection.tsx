import React, { useState } from 'react';
import { Mail, Phone, MapPin, Clock, Calendar, Send, CheckCircle, Heart, Star } from 'lucide-react';

export default function ContactSection() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSent, setIsSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !message) {
      return;
    }
    setIsSubmitting(true);
    // Mimick send action with an organic delay
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSent(true);
      setName('');
      setEmail('');
      setPhone('');
      setMessage('');
    }, 1500);
  };

  const scheduleHours = [
    { days: 'Monday - Thursday', hours: '09:00 AM - 06:00 PM' },
    { days: 'Friday - Saturday', hours: '08:00 AM - 08:30 PM' },
    { days: 'Sunday', hours: '10:00 AM - 04:00 PM' },
  ];

  return (
    <section id="contact" className="py-24 px-6 bg-[#fbf8f5] relative overflow-hidden">
      
      {/* Background visual soft glowing nodes */}
      <div className="absolute top-[20%] right-[-15%] w-[450px] h-[450px] rounded-full bg-rosegold-100/30 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[20%] left-[-15%] w-[400px] h-[400px] rounded-full bg-blossom-50/40 blur-[130px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Title */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <span className="text-[11px] uppercase tracking-[0.25em] font-bold text-rosegold-500 bg-white px-4 py-1.5 rounded-full inline-block border border-rosegold-200 shadow-xs">
            Boutique Locations
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-gray-900 font-bold tracking-tight">
            Connect With Our <span className="italic font-normal text-rosegold-500 font-serif">Concierge</span>
          </h2>
          <div className="w-[80px] h-[1px] bg-rosegold-300 mx-auto" />
          <p className="text-sm text-gray-600 max-w-lg mx-auto leading-relaxed font-medium">
            Planning a grand wedding, anniversary banquet, or high-luxury reception? Drop us a prompt or pay a visit to our Madison Ave salon.
          </p>
        </div>

        {/* Contact Split layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
          
          {/* Left Column: Salon Details and Map Mockup */}
          <div className="lg:col-span-5 flex flex-col justify-between p-8 rounded-[32px] glass-panel border border-white/80 shadow-lg bg-linear-to-b from-white to-rosegold-50/30">
            <div className="space-y-8">
              <div>
                <h3 className="font-serif text-2xl text-[#3d3430] font-medium">Sweet Blossom Parlor</h3>
                <p className="text-xs text-[#be2146] font-semibold tracking-wide mt-1 uppercase">Madison Avenue Flagship Store</p>
              </div>

              {/* Direct lists */}
              <div className="space-y-5 text-sm">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-rosegold-50 border border-rosegold-100 flex items-center justify-center text-rosegold-500 shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <h5 className="font-semibold text-xs uppercase tracking-wider text-[#a38c81]">Salons Address</h5>
                    <p className="text-[#5d4d42] mt-0.5 font-light">
                      742 Madison Ave, Suite B, <br /> New York, NY 10021
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-rosegold-50 border border-rosegold-100 flex items-center justify-center text-rosegold-500 shrink-0">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <h5 className="font-semibold text-xs uppercase tracking-wider text-[#a38c81]">Concierge Phone</h5>
                    <p className="text-[#5d4d42] mt-0.5 font-light">
                      +1 (212) 555-0143 <br />
                      <span className="text-[11px] text-[#bd8e77] italic font-normal">Complimentary wedding consultations available</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-rosegold-50 border border-rosegold-100 flex items-center justify-center text-rosegold-500 shrink-0">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <h5 className="font-semibold text-xs uppercase tracking-wider text-[#a38c81]">Digital Mailbox</h5>
                    <p className="text-[#5d4d42] mt-0.5 font-light">
                      orders@sweetblossombakery.com
                    </p>
                  </div>
                </div>
              </div>

              {/* Operational Curation Schedules */}
              <div className="pt-6 border-t border-rosegold-150/40 space-y-4">
                <h4 className="font-serif text-base text-[#3d3430] flex items-center gap-2 font-medium">
                  <Clock className="w-4.5 h-4.5 text-rosegold-400" />
                  Boutique Curation Hours
                </h4>
                <div className="space-y-2">
                  {scheduleHours.map((sh, idx) => (
                    <div key={idx} className="flex justify-between text-xs text-[#5d4d42] border-b border-rosegold-100/30 pb-1.5 font-light">
                      <span>{sh.days}</span>
                      <strong className="text-[#3d3430] font-medium">{sh.hours}</strong>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Simulated stylized vector map */}
            <div className="mt-8 pt-6 border-t border-rosegold-150/40">
              <div className="w-full h-32 rounded-2xl bg-[#f2e9e4] border border-rosegold-200 p-2 flex items-center justify-center relative overflow-hidden group">
                <div className="absolute inset-0 bg-[radial-gradient(#bd8e77_1px,transparent_1px)] [background-size:16px_16px] opacity-40" />
                
                {/* Visual streets vector mockup */}
                <div className="absolute top-2 left-6 w-[2px] h-28 bg-white" />
                <div className="absolute top-1/2 left-2 w-72 h-[2px] bg-white -translate-y-1/2" />
                <div className="absolute bottom-6 left-16 w-14 h-[2px] bg-white" />
                
                {/* Madison Ave Label */}
                <span className="absolute left-8 top-12 text-[8px] uppercase tracking-widest text-[#a38c81] rotate-90 select-none">Madison Ave</span>
                <span className="absolute bottom-3 left-22 text-[8px] uppercase tracking-widest text-[#a38c81] select-none">East 65th St</span>

                {/* Boutique Center Marker with Ripple animation */}
                <div className="relative z-10 flex flex-col items-center">
                  <div className="w-8 h-8 rounded-full bg-blossom-500 flex items-center justify-center text-xs shadow-md border-2 border-white text-white select-none relative">
                    🌸
                    <span className="absolute inset-0 rounded-full border border-blossom-500 scale-150 animate-ping opacity-45" />
                  </div>
                  <span className="text-[9px] font-bold text-[#3d3430] mt-1 bg-white/90 backdrop-blur-md px-1.5 py-0.5 rounded-md shadow-xs border border-rosegold-100">
                    Sweet Blossom
                  </span>
                </div>
              </div>
            </div>

          </div>


          {/* Right Column: Interactive general Query Form */}
          <div className="lg:col-span-7 bg-white rounded-[32px] p-8 sm:p-10 border border-rosegold-200/40 shadow-sm flex flex-col justify-between">
            
            {!isSent ? (
              <form onSubmit={handleSubmit} className="space-y-6 flex-1 flex flex-col justify-between">
                
                <div className="space-y-2">
                  <h3 className="font-serif text-2xl text-[#3d3430] font-medium">Send Corporate / Casual Inquiries</h3>
                  <p className="text-xs text-[#8c7366] font-light">Have an event layout proposal or bespoke inquiry? Send us a brief message.</p>
                </div>

                <div className="space-y-4">
                  
                  <div className="space-y-1">
                    <label className="text-xs uppercase font-semibold text-[#a38c81] tracking-wider block">Your full Name:</label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Clara Edwards"
                      className="w-full bg-rosegold-50/50 px-4 py-3 rounded-xl text-xs border border-rosegold-100 focus:outline-none focus:border-rosegold-400 focus:bg-white transition-all"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-xs uppercase font-semibold text-[#a38c81] tracking-wider block">Email Address:</label>
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="clara@example.com"
                        className="w-full bg-rosegold-50/50 px-4 py-3 rounded-xl text-xs border border-rosegold-100 focus:outline-none focus:border-rosegold-400 focus:bg-white transition-all"
                      />
                    </div>
                    
                    <div className="space-y-1">
                      <label className="text-xs uppercase font-semibold text-[#a38c81] tracking-wider block">Phone Number (Optional):</label>
                      <input
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="+1 (212) 555-0100"
                        className="w-full bg-rosegold-50/50 px-4 py-3 rounded-xl text-xs border border-rosegold-100 focus:outline-none focus:border-rosegold-400 focus:bg-white transition-all"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs uppercase font-semibold text-[#a38c81] tracking-wider block">Your Message:</label>
                    <textarea
                      required
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Describe your cake visual theme, colors, flavor preferences or details..."
                      className="w-full bg-rosegold-50/50 px-4 py-3 rounded-xl text-xs border border-rosegold-100 focus:outline-none focus:border-rosegold-400 focus:bg-white transition-all h-36 resize-none"
                    />
                  </div>

                </div>

                <div className="pt-4 flex items-center justify-end border-t border-rosegold-50">
                  <button
                    type="submit"
                    disabled={isSubmitting || !name || !email || !message}
                    className={`btn-luxury font-semibold uppercase tracking-widest text-xs px-8 py-4 rounded-xl flex items-center gap-2.5 transition-all select-none cursor-pointer ${
                      isSubmitting || !name || !email || !message ? 'opacity-40 cursor-not-allowed' : 'btn-luxury shadow-md'
                    }`}
                  >
                    {isSubmitting ? (
                      <>
                        <span className="w-4 h-4 rounded-full border-2 border-white border-t-transparent animate-spin" />
                        Transmitting...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        Submit Message
                      </>
                    )}
                  </button>
                </div>

              </form>
            ) : (
              /* Submission Success screen */
              <div className="flex-1 flex flex-col items-center justify-center text-center p-6 space-y-4 animate-scaleUp">
                <div className="w-[100px] h-[100px] rounded-full bg-green-50/70 border border-green-200 flex items-center justify-center text-green-500 shadow-inner relative">
                  <CheckCircle className="w-12 h-12" />
                  <Heart className="w-4 h-4 text-rosegold-400 fill-rosegold-100 absolute -bottom-1 -right-1 animate-pulse" />
                </div>
                
                <h3 className="font-serif text-xl sm:text-2xl text-[#3d3430] font-medium">Bespoke Curation Sent!</h3>
                <p className="text-xs text-[#8c7366] max-w-sm mx-auto leading-relaxed font-light">
                  We received your message successfully. Our Madison parlor concierge team will contact you within 6 business hours.
                </p>

                <div className="pt-4">
                  <button
                    onClick={() => setIsSent(false)}
                    className="bg-rosegold-50 hover:bg-rosegold-100 text-[#5d4d42] px-6 py-3 rounded-xl border border-rosegold-200 text-xs font-semibold uppercase tracking-widest transition-all cursor-pointer"
                  >
                    Send Another Message
                  </button>
                </div>
              </div>
            )}

          </div>

        </div>

      </div>
    </section>
  );
}
