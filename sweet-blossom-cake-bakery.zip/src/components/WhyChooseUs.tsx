import { Apple, Eye, Truck, Sparkles, Heart, Award, ArrowRight } from 'lucide-react';

export default function WhyChooseUs() {
  const highlights = [
    {
      title: 'Esthetic Royal Designs',
      description: 'We treat cake baking as culinary canvas. Our drafts draw inspirations from botanical gardens, classical French architecture, and haute couture bridal designs.',
      icon: <Sparkles className="w-5 h-5 text-rosegold-500" />,
      tag: 'Bespoke Custom Sculptures'
    },
    {
      title: 'Premium Local Sourcing',
      description: 'Zero processed compounds. We bake with organic cage-free local eggs, organic grass-fed butter, hand-scraped Madagascan vanilla pods, and real floral purees.',
      icon: <Apple className="w-5.5 h-5.5 text-rosegold-500" />,
      tag: '100% Wholesome Ingredients'
    },
    {
      title: 'White-Glove Safe Transport',
      description: 'Your delicate sugar masterpiece travels safely inside state-of-the-art climate-cooled boutique transits, hand-placed and set up at your venue with flawless precision.',
      icon: <Truck className="w-5.5 h-5.5 text-rosegold-500" />,
      tag: 'On-Time Protected Shipping'
    },
    {
      title: 'Celebrated Cake Artisans',
      description: 'Led by French-conditioned confectionary masters, our kitchen dedicates painstaking hours to piping delicate ivory rosettes and crafting highly realistic edible petals.',
      icon: <Award className="w-5.5 h-5.5 text-rosegold-500" />,
      tag: 'Artisanal Handcraft Skill'
    }
  ];

  return (
    <section id="why-us" className="py-24 px-6 bg-[#fbf8f5] relative overflow-hidden">
      
      {/* Visual Ambient Element */}
      <div className="absolute top-0 right-[-15%] w-[500px] h-[500px] rounded-full bg-rosegold-100/35 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[20%] left-[-15%] w-[450px] h-[450px] rounded-full bg-blossom-50/40 blur-[130px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Why Choose Us Header */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center mb-16">
          <div className="lg:col-span-7 space-y-4">
            <span className="text-[11px] uppercase tracking-[0.25em] font-bold text-rosegold-500 bg-white px-4 py-1.5 rounded-full inline-block border border-rosegold-200 shadow-xs">
              Defining True Luxury
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-gray-900 font-bold tracking-tight">
              Why Epicures Celebrate <span className="italic font-normal text-rosegold-500 font-serif">Sweet Blossom</span>
            </h2>
            <div className="w-[80px] h-[1px] bg-rosegold-300" />
          </div>
          <div className="lg:col-span-5">
            <p className="text-xs sm:text-sm text-gray-600 font-medium leading-relaxed">
              We separate ourselves from traditional baking by fusing strict historical French baking systems with high-end modern design, producing desserts that are equal parts culinary masterpiece and delicious confectionery.
            </p>
          </div>
        </div>

        {/* Benefits Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10">
          {highlights.map((item, idx) => (
            <div
              key={idx}
              className="group p-8 rounded-[28px] bg-white border border-rosegold-200/80 transition-all duration-500 shadow-xs hover:shadow-lg flex flex-col md:flex-row gap-6"
            >
              {/* Luxury Icon Frame */}
              <div className="w-13 h-13 shrink-0 rounded-2xl bg-rosegold-50 border border-rosegold-100 flex items-center justify-center group-hover:scale-110 group-hover:bg-[#ffebef] group-hover:border-blossom-200 transition-all duration-300 shadow-inner">
                {item.icon}
              </div>

              {/* Text Highlights */}
              <div className="space-y-3">
                <span className="text-[10px] uppercase font-bold tracking-wider text-[#bd8e77]">
                  {item.tag}
                </span>
                <h3 className="font-serif text-lg md:text-xl text-gray-900 font-bold group-hover:text-rosegold-500 transition-colors">
                  {item.title}
                </h3>
                <p className="text-xs md:text-sm text-gray-600 leading-relaxed font-medium">
                  {item.description}
                </p>
              </div>

            </div>
          ))}
        </div>

        {/* Floating Call Out Bar */}
        <div className="mt-16 p-6 sm:p-8 rounded-[30px] glass-panel border border-white/80 shadow-md flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-lg shadow-xs select-none">
              🧁
            </div>
            <div>
              <p className="font-serif text-base sm:text-lg text-gray-900 font-bold">Have a specific design recipe in mind?</p>
              <p className="text-[11px] text-gray-600 font-medium">Bring your pinterest mood boards, we will craft edible reality.</p>
            </div>
          </div>
          <a
            href="#design-studio"
            className="w-full sm:w-auto btn-luxury px-6.5 py-3.5 rounded-full font-semibold uppercase tracking-widest text-[10px] text-center shrink-0"
          >
            Launch Design Studio
          </a>
        </div>

      </div>
    </section>
  );
}
