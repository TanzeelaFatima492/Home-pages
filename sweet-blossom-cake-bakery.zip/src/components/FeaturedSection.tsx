import { CATEGORIES } from '../data';
import { CakeCategory } from '../types';
import { Sparkles, DollarSign, ListCollapse, UtensilsCrossed, CalendarRange } from 'lucide-react';

interface FeaturedSectionProps {
  onCategorySelectInStudio: (category: CakeCategory) => void;
}

export default function FeaturedSection({ onCategorySelectInStudio }: FeaturedSectionProps) {
  return (
    <section id="featured" className="py-24 px-6 bg-white relative">
      
      {/* Delicate background decorations */}
      <div className="absolute top-[30%] right-[-10%] w-[400px] h-[400px] rounded-full bg-rosegold-100/30 blur-[130px] pointer-events-none" />
      <div className="absolute bottom-0 left-[-10%] w-[350px] h-[350px] rounded-full bg-blossom-50/50 blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <span className="text-[11px] uppercase tracking-[0.25em] font-bold text-rosegold-500 bg-rosegold-100/60 px-4 py-1.5 rounded-full inline-block border border-rosegold-200">
            Our Classic Offerings
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-gray-900 font-bold tracking-tight">
            Crafted For Golden <span className="italic font-normal text-rosegold-500">Moments</span>
          </h2>
          <div className="w-[80px] h-[1px] bg-rosegold-300 mx-auto" />
          <p className="text-sm text-gray-600 max-w-lg mx-auto leading-relaxed font-medium">
            Delve into our boutique collections. Every single cake is an individually assembled masterpiece, designed to express distinct taste palettes.
          </p>
        </div>

        {/* Featured Cakes Bento/Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10">
          {CATEGORIES.map((cat, idx) => (
            <div
              key={cat.id}
              className="group rounded-[30px] overflow-hidden border border-rosegold-200/40 bg-rosegold-50/30 p-5 lg:p-6 transition-all duration-500 hover:shadow-xl hover:translate-y-[-4px] hover:bg-white flex flex-col justify-between"
            >
              <div>
                
                {/* Category Image Wrapper with Zoom & Subtle Glow */}
                <div className="relative w-full aspect-[16/10] sm:aspect-[16/9] rounded-[24px] overflow-hidden bg-rosegold-100 shadow-inner group-hover:shadow-md transition-shadow">
                  <img
                    src={cat.image}
                    alt={cat.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-103 cursor-pointer object-center"
                    referrerPolicy="no-referrer"
                  />
                  
                  {/* Absolute Badge: Category starting price */}
                  <div className="absolute top-4 left-4 glass-panel px-3 py-1.5 rounded-full flex items-center gap-1 border border-white/60">
                    <span className="text-[10px] uppercase font-semibold tracking-wider text-[#bd8e77]">Starts at</span>
                    <strong className="text-xs font-semibold text-rosegold-600">${cat.startingPrice}</strong>
                  </div>

                  {/* Absolute Category Tag */}
                  <div className="absolute bottom-4 right-4 glass-panel px-3.5 py-1.5 rounded-full border border-white/50">
                    <p className="text-[9px] uppercase tracking-widest font-semibold text-rosegold-500 flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-rosegold-400" />
                      Collection
                    </p>
                  </div>
                </div>

                {/* Content description list */}
                <div className="mt-6 space-y-3.5">
                  <h3 className="font-serif text-xl sm:text-2xl text-gray-900 font-bold group-hover:text-rosegold-500 transition-colors">
                    {cat.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-gray-600 leading-relaxed font-medium">
                    {cat.description}
                  </p>

                  <div className="pt-4 border-t border-rosegold-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-xs">
                    <div>
                      <span className="text-[#a38c81] font-semibold text-[10px] uppercase tracking-wider block mb-1">
                        Most Demanded Flavors:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {cat.popularFlavors.map((fl, fIdx) => (
                          <span key={fIdx} className="bg-white text-xs px-2.5 py-1 rounded-full text-[#5d4d42] border border-rosegold-100/40">
                            {fl}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                </div>
              </div>

              {/* Inquiry CTA mapping directly to the Customizer */}
              <div className="mt-8 pt-4 border-t border-rosegold-100/50">
                <button
                  onClick={() => {
                    onCategorySelectInStudio(cat.id);
                  }}
                  className="w-full bg-white select-none hover:bg-rosegold-50 border border-rosegold-300 hover:border-rosegold-400 text-rosegold-600 hover:text-rosegold-700 py-3 rounded-2xl font-semibold uppercase tracking-widest text-[10px] sm:text-xs transition-all flex items-center justify-center gap-2 group/btn cursor-pointer"
                >
                  <CalendarRange className="w-4 h-4 text-rosegold-400 group-hover/btn:scale-110 transition-transform" />
                  Customize & Order
                </button>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
