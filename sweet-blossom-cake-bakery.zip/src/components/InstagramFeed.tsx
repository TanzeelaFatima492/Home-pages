import { useState } from 'react';
import { INSTAGRAM_POSTS } from '../data';
import { InstagramPost } from '../types';
import { Instagram, Heart, MessageCircle, X, ExternalLink, Copy, Check, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function InstagramFeed() {
  const [activePost, setActivePost] = useState<InstagramPost | null>(null);
  const [copiedIndex, setCopiedIndex] = useState(false);

  const handleCopyLink = (textAddress: string) => {
    navigator.clipboard.writeText(textAddress);
    setCopiedIndex(true);
    setTimeout(() => setCopiedIndex(false), 2000);
  };

  return (
    <section id="instagram" className="py-24 px-6 bg-white relative">
      <div className="max-w-7xl mx-auto">
        
        {/* Instagram Feed Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 bg-rosegold-100/60 px-4 py-1.5 rounded-full border border-rosegold-200 text-xs tracking-widest uppercase font-bold text-rosegold-500">
            <Instagram className="w-4 h-4 text-rosegold-400" />
            Social Lookbooks
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-gray-900 font-bold tracking-tight">
            Follow Our Sugar <span className="italic font-normal text-rosegold-500 font-serif">Adventures</span>
          </h2>
          <div className="w-[80px] h-[1px] bg-rosegold-300 mx-auto" />
          <p className="text-sm text-rosegold-500 font-bold tracking-wider">
            @SweetBlossomBoutique
          </p>
        </div>

        {/* Six Square Instagram Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 lg:gap-6">
          {INSTAGRAM_POSTS.map((post) => (
            <div
              key={post.id}
              onClick={() => setActivePost(post)}
              className="group aspect-square relative rounded-2xl overflow-hidden shadow-inner border border-neutral-100 bg-neutral-100 cursor-pointer"
            >
              {/* Image */}
              <img
                src={post.image}
                alt={post.caption}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-103"
                referrerPolicy="no-referrer"
              />

              {/* Tint Overlay on Hover */}
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-6 text-white font-medium text-xs sm:text-sm">
                <span className="flex items-center gap-1.5 scale-95 group-hover:scale-100 transition-transform duration-300">
                  <Heart className="w-5.5 h-5.5 fill-white stroke-white" />
                  {post.likes}
                </span>
                <span className="flex items-center gap-1.5 scale-95 group-hover:scale-100 transition-transform duration-300">
                  <MessageCircle className="w-5.5 h-5.5 fill-white stroke-white" />
                  {post.comments}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Footer Link out badge */}
        <div className="mt-12 text-center">
          <a
            href="https://instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-rosegold-50 hover:bg-rosegold-100 text-[#5d4d42] px-6 py-3 rounded-xl border border-rosegold-200 text-xs font-semibold uppercase tracking-widest transition-all"
          >
            Visit Instagram Feed <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

      </div>

      {/* Instagram Post Detail Modal */}
      <AnimatePresence>
        {activePost && (
          <div className="fixed inset-0 z-55 flex items-center justify-center p-4">
            {/* Modal backing */}
            <motion.div
              className="absolute inset-0 bg-black/80 backdrop-blur-3xs"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setActivePost(null)}
            />

            {/* Modal Box */}
            <motion.div
              className="relative w-full max-w-xl bg-white rounded-[28px] overflow-hidden shadow-2xl z-20 border border-rosegold-100"
              initial={{ scale: 0.92, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.92, opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              
              <button
                onClick={() => setActivePost(null)}
                className="absolute top-4.5 right-4.5 p-1.5 rounded-full hover:bg-neutral-150 text-neutral-500 z-10 transition-colors"
              >
                <X className="w-5.5 h-5.5" />
              </button>

              <div className="flex flex-col">
                
                {/* Header Profile Info inside Modal */}
                <div className="p-4 border-b border-rosegold-100 flex items-center gap-3 bg-rosegold-50/50">
                  <div className="w-9 h-9 rounded-full bg-linear-to-tr from-yellow-400 via-pink-500 to-purple-600 p-0.5 shadow-sm">
                    <img
                      src="https://images.unsplash.com/photo-1544025162-d76694265947?w=100&auto=format&fit=crop&q=80"
                      alt="Brand Avatar"
                      className="w-full h-full rounded-full object-cover border border-white"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-[#3d3430]">Sweet Blossom Cake Boutique</h4>
                    <p className="text-[9px] uppercase tracking-wider text-rosegold-500 font-semibold font-mono">Boutique Kitchen • Paris & NYC</p>
                  </div>
                </div>

                {/* Aspect Image */}
                <div className="w-full aspect-square bg-neutral-900 overflow-hidden">
                  <img
                    src={activePost.image}
                    alt={activePost.caption}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* Bottom Details panel */}
                <div className="p-6 space-y-4">
                  {/* Likes / Comments Counters bar */}
                  <div className="flex items-center justify-between text-[#5d4d42] border-b border-rosegold-50 pb-3">
                    <div className="flex items-center gap-4 text-xs">
                      <span className="flex items-center gap-1 font-semibold text-rosegold-600">
                        <Heart className="w-4 h-4 fill-rosegold-400 stroke-rosegold-500" />
                        {activePost.likes} Likes
                      </span>
                      <span className="flex items-center gap-1 text-[#8c7366]">
                        <MessageCircle className="w-4 h-4" />
                        {activePost.comments} Comments
                      </span>
                    </div>
                    <span className="text-[10px] text-neutral-400 font-semibold">Posted June 2026</span>
                  </div>

                  {/* Caption statement */}
                  <div className="space-y-2">
                    <p className="text-[12.5px] text-[#3d3430] leading-relaxed font-light">
                      {activePost.caption}
                    </p>
                  </div>

                  {/* Share / Copy area */}
                  <div className="pt-2 border-t border-rosegold-50 flex items-center justify-between gap-3 text-xs">
                    <span className="text-[#a38c81] text-[10px] uppercase font-semibold">Share lookback URL:</span>
                    <button
                      onClick={() => handleCopyLink(`https://instagram.com/p/${activePost.id}`)}
                      className="inline-flex items-center gap-1 text-rosegold-600 hover:text-rosegold-700 bg-rosegold-50 px-3 py-1.5 rounded-lg border border-rosegold-100 cursor-pointer"
                    >
                      {copiedIndex ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-green-500" />
                          Copied!
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          Copy Post Link
                        </>
                      )}
                    </button>
                  </div>

                </div>

              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </section>
  );
}
