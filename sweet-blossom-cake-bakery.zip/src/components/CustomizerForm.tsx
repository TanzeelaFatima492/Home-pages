import React, { useState, useEffect } from 'react';
import { FLAVOR_OPTIONS, FROSTING_OPTIONS, ACCENT_OPTIONS, CATEGORIES } from '../data';
import { CakeCategory, CustomCakeInquiry } from '../types';
import { Sparkles, Calendar, User, Phone, Mail, ChevronRight, ChevronLeft, CreditCard, RotateCcw, Heart, Truck, ShoppingBag, Check } from 'lucide-react';

interface CustomizerFormProps {
  initialCategory: CakeCategory;
  onSuccess: () => void;
}

export default function CustomizerForm({ initialCategory, onSuccess }: CustomizerFormProps) {
  const [step, setStep] = useState(1);
  const [category, setCategory] = useState<CakeCategory>(initialCategory);
  
  // Custom design states
  const [selectedFlavor, setSelectedFlavor] = useState(FLAVOR_OPTIONS[0]);
  const [selectedFrosting, setSelectedFrosting] = useState(FROSTING_OPTIONS[1]);
  const [tiers, setTiers] = useState<number>(2);
  const [servings, setServings] = useState<number>(25);
  const [metallicFinish, setMetallicFinish] = useState<'none' | 'rose-gold' | 'gold' | 'silver'>('none');
  const [selectedAccents, setSelectedAccents] = useState<string[]>([]);
  
  // Delivery states
  const [deliveryDate, setDeliveryDate] = useState('');
  const [deliveryMethod, setDeliveryMethod] = useState<'pickup' | 'delivery'>('pickup');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');
  
  // Submission success state
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submittedInquiry, setSubmittedInquiry] = useState<CustomCakeInquiry | null>(null);

  // Sync category prop updates
  useEffect(() => {
    setCategory(initialCategory);
  }, [initialCategory]);

  // Handle guest servings when tiers change to keep estimates reasonable
  useEffect(() => {
    const minServings = tiers === 1 ? 10 : tiers === 2 ? 25 : tiers === 3 ? 60 : 100;
    if (servings < minServings) {
      setServings(minServings);
    }
  }, [tiers]);

  // Dynamic live pricing engine based on selected assets
  const calculateTotal = () => {
    let price = 0;
    // Base category staring cost
    const catInfo = CATEGORIES.find(c => c.id === category);
    if (catInfo) {
      price += catInfo.startingPrice;
    }

    // Additional flavor premiums
    price += selectedFlavor.additionalPrice;
    price += selectedFrosting.additionalPrice;

    // Multi-tier compounding (adds $50 per additional tier)
    price += (tiers - 1) * 60;

    // Servings compounding (adds $3 per servings above category base guest limit)
    const baseServings = tiers === 1 ? 10 : tiers === 2 ? 25 : tiers === 3 ? 60 : 100;
    if (servings > baseServings) {
      price += (servings - baseServings) * 3;
    }

    // Metallic Finish add-on
    if (metallicFinish !== 'none') {
      price += 30;
    }

    // Accents pricing array sum
    selectedAccents.forEach(accentName => {
      const match = ACCENT_OPTIONS.find(ac => ac.name === accentName);
      if (match) {
        price += match.price;
      }
    });

    // Shipping surcharge
    if (deliveryMethod === 'delivery') {
      price += 45;
    }

    return price;
  };

  const currentPrice = calculateTotal();

  const handleAccentToggle = (accentName: string) => {
    if (selectedAccents.includes(accentName)) {
      setSelectedAccents(prev => prev.filter(t => t !== accentName));
    } else {
      setSelectedAccents(prev => [...prev, accentName]);
    }
  };

  const handleReset = () => {
    setStep(1);
    setSelectedFlavor(FLAVOR_OPTIONS[0]);
    setSelectedFrosting(FROSTING_OPTIONS[1]);
    setTiers(2);
    setServings(25);
    setMetallicFinish('none');
    setSelectedAccents([]);
    setDeliveryDate('');
    setDeliveryMethod('pickup');
    setFullName('');
    setEmail('');
    setPhone('');
    setNotes('');
    setIsSubmitted(false);
    setSubmittedInquiry(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !email || !phone || !deliveryDate) {
      // Basic safeguard
      return;
    }

    const newInquiry: CustomCakeInquiry = {
      id: 'blossom-' + Date.now().toString(36),
      category,
      flavor: selectedFlavor.name,
      frosting: selectedFrosting.name,
      tiers,
      servings,
      accents: selectedAccents,
      metallicFinish,
      deliveryDate,
      deliveryMethod,
      fullname: fullName,
      email,
      phone,
      notes,
      estimatedPrice: currentPrice,
      status: 'pending',
      createdAt: new Date().toLocaleDateString(),
    };

    // Storing in localstorage to create a beautiful unified, durable state experience
    const existing = localStorage.getItem('sweet_blossom_inquiries');
    let inquiriesList: CustomCakeInquiry[] = [];
    if (existing) {
      try {
        inquiriesList = JSON.parse(existing);
      } catch (e) {
        console.error(e);
      }
    }
    inquiriesList.unshift(newInquiry);
    localStorage.setItem('sweet_blossom_inquiries', JSON.stringify(inquiriesList));

    // Dispatching event for Navbar state updater
    window.dispatchEvent(new Event('sweet_blossom_inquiry_added'));

    // Loading results
    setSubmittedInquiry(newInquiry);
    setIsSubmitted(true);
    onSuccess();
  };

  // Select visual decoration nodes to display on stacked rendering
  const getFrostingGradient = () => {
    if (selectedFrosting.id === 'fr1') return 'bg-gradient-to-tr from-[#cca592] via-[#e3d2c8] to-[#cca592] shadow-md border-rose-200 animate-shimmer bg-[size_200%_auto]';
    if (selectedFrosting.id === 'fr3') return 'bg-gradient-to-b from-[#ffa3b7] to-[#ffccd8] shadow-sm border-pink-100';
    if (selectedFrosting.id === 'fr4') return 'bg-gradient-to-b from-[#3a2c28] to-[#4e3d30] shadow-md border-[#3a2c28]';
    return 'bg-gradient-to-b from-white to-neutral-100/90 shadow-sm border-neutral-200';
  };

  // Generate tier stack array
  const renderStackedTiers = () => {
    const tierElements = [];
    const colorClass = getFrostingGradient();
    
    // Width classes index matching dimensions
    const widthClasses = ['w-24', 'w-36', 'w-48', 'w-56'];

    for (let i = tiers; i >= 1; i--) {
      // Custom height
      const height = 'h-9 sm:h-11';
      // Shift indices to build matching proportions
      const wClass = widthClasses[i - 1];

      tierElements.push(
        <div key={i} className="flex flex-col items-center relative select-none">
          {/* Main Tier Box */}
          <div
            className={`rounded-t-lg rounded-b-md ${wClass} ${height} ${colorClass} border-x border-t relative flex items-center justify-center transition-all duration-500`}
          >
            {/* Embedded Accent Layer */}
            {selectedAccents.includes('Edible Rose Gold Leaf') && (
              <div className="absolute inset-0 bg-radial-to-t from-transparent to-[#ffe6eb]/20 flex flex-wrap gap-1 px-3 py-1 pointer-events-none overflow-hidden opacity-80">
                <span className="text-[7px] text-[#dfbc99] animate-pulse">✨</span>
                <span className="text-[6px] text-[#cca592] absolute top-1 right-3">✨</span>
                <span className="text-[5px] text-[#cca592] absolute bottom-1.5 left-2">✨</span>
              </div>
            )}

            {/* Drip Accents */}
            {selectedAccents.includes('Elegant Waterfall Chocolate Drip') && (
              <div className="absolute top-0 left-0 w-full h-full pointer-events-none flex justify-around">
                <div className="w-1.5 h-3 bg-[#3d2f2b]/80 rounded-b-full" />
                <div className="w-1 h-5 bg-[#3d2f2b]/80 rounded-b-full -translate-x-1" />
                <div className="w-1.5 h-4 bg-[#3d2f2b]/80 rounded-b-full translate-x-2" />
                <div className="w-1 h-2.5 bg-[#3d2f2b]/80 rounded-b-full" />
              </div>
            )}

            {/* Sugar Pearls Decoration along bottom border */}
            {selectedAccents.includes('Shimmering White Pearl Accents') && (
              <div className="absolute bottom-0 left-0 w-full h-[3px] flex justify-between px-1 pointer-events-none opacity-80 z-10">
                {Array.from({ length: 15 }).map((_, pIdx) => (
                  <div key={pIdx} className="w-[3px] h-[3px] rounded-full bg-white shadow-xs" />
                ))}
              </div>
            )}

            {/* Inner text signaling tier level */}
            <span className={`text-[9px] uppercase tracking-widest font-semibold ${selectedFrosting.id === 'fr4' ? 'text-rosegold-50 opacity-40' : 'text-rosegold-900/40'}`}>
              Tier {i}
            </span>
          </div>

          {/* Rose flower decorations clustered on left side of tier */}
          {selectedAccents.includes('Sugar Crafted Peonies & Roses') && i === 1 && (
            <span className="absolute -left-3 -bottom-1 text-base sm:text-lg animate-float">🌸</span>
          )}
          {selectedAccents.includes('Sugar Crafted Peonies & Roses') && i === Math.ceil(tiers / 2) && (
            <span className="absolute -right-3 -top-2.5 text-base sm:text-lg animate-float-delayed">🌸</span>
          )}

          {/* Macarons decor clustered on sides of tiers */}
          {selectedAccents.includes('Gourmet French Macarons Set') && i === 1 && (
            <span className="absolute -right-2 bottom-0 text-sm select-none">🧁</span>
          )}
        </div>
      );
    }
    return tierElements;
  };

  return (
    <section id="design-studio" className="py-24 px-6 bg-gradient-to-b from-[#faf7f5] via-[#fffbfb] to-[#faf7f5] relative">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Title */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <span className="text-[11px] uppercase tracking-[0.25em] font-bold text-rosegold-500 bg-rosegold-100/60 px-4 py-1.5 rounded-full inline-block border border-rosegold-200">
            Bespoke Confectionery
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-gray-900 font-bold tracking-tight">
            Design Your <span className="italic font-normal text-rosegold-500 font-serif">Dream Cake</span>
          </h2>
          <div className="w-[80px] h-[1px] bg-rosegold-300 mx-auto" />
          <p className="text-sm text-gray-600 max-w-lg mx-auto leading-relaxed font-medium">
            Our luxury visual customizer allows you to stack tiers, select organic fillings, apply rose gold leafing, and receive an instant structural estimate.
          </p>
        </div>

        {/* Customizer Layout Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
          
          {/* Left Side: Real-Time Custom Cake Visual Preview Card */}
          <div className="lg:col-span-5 flex flex-col justify-between p-8 rounded-[32px] glass-panel border border-white/70 shadow-lg relative overflow-hidden min-h-[460px] lg:min-h-auto bg-gradient-to-b from-white to-rosegold-50/40">
            {/* Background delicate circle badge */}
            <div className="absolute -top-12 -left-12 w-48 h-48 rounded-full bg-blossom-100/30 blur-[60px] pointer-events-none" />
            <div className="absolute -bottom-10 -right-10 w-44 h-44 rounded-full bg-rosegold-200/20 blur-[50px] pointer-events-none" />

            <div className="relative z-10 w-full">
              
              {/* Header card details */}
              <div className="flex justify-between items-start mb-8 pb-4 border-b border-rosegold-100/50">
                <div>
                  <span className="text-[10px] uppercase font-bold tracking-widest text-[#bd8e77] block">
                    Sweet Blossom
                  </span>
                  <h4 className="font-serif text-base text-[#3d3430] capitalize">
                    {category} Edition Recipe
                  </h4>
                </div>
                <div className="text-right">
                  <span className="text-[9px] uppercase tracking-wider text-neutral-400 block">Est. Invoice</span>
                  <strong className="text-xl font-bold text-rosegold-600">${currentPrice}</strong>
                </div>
              </div>

              {/* Dynamic Interactive Tier Visualizer Area */}
              <div className="h-64 flex flex-col justify-end items-center pb-8 border-b border-rosegold-100/40 relative">
                
                {/* Visual cake silver serving tray base */}
                <div className="w-64 h-2 rounded-t-lg bg-linear-to-r from-neutral-300 via-neutral-100 to-neutral-300 border-b border-neutral-400 opacity-90 absolute bottom-6 flex items-center justify-center">
                  <div className="w-16 h-1 bg-white/40 absolute top-0.5" />
                </div>
                
                {/* Dynamically piled custom Tiers */}
                <div className="space-y-1 z-10 mb-8 flex flex-col items-center">
                  {renderStackedTiers()}
                </div>

                {/* Sparkling dust if gold metallic is chosen */}
                {metallicFinish !== 'none' && (
                  <div className="absolute inset-x-8 top-12 bottom-12 border border-transparent flex justify-around pointer-events-none select-none text-xs text-rosegold-400 opacity-60">
                    <span className="animate-float">✨</span>
                    <span className="animate-float-delayed mt-8">✨</span>
                    <span className="animate-float mt-16">✨</span>
                  </div>
                )}
              </div>

              {/* Detailed Active Ingredients List */}
              <div className="mt-6 space-y-2 text-xs">
                <div className="flex justify-between text-[#5d4d42]">
                  <span>Sponge Cake Flavor:</span>
                  <strong className="text-[#3d3430]">{selectedFlavor.name}</strong>
                </div>
                <div className="flex justify-between text-[#5d4d42]">
                  <span>Applied Frosting:</span>
                  <strong className="text-[#3d3430]">{selectedFrosting.name}</strong>
                </div>
                {metallicFinish !== 'none' && (
                  <div className="flex justify-between text-[#5d4d42]">
                    <span>Foil Lamination:</span>
                    <strong className="text-[#3d3430] capitalize">{metallicFinish} micro-leaf</strong>
                  </div>
                )}
                {selectedAccents.length > 0 && (
                  <div className="flex flex-col gap-1 pt-1.5 justify-between">
                    <span className="text-[#a38c81] font-semibold text-[10px] uppercase tracking-widest block mb-0.5">Applied Visual Garnishes:</span>
                    <div className="flex flex-wrap gap-1">
                      {selectedAccents.map((acc, index) => (
                        <span key={index} className="bg-white px-2 py-0.5 rounded-full text-[10px] text-[#5d4d42] border border-rosegold-100 shadow-3xs uppercase tracking-[0.05em]">
                          {acc}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

            </div>

            {/* Quick Helper Notes */}
            <div className="mt-8 pt-4 border-t border-rosegold-100/50 text-[10px] text-center text-[#998075] italic font-light z-10 flex items-center justify-center gap-2">
              <ShoppingBag className="w-3.5 h-3.5 text-rosegold-400" />
              Includes custom signature display case with delivery wrapper.
            </div>

          </div>


          {/* Right Side: Step-by-Step Interactive Form Wizard */}
          <div className="lg:col-span-7 bg-white rounded-[32px] p-8 border border-rosegold-200/40 shadow-sm flex flex-col justify-between">
            
            {/* Wizard Steps indicator */}
            <div className="flex items-center justify-between mb-8 pb-4 border-b border-rosegold-100/60 text-xs">
              <div className="flex items-center gap-1.5 md:gap-2.5 overflow-x-auto pb-1 max-w-full">
                {[1, 2, 3, 4, 5].map((sIndex) => (
                  <button
                    key={sIndex}
                    onClick={() => setStep(sIndex)}
                    className={`shrink-0 w-8 h-8 rounded-full font-bold flex items-center justify-center transition-all ${
                      step === sIndex
                        ? 'bg-rosegold-500 text-white shadow-md'
                        : step > sIndex
                        ? 'bg-[#ffeef2] text-[#be2146] border border-[#ffccd8]'
                        : 'bg-neutral-50 text-neutral-400 border border-neutral-200'
                    }`}
                  >
                    {step > sIndex ? <Check className="w-3.5 h-3.5" /> : sIndex}
                  </button>
                ))}
              </div>
              <button
                onClick={handleReset}
                className="text-[10px] tracking-wider uppercase font-semibold text-[#8c7366] hover:text-rosegold-500 transition-colors flex items-center gap-1 shrink-0"
              >
                <RotateCcw className="w-3 h-3" /> Reset
              </button>
            </div>


            {/* Main Interactive Form block */}
            {!isSubmitted ? (
              <form onSubmit={handleSubmit} className="flex-1 flex flex-col justify-between min-h-[350px]">
                
                {/* Step 1: Base Occasion Category Selection */}
                {step === 1 && (
                  <div className="space-y-6 animate-fadeIn">
                    <div>
                      <h4 className="font-serif text-xl text-[#3d3430] font-medium">1. Choose Your Cake Occasion</h4>
                      <p className="text-xs text-[#8c7366] font-light mt-1">This sets our base scale structure, and default starting estimates.</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      {CATEGORIES.map((catOption) => (
                        <div
                          key={catOption.id}
                          onClick={() => {
                            setCategory(catOption.id);
                          }}
                          className={`p-4 rounded-2xl border transition-all duration-300 cursor-pointer text-left flex flex-col justify-between ${
                            category === catOption.id
                              ? 'border-rosegold-500 bg-rosegold-50/40 ring-1 ring-rosegold-400'
                              : 'border-rosegold-100 hover:border-rosegold-300 hover:bg-neutral-50/50'
                          }`}
                        >
                          <div>
                            <span className="text-xl">
                              {catOption.id === 'wedding' ? '💍' : catOption.id === 'birthday' ? '🎂' : catOption.id === 'anniversary' ? '🕊️' : '✨'}
                            </span>
                            <h5 className="font-serif text-sm text-[#3d3430] mt-2 capitalize font-semibold">{catOption.id} Cake</h5>
                            <p className="text-[10.5px] text-[#8c7366] leading-relaxed mt-1 line-clamp-2">{catOption.description}</p>
                          </div>
                          <p className="text-[10px] font-semibold text-rosegold-600 mt-3 border-t border-rosegold-100/50 pt-2">
                            Starts from ${catOption.startingPrice}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}


                {/* Step 2: Sponge Cake Interior Flavor */}
                {step === 2 && (
                  <div className="space-y-6">
                    <div>
                      <h4 className="font-serif text-xl text-[#3d3430] font-medium">2. Choose Your Cake Flavor</h4>
                      <p className="text-xs text-[#8c7366] font-light mt-1">Every batter uses clean organic flour and fresh compound extracts.</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                      {FLAVOR_OPTIONS.map((flOpt) => (
                        <div
                          key={flOpt.id}
                          onClick={() => setSelectedFlavor(flOpt)}
                          className={`p-3.5 rounded-2xl border transition-all duration-300 cursor-pointer text-left flex items-start gap-3.5 ${
                            selectedFlavor.id === flOpt.id
                              ? 'border-rosegold-500 bg-[#fff5f7] ring-1 ring-rosegold-400'
                              : 'border-rosegold-100 hover:border-rosegold-300 hover:bg-neutral-50/50'
                          }`}
                        >
                          <div className="w-8 h-8 rounded-full bg-white border border-rosegold-100 flex items-center justify-center text-sm shadow-2xs shrink-0 select-none">
                            🍰
                          </div>
                          <div className="space-y-0.5">
                            <h5 className="text-[13px] font-semibold text-[#3d3430] flex items-center justify-between">
                              {flOpt.name}
                              {flOpt.additionalPrice > 0 && (
                                <span className="text-[9.5px] text-[#be2146] font-bold bg-[#ffeef2] px-1.5 py-0.5 rounded-md ml-1">
                                  +${flOpt.additionalPrice}
                                </span>
                              )}
                            </h5>
                            <p className="text-[10.5px] text-[#8c7366] leading-relaxed font-light">{flOpt.description}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}


                {/* Step 3: Satin Outer Frosting Selection */}
                {step === 3 && (
                  <div className="space-y-6">
                    <div>
                      <h4 className="font-serif text-xl text-[#3d3430] font-medium">3. Choose Outer Frosting Coat</h4>
                      <p className="text-xs text-[#8c7366] font-light mt-1">Choose your canvas texture. We hand pipe and level to pristine finishes.</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                      {FROSTING_OPTIONS.map((frOpt) => (
                        <div
                          key={frOpt.id}
                          onClick={() => setSelectedFrosting(frOpt)}
                          className={`p-3.5 rounded-2xl border transition-all duration-300 cursor-pointer text-left flex items-start gap-3.5 ${
                            selectedFrosting.id === frOpt.id
                              ? 'border-rosegold-500 bg-[#fff5f7] ring-1 ring-rosegold-400'
                              : 'border-rosegold-100 hover:border-rosegold-300 hover:bg-neutral-50/50'
                          }`}
                        >
                          <div className="w-8 h-8 rounded-full bg-white border border-rosegold-100 flex items-center justify-center text-sm shadow-2xs shrink-0 select-none">
                            🎨
                          </div>
                          <div className="space-y-0.5">
                            <h5 className="text-[13px] font-semibold text-[#3d3430] flex items-center justify-between">
                              {frOpt.name}
                              {frOpt.additionalPrice > 0 && (
                                <span className="text-[9.5px] text-[#be2146] font-bold bg-[#ffeef2] px-1.5 py-0.5 rounded-md ml-1">
                                  +${frOpt.additionalPrice}
                                </span>
                              )}
                            </h5>
                            <p className="text-[10.5px] text-[#8c7366] leading-relaxed font-light">{frOpt.description}</p>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Foil options */}
                    <div className="pt-4 border-t border-rosegold-100">
                      <label className="text-xs uppercase font-semibold text-[#a38c81] tracking-wider block mb-2">Metallic Micro-Foil Accents (+$30):</label>
                      <div className="flex flex-wrap gap-2.5">
                        {['none', 'rose-gold', 'gold', 'silver'].map((fKey) => (
                          <button
                            key={fKey}
                            type="button"
                            onClick={() => setMetallicFinish(fKey as any)}
                            className={`px-4.5 py-2.5 rounded-xl text-[11px] capitalize cursor-pointer font-medium border transition-all ${
                              metallicFinish === fKey
                                ? 'bg-rosegold-500 text-white border-rosegold-600 shadow-md'
                                : 'bg-white hover:bg-neutral-50 text-[#5d4d42] border-rosegold-100'
                            }`}
                          >
                            {fKey} Leafing
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}


                {/* Step 4: Scales and Dimension config */}
                {step === 4 && (
                  <div className="space-y-6">
                    <div>
                      <h4 className="font-serif text-xl text-[#3d3430] font-medium">4. Configure Tiers & Servings</h4>
                      <p className="text-xs text-[#8c7366] font-light mt-1">Scale your proportions accurately. Servings are estimated for standard slices.</p>
                    </div>

                    {/* Interactive Tiers Stack Toggle Buttons */}
                    <div className="space-y-2">
                      <label className="text-xs uppercase font-semibold text-[#a38c81] tracking-wider block">Stack Tiers Count:</label>
                      <div className="grid grid-cols-4 gap-3">
                        {[1, 2, 3, 4].map((tierNum) => (
                          <button
                            key={tierNum}
                            type="button"
                            onClick={() => setTiers(tierNum)}
                            className={`py-3 rounded-2xl border font-bold text-sm tracking-widest cursor-pointer transition-all ${
                              tiers === tierNum
                                ? 'bg-[#ffccd8] text-[#be2146] border-[#ffa3b7] shadow-sm'
                                : 'bg-white hover:bg-neutral-50 text-[#5d4d42] border-rosegold-100'
                            }`}
                          >
                            {tierNum} Tier{tierNum > 1 ? 's' : ''}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Guests Servings Slider */}
                    <div className="space-y-3 pt-4 border-t border-rosegold-100/60">
                      <div className="flex justify-between text-xs font-semibold text-[#5d4d42]">
                        <span className="uppercase text-[#a38c81] tracking-wider">Target Guests Servings:</span>
                        <span className="text-rosegold-600">{servings} guests</span>
                      </div>
                      <input
                        type="range"
                        min={tiers === 1 ? 10 : tiers === 2 ? 25 : tiers === 3 ? 60 : 100}
                        max={tiers === 1 ? 25 : tiers === 2 ? 60 : tiers === 3 ? 120 : 250}
                        step={5}
                        value={servings}
                        onChange={(e) => setServings(parseInt(e.target.value))}
                        className="w-full h-1.5 bg-rosegold-100 rounded-lg appearance-none cursor-pointer accent-rosegold-500"
                      />
                      <div className="flex justify-between text-[10px] text-[#a38c81]">
                        <span>Min needed: {tiers === 1 ? 10 : tiers === 2 ? 25 : tiers === 3 ? 60 : 100} guests</span>
                        <span>Max bounds: {tiers === 1 ? 25 : tiers === 2 ? 60 : tiers === 3 ? 120 : 250} guests</span>
                      </div>
                    </div>
                  </div>
                )}


                {/* Step 5: Master Artisan Accessories */}
                {step === 5 && (
                  <div className="space-y-6">
                    <div>
                      <h4 className="font-serif text-xl text-[#3d3430] font-medium">5. Select Visual Garnishes</h4>
                      <p className="text-xs text-[#8c7366] font-light mt-1">Our pastry chefs will hand apply these custom luxury elements on your cake.</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {ACCENT_OPTIONS.map((acc) => (
                        <div
                          key={acc.id}
                          onClick={() => handleAccentToggle(acc.name)}
                          className={`p-3 rounded-2xl border transition-all duration-300 cursor-pointer text-left flex items-center justify-between ${
                            selectedAccents.includes(acc.name)
                              ? 'border-rosegold-500 bg-[#fff5f7] ring-1 ring-rosegold-400'
                              : 'border-rosegold-100 hover:border-rosegold-300 hover:bg-neutral-50/50'
                          }`}
                        >
                          <div className="flex items-center gap-2.5 max-w-[80%]">
                            <span className="text-lg bg-white w-7 h-7 rounded-sm flex items-center justify-center shadow-3xs">{acc.icon}</span>
                            <span className="text-[12px] font-medium text-[#3d3430]">{acc.name}</span>
                          </div>
                          <span className="text-[10px] font-bold text-rosegold-600 shrink-0 bg-white border border-rosegold-100 px-1.5 py-0.5 rounded-md">
                            +${acc.price}
                          </span>
                        </div>
                      ))}
                    </div>

                    {/* Submissions Section Integration */}
                    <div className="pt-4 border-t border-rosegold-100">
                      <label className="text-xs uppercase font-semibold text-[#a38c81] tracking-wider block mb-2">Configure Secure Delivery Curation:</label>
                      <div className="grid grid-cols-2 gap-4">
                        <div
                          onClick={() => setDeliveryMethod('pickup')}
                          className={`p-3 rounded-xl border transition-all duration-300 cursor-pointer flex items-center gap-2 ${
                            deliveryMethod === 'pickup'
                              ? 'border-rosegold-500 bg-rosegold-50/20'
                              : 'border-rosegold-100/60 hover:border-rosegold-200'
                          }`}
                        >
                          <ShoppingBag className="w-4 h-4 text-rosegold-400 shrink-0" />
                          <div>
                            <p className="text-[11px] font-bold text-[#3d3430]">Boutique Pickup</p>
                            <p className="text-[9px] text-[#8c7366]">Complimentary</p>
                          </div>
                        </div>

                        <div
                          onClick={() => setDeliveryMethod('delivery')}
                          className={`p-3 rounded-xl border transition-all duration-300 cursor-pointer flex items-center gap-2 ${
                            deliveryMethod === 'delivery'
                              ? 'border-rosegold-500 bg-rosegold-50/20'
                              : 'border-rosegold-100/60 hover:border-rosegold-200'
                          }`}
                        >
                          <Truck className="w-4 h-4 text-rosegold-400 shrink-0" />
                          <div>
                            <p className="text-[11px] font-bold text-[#3d3430]">White Glove Delivery</p>
                            <p className="text-[9px] text-[#8c7366]">+$45 (Temperature Safe)</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}


                {/* Delivery and final contact panel */}
                {step === 5 && (
                  <div className="mt-8 pt-6 border-t border-rosegold-100/80 space-y-4">
                    <h5 className="text-xs uppercase font-bold tracking-widest text-[#a38c81]">Delivery Curation & Client Profile</h5>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="relative">
                        <User className="w-4 h-4 text-rosegold-400 absolute left-3 top-3" />
                        <input
                          type="text"
                          required
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                          placeholder="Your Full Name"
                          className="w-full bg-rosegold-50/50 pl-9 pr-4 py-2.5 rounded-xl text-xs border border-rosegold-100 focus:outline-none focus:border-rosegold-400"
                        />
                      </div>
                      <div className="relative">
                        <Calendar className="w-4 h-4 text-rosegold-400 absolute left-3 top-3" />
                        <input
                          type="date"
                          required
                          value={deliveryDate}
                          onChange={(e) => setDeliveryDate(e.target.value)}
                          className="w-full bg-rosegold-50/50 pl-9 pr-4 py-2.5 rounded-xl text-xs border border-rosegold-100 focus:outline-none focus:border-rosegold-400"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="relative">
                        <Mail className="w-4 h-4 text-rosegold-400 absolute left-3 top-3" />
                        <input
                          type="email"
                          required
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="Email Address"
                          className="w-full bg-rosegold-50/50 pl-9 pr-4 py-2.5 rounded-xl text-xs border border-rosegold-100 focus:outline-none focus:border-rosegold-400"
                        />
                      </div>
                      <div className="relative">
                        <Phone className="w-4 h-4 text-rosegold-400 absolute left-3 top-3" />
                        <input
                          type="tel"
                          required
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="Phone Number"
                          className="w-full bg-rosegold-50/50 pl-9 pr-4 py-2.5 rounded-xl text-xs border border-rosegold-100 focus:outline-none focus:border-rosegold-400"
                        />
                      </div>
                    </div>

                    <div>
                      <textarea
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        placeholder="Special requests or instructions (e.g. ribbon color, allergies, flowers)..."
                        className="w-full bg-rosegold-50/50 px-4 py-2.5 rounded-xl text-xs border border-rosegold-100 focus:outline-none focus:border-rosegold-400 h-16 resize-none"
                      />
                    </div>
                  </div>
                )}


                {/* Master Action Navigation Controls */}
                <div className="mt-8 flex items-center justify-between gap-4 pt-4 border-t border-rosegold-100/60">
                  <button
                    type="button"
                    disabled={step === 1}
                    onClick={() => setStep(prev => prev - 1)}
                    className={`px-5 py-3 rounded-xl text-xs font-semibold uppercase tracking-wider flex items-center gap-1 cursor-pointer select-none transition-colors border ${
                      step === 1
                        ? 'opacity-30 border-neutral-200 text-neutral-400 pointer-events-none'
                        : 'bg-white hover:bg-rosegold-50 text-[#5d4d42] border-rosegold-100'
                    }`}
                  >
                    <ChevronLeft className="w-4 h-4" /> Back
                  </button>

                  {step < 5 ? (
                    <button
                      type="button"
                      onClick={() => setStep(prev => prev + 1)}
                      className="px-6 py-3 btn-luxury rounded-xl text-xs font-semibold uppercase tracking-widest flex items-center gap-1 select-none cursor-pointer"
                    >
                      Continue <ChevronRight className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      type="submit"
                      disabled={!fullName || !email || !phone || !deliveryDate}
                      className={`px-8 py-3 bg-[#e33660] hover:bg-[#c95151] font-semibold uppercase tracking-widest text-[#fff5f7] rounded-xl text-xs transition-colors flex items-center gap-1 cursor-pointer select-none duration-300 ${(!fullName || !email || !phone || !deliveryDate) ? 'opacity-40 cursor-not-allowed' : 'btn-luxury shadow-lg'}`}
                    >
                      Bake and Request Quote <Sparkles className="w-4 h-4" />
                    </button>
                  )}
                </div>

              </form>
            ) : (
              /* Success confirmation Screen */
              <div className="flex-1 flex flex-col items-center justify-center text-center p-6 space-y-5 animate-scaleUp">
                <div className="w-[110px] h-[110px] rounded-full bg-[#fcf5f7] border border-[#f5b8c9] flex items-center justify-center relative shadow-inner">
                  <Check className="w-12 h-12 text-[#ff406c] absolute animate-bounce" />
                  <Heart className="w-4 h-4 text-rosegold-500 absolute -bottom-1 -right-1 fill-rosegold-100 animate-pulse" />
                </div>

                <div className="space-y-2">
                  <h4 className="font-serif text-2xl text-[#3d3430] font-medium">Masterpiece Recipe Registered!</h4>
                  <p className="text-xs text-[#8c7366] max-w-sm mx-auto font-light leading-relaxed">
                    Thank you {fullName}! Your customized <span className="font-semibold text-rosegold-600 capitalize">{category} Edition</span> recipe is registered and saved inside our boutique local records.
                  </p>
                </div>

                {submittedInquiry && (
                  <div className="p-4 rounded-2xl bg-rosegold-50/50 border border-rosegold-100/60 max-w-md w-full text-left space-y-3.5 text-xs text-[#5d4d42]">
                    <div className="flex justify-between items-center border-b border-rosegold-100/50 pb-2">
                      <span className="text-[10px] uppercase font-bold text-[#a38c81]">Visual Design Invoice:</span>
                      <strong className="text-rosegold-500 font-bold">{submittedInquiry.id}</strong>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px] font-light">
                      <div><strong className="text-[#3d3430]">Occasion:</strong> <span className="capitalize">{submittedInquiry.category}</span></div>
                      <div><strong className="text-[#3d3430]">Layers:</strong> {submittedInquiry.tiers} Tier Cake</div>
                      <div><strong className="text-[#3d3430]">Base:</strong> {submittedInquiry.flavor}</div>
                      <div><strong className="text-[#3d3430]">Finishing Coat:</strong> {submittedInquiry.frosting}</div>
                      <div><strong className="text-[#3d3430]">Occasion Date:</strong> {submittedInquiry.deliveryDate}</div>
                      <div><strong className="text-[#3d3430]">Foil coating:</strong> {submittedInquiry.metallicFinish === 'none' ? 'None' : submittedInquiry.metallicFinish}</div>
                    </div>

                    {submittedInquiry.accents.length > 0 && (
                      <div className="border-t border-rosegold-100/40 pt-2 text-[11px]">
                        <strong className="text-[#3d3430] block mb-1">Garnishes:</strong>
                        <div className="flex flex-wrap gap-1">
                          {submittedInquiry.accents.map((accent, index) => (
                            <span key={index} className="bg-white px-2 py-0.5 rounded-full border border-rosegold-100/60 text-[10px]">
                              {accent}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="flex justify-between items-center border-t border-rosegold-100 pb-1 pt-2">
                      <span className="font-semibold text-neutral-500">Approximate Budget:</span>
                      <strong className="text-base text-rosegold-600 font-bold">${submittedInquiry.estimatedPrice}</strong>
                    </div>
                  </div>
                )}

                <div className="pt-2">
                  <button
                    onClick={handleReset}
                    className="btn-luxury px-6.5 py-3 rounded-full text-xs font-semibold uppercase tracking-wider cursor-pointer"
                  >
                    Bake Another Design
                  </button>
                </div>
              </div>
            )}

          </div>

        </div>

      </div>
    </section>
  );
}
