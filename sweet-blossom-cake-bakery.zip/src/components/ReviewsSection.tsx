import { useState, useEffect } from 'react';
import { REVIEWS } from '../data';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';

export default function ReviewsSection() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const prevReview = () => {
    setCurrentIndex((prev) => (prev > 0 ? prev - 1 : REVIEWS.length - 1));
  };

  const nextReview = () => {
    setCurrentIndex((prev) => (prev < REVIEWS.length - 1 ? prev + 1 : 0));
  };

  // Autoplay carousel every 8 seconds for a lively fluid feel
  useEffect(() => {
    const timer = setInterval(nextReview, 8 * 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section id="reviews" className="py-24 px-6 bg-[#fbf8f5] relative overflow-hidden">
      
      {/* Delicate background blur accent glows */}
      <div className="absolute top-[20%] left-[-15%] w-[400px] h-[400px] rounded-full bg-rosegold-100/30 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[20%] right-[-15%] w-[450px] h-[450px] rounded-full bg-blossom-50/40 blur-[130px] pointer-events-none" />

      <div className="max-w-4xl mx-auto relative z-10 text-center">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <span className="text-[11px] uppercase tracking-[0.25em] font-bold text-rosegold-500 bg-white px-4 py-1.5 rounded-full inline-block border border-rosegold-200 shadow-xs">
            Client Testimonials
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-gray-900 font-bold tracking-tight">
            Loved By Sweet <span className="italic font-normal text-rosegold-500 font-serif">Connoisseurs</span>
          </h2>
          <div className="w-[80px] h-[1px] bg-rosegold-300 mx-auto" />
        </div>

        {/* Carousel Testimonial Card */}
        <div className="relative min-h-[320px] flex items-center justify-center">
          
          {/* Main Card Container with Glassmorphic Elements */}
          <div className="w-full glass-panel border border-white/85 p-8 sm:p-12 rounded-[32px] shadow-xl relative transition-all duration-500">
            
            {/* Elegant visual quote icon */}
            <div className="absolute top-6 left-6 opacity-8 select-none">
              <Quote className="w-16 h-16 text-rosegold-400" />
            </div>

            {/* Testimonial Core */}
            <div className="space-y-6 relative z-10">
              
              {/* Star Evaluation */}
              <div className="flex items-center justify-center gap-1">
                {Array.from({ length: REVIEWS[currentIndex].rating }).map((_, idx) => (
                  <Star key={idx} className="w-5 h-5 fill-amber-300 stroke-amber-400" />
                ))}
              </div>

              {/* Review Text */}
              <p className="font-medium italic text-sm sm:text-base lg:text-lg text-gray-700 leading-relaxed max-w-2xl mx-auto">
                "{REVIEWS[currentIndex].text}"
              </p>

              {/* Divider */}
              <div className="w-12 h-[1px] bg-rosegold-200/60 mx-auto" />

              {/* Author Avatar Detail */}
              <div className="flex flex-col items-center space-y-3.5">
                <img
                  src={REVIEWS[currentIndex].avatar}
                  alt={REVIEWS[currentIndex].name}
                  className="w-16 h-16 rounded-full object-cover border-2 border-white shadow-md"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <h4 className="font-serif text-base text-gray-900 font-bold">
                    {REVIEWS[currentIndex].name}
                  </h4>
                  <p className="text-[10px] uppercase font-bold text-rosegold-500 tracking-wider mt-0.5">
                    {REVIEWS[currentIndex].role} — {REVIEWS[currentIndex].cakeStyle}
                  </p>
                </div>
              </div>

            </div>

          </div>

          {/* Left/Right floating slider navigations */}
          <button
            onClick={prevReview}
            className="absolute -left-4 sm:-left-6 top-1/2 -translate-y-1/2 p-3 rounded-full bg-white hover:bg-rosegold-50 hover:scale-105 border border-rosegold-100 shadow-md text-rosegold-500 transition-all select-none cursor-pointer"
            title="Previous Testimonial"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          
          <button
            onClick={nextReview}
            className="absolute -right-4 sm:-right-6 top-1/2 -translate-y-1/2 p-3 rounded-full bg-white hover:bg-rosegold-50 hover:scale-105 border border-rosegold-100 shadow-md text-rosegold-500 transition-all select-none cursor-pointer"
            title="Next Testimonial"
          >
            <ChevronRight className="w-5 h-5" />
          </button>

        </div>

        {/* Carousel Slide Indicators dots */}
        <div className="flex items-center justify-center gap-2 mt-8">
          {REVIEWS.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                currentIndex === idx
                  ? 'bg-rosegold-500 w-6 shadow-xs'
                  : 'bg-rosegold-200/70 hover:bg-rosegold-300'
              }`}
            />
          ))}
        </div>

      </div>
    </section>
  );
}
