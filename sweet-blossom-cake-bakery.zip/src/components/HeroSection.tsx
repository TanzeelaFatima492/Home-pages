import { motion } from 'motion/react';
import { Sparkles, ArrowRight, Play, Heart } from 'lucide-react';

interface HeroSectionProps {
  onLearnMoreClick: () => void;
  onDesignClick: () => void;
}

export default function HeroSection({ onLearnMoreClick, onDesignClick }: HeroSectionProps) {
  // Array to generate falling petals
  const petals = Array.from({ length: 15 });

  return (
    <section
      id="home"
      className="relative min-h-screen pt-28 pb-16 px-6 overflow-hidden flex items-center bg-gradient-to-b from-[#fffafb] via-[#fff5f7] to-[#fbf8f5]"
    >
      {/* Decorative Floating Petals / Flakes */}
      <div className="absolute inset-0 pointer-events-none select-none z-10 overflow-hidden">
        {petals.map((_, idx) => {
          const delay = (idx * 0.7).toFixed(1);
          const duration = (8 + idx * 1.2).toFixed(1);
          const left = (5 + idx * 6.5).toFixed(1);
          const scale = (0.4 + (idx % 3) * 0.25).toFixed(2);
          return (
            <div
              key={idx}
              className="absolute text-pink-200/40 animate-petal-fall"
              style={{
                left: `${left}%`,
                animationDelay: `${delay}s`,
                animationDuration: `${duration}s`,
                transform: `scale(${scale})`,
              }}
            >
              {idx % 3 === 0 ? (
                // Rose gold leaf / circle sparkle
                <div className="w-3 h-3 rounded-full bg-linear-to-tr from-[#dfbc99] to-[#cca592] shadow-xs opacity-60" />
              ) : idx % 3 === 1 ? (
                // Sakura blossom shape representer
                <span className="text-xl">🌸</span>
              ) : (
                // Sparkling gold star
                <Sparkles className="w-4 h-4 text-rosegold-300 opacity-60" />
              )}
            </div>
          );
        })}
      </div>

      {/* Elegant Radial Soft Rose-Gold Glows */}
      <div className="absolute top-[20%] left-[-10%] w-[500px] h-[500px] rounded-full bg-blossom-100/40 blur-[130px] pointer-events-none" />
      <div className="absolute bottom-[10%] right-[-10%] w-[600px] h-[600px] rounded-full bg-rosegold-100/50 blur-[150px] pointer-events-none" />

      <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-20">
        
        {/* Left Written Brand Intro */}
        <motion.div
          className="lg:col-span-6 flex flex-col space-y-8 text-center lg:text-left"
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.9, ease: 'easeOut' }}
        >
          {/* Tagline Badge */}
          <div className="flex items-center justify-center lg:justify-start">
            <span className="inline-flex items-center gap-2 bg-white/70 backdrop-blur-md px-4.5 py-1.5 rounded-full border border-rosegold-100 shadow-xs text-xs tracking-[0.2em] uppercase font-semibold text-rosegold-500">
              <Sparkles className="w-3.5 h-3.5 text-rosegold-400" />
              Brand of Exquisite Taste
            </span>
          </div>

          <div className="space-y-4 text-center lg:text-left">
            <p className="text-rosegold-500 font-serif italic text-lg sm:text-xl md:text-2xl tracking-wide">
              Crafting Happiness...
            </p>
            <h1 className="font-serif text-5xl sm:text-6xl lg:text-7xl xl:text-8xl leading-[0.9] text-gray-900 font-bold tracking-tighter">
              One Slice <br />
              at a <span className="italic font-normal text-rosegold-500">Time</span>
            </h1>
            <p className="text-sm sm:text-base text-gray-600 max-w-xl mx-auto lg:mx-0 leading-relaxed font-medium mt-4">
              Sweet Blossom creates high-fashion custom sugar sculptures and premium boutique cakes. 
              Each creation binds Parisian luxury baking with stunning organic blossom aesthetics.
            </p>
          </div>

          {/* Luxury CTA Actions */}
          <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
            <button
              onClick={onDesignClick}
              className="w-full sm:w-auto btn-luxury px-8 py-4 rounded-full font-semibold uppercase tracking-widest text-xs flex items-center justify-center gap-2.5 transition-all select-none cursor-pointer"
            >
              <Sparkles className="w-4 h-4 animate-pulse" />
              Design Studio
            </button>
            <button
              onClick={onLearnMoreClick}
              className="w-full sm:w-auto bg-white hover:bg-rosegold-50 text-[#3d3430] border border-rosegold-200 hover:border-rosegold-300 transition-all font-semibold uppercase tracking-widest text-xs px-8 py-4 rounded-full flex items-center justify-center gap-2 group cursor-pointer"
            >
              Learn More
              <ArrowRight className="w-4 h-4 text-[#bd8e77] transition-transform group-hover:translate-x-1" />
            </button>
          </div>

          {/* Social Social-proof stats */}
          <div className="pt-6 grid grid-cols-3 gap-6 border-t border-rosegold-100/80 max-w-md mx-auto lg:mx-0">
            <div>
              <p className="font-serif text-2xl md:text-3xl text-rosegold-500 font-semibold">100%</p>
              <p className="text-[10px] uppercase tracking-wider text-[#a38c81] mt-1">Organic Sourced</p>
            </div>
            <div>
              <p className="font-serif text-2xl md:text-3xl text-rosegold-500 font-semibold">5.0 ★</p>
              <p className="text-[10px] uppercase tracking-wider text-[#a38c81] mt-1">Over 800 Reviews</p>
            </div>
            <div>
              <p className="font-serif text-2xl md:text-3xl text-rosegold-500 font-semibold">15+</p>
              <p className="text-[10px] uppercase tracking-wider text-[#a38c81] mt-1">Years Artisan Skill</p>
            </div>
          </div>

        </motion.div>

        {/* Right Cake Image Gallery Panel */}
        <motion.div
          className="lg:col-span-6 flex justify-center lg:justify-end relative"
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.9, delay: 0.2, ease: 'easeOut' }}
        >
          {/* Main Cake Image frame block */}
          <div className="relative w-full max-w-[480px] group">
            
            {/* Soft backdrop floating circle rings */}
            <div className="absolute inset-0 rounded-full border border-rosegold-200/50 scale-105 pointer-events-none animate-float-delayed" />
            
            {/* Elegant luxury framing with glass overlay */}
            <div className="overflow-hidden rounded-t-[200px] rounded-b-[40px] border-4 border border-white bg-linear-to-b from-white to-rosegold-50 p-3 shadow-2xl relative transition-all duration-700 hover:shadow-[0_25px_60px_-15px_rgba(177,120,93,0.35)]">
              <img
                src="/src/assets/images/hero_cake_1780230717096.png"
                alt="Sweet Blossom Luxury Masterpiece Wedding Cake"
                className="w-full object-cover rounded-t-[190px] rounded-b-[30px] aspect-[4/5] object-center transition-transform duration-700 hover:scale-103"
                referrerPolicy="no-referrer"
              />
              
              {/* Floating review card in absolute */}
              <div className="absolute bottom-6 left-6 right-6 p-4 rounded-xl glass-panel shadow-lg flex items-center gap-3 border border-white/60">
                <div className="relative">
                  <img
                    src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&auto=format&fit=crop&q=80"
                    alt="Reviewer"
                    className="w-10 h-10 rounded-full object-cover border border-rosegold-200"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute -bottom-1 -right-1 w-4.5 h-4.5 rounded-full bg-rosegold-400 flex items-center justify-center">
                    <Heart className="w-2.5 h-2.5 text-white fill-white" />
                  </div>
                </div>
                <div>
                  <div className="flex text-amber-400 text-xs">★★★★★</div>
                  <p className="text-[10.5px] italic text-[#5d4d42] mt-0.5 line-clamp-2">"The sugar flowers were so life-like, nobody wanted to slice it!"</p>
                  <p className="text-[9px] uppercase tracking-wider text-[#bd8e77] mt-1 font-semibold">- Clara Edwards, Bride</p>
                </div>
              </div>
            </div>

            {/* Glowing gold rose particle decoration bottom-right */}
            <div className="absolute -bottom-6 -right-6 w-16 h-16 rounded-full bg-rosegold-100/90 border border-rosegold-200/80 flex items-center justify-center shadow-lg animate-float text-xl select-none">
              🧁
            </div>

            {/* Top-left decoration */}
            <div className="absolute -top-3 -left-3 w-12 h-12 rounded-full bg-white border border-rosegold-100 flex items-center justify-center shadow-md animate-float-delayed text-lg select-none">
              🌸
            </div>

          </div>
        </motion.div>

      </div>
    </section>
  );
}
