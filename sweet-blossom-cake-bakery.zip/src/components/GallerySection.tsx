import { useState } from 'react';
import { GALLERY } from '../data';
import { GalleryItem, CakeCategory } from '../types';
import { Sparkles, Maximize2, X, ChevronLeft, ChevronRight, Cake, Heart, Calendar } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function GallerySection() {
  const [selectedCategory, setSelectedCategory] = useState<CakeCategory | 'all'>('all');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  // Filter gallery items based on selection
  const filteredItems = selectedCategory === 'all'
    ? GALLERY
    : GALLERY.filter(item => item.category === selectedCategory);

  // Filter navigation in Lightbox view
  const openLightbox = (id: string) => {
    const idx = filteredItems.findIndex(item => item.id === id);
    if (idx !== -1) {
      setLightboxIndex(idx);
    }
  };

  const closeLightbox = () => {
    setLightboxIndex(null);
  };

  const handlePrev = () => {
    if (lightboxIndex !== null) {
      setLightboxIndex(prev => (prev !== null && prev > 0 ? prev - 1 : filteredItems.length - 1));
    }
  };

  const handleNext = () => {
    if (lightboxIndex !== null) {
      setLightboxIndex(prev => (prev !== null && prev < filteredItems.length - 1 ? prev + 1 : 0));
    }
  };

  const categories: { label: string; value: CakeCategory | 'all' }[] = [
    { label: 'All Masterpieces', value: 'all' },
    { label: 'Wedding Creations', value: 'wedding' },
    { label: 'Milestone Birthdays', value: 'birthday' },
    { label: 'Anniversary Classics', value: 'anniversary' },
    { label: 'Bespoke Art', value: 'custom' },
  ];

  return (
    <section id="gallery" className="py-24 px-6 bg-white relative">
      
      {/* Decorative Blur Element */}
      <div className="absolute top-[30%] left-[-15%] w-[400px] h-[400px] rounded-full bg-blossom-50/50 blur-[130px] pointer-events-none" />
      <div className="absolute bottom-[10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-rosegold-50/40 blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Gallery Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <span className="text-[11px] uppercase tracking-[0.25em] font-bold text-rosegold-500 bg-rosegold-100/60 px-4 py-1.5 rounded-full inline-block border border-rosegold-200">
            Our Sugar Canvas
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-gray-900 font-bold tracking-tight">
            The Enchanted <span className="italic font-normal text-rosegold-500 font-serif">Gallery</span>
          </h2>
          <div className="w-[80px] h-[1px] bg-rosegold-300 mx-auto" />
          <p className="text-sm text-gray-600 max-w-lg mx-auto leading-relaxed font-medium">
            Browse through some of our most celebrated creations. Each cake highlights a bespoke story of luxury textures and floral balance.
          </p>
        </div>

        {/* Filter Navigation Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2 md:gap-3 mb-12">
          {categories.map((tab) => (
            <button
              key={tab.value}
              onClick={() => setSelectedCategory(tab.value)}
              className={`px-5 py-2.5 rounded-full text-xs uppercase tracking-widest font-semibold transition-all duration-300 pointer-events-auto cursor-pointer ${
                selectedCategory === tab.value
                  ? 'btn-luxury shadow-md scale-103'
                  : 'bg-rosegold-50/50 hover:bg-rosegold-100/80 text-[#5d4d42] border border-rosegold-200/30'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Masonry-inspired Grid Layout */}
        <div className="columns-1 sm:columns-2 lg:columns-3 gap-6 space-y-6">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              onClick={() => openLightbox(item.id)}
              className="masonry-grid-item group relative rounded-[24px] overflow-hidden bg-rosegold-100 shadow-md hover:shadow-2xl transition-all duration-500 cursor-pointer border-2 border-white"
            >
              {/* Image with zoom effect */}
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-auto object-cover transition-transform duration-700 group-hover:scale-104"
                referrerPolicy="no-referrer"
              />

              {/* Sophisticated glassmorphic hover overlay */}
              <div className="absolute inset-0 bg-linear-to-t from-black/60 via-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-400 p-6 flex flex-col justify-end">
                
                {/* Visual Accent Button Top Right */}
                <div className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/35 backdrop-blur-md border border-white/40 flex items-center justify-center text-white scale-90 group-hover:scale-100 transition-all duration-300">
                  <Maximize2 className="w-4 h-4" />
                </div>

                <div className="space-y-1 transform translate-y-3 group-hover:translate-y-0 transition-transform duration-500">
                  <span className="text-[10px] uppercase font-bold tracking-widest text-[#ffeef2] bg-blossom-500/80 px-2.5 py-0.5 rounded-md inline-block">
                    {item.tag}
                  </span>
                  <h4 className="font-serif text-lg text-white mt-1">
                    {item.title}
                  </h4>
                  {item.size && (
                    <p className="text-[11px] text-[#f2e9e4]">
                      {item.size}
                    </p>
                  )}
                </div>

              </div>

            </div>
          ))}
        </div>

      </div>

      {/* Lightbox Modal Carousel with AnimatePresence */}
      <AnimatePresence>
        {lightboxIndex !== null && (
          <div className="fixed inset-0 z-55 flex items-center justify-center p-4">
            {/* Dark background backing */}
            <motion.div
              className="absolute inset-0 bg-black/85 backdrop-blur-sm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={closeLightbox}
            />

            {/* Lightbox Content Container */}
            <motion.div
              className="relative w-full max-w-4xl bg-white rounded-[32px] overflow-hidden shadow-2xl z-20 flex flex-col md:flex-row border border-rosegold-100"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            >
              
              {/* Left Side: Stunning zoomable Image */}
              <div className="w-full md:w-3/5 bg-neutral-900 flex items-center justify-center relative aspect-[4/3] md:aspect-auto md:h-[500px]">
                <img
                  src={filteredItems[lightboxIndex].image}
                  alt={filteredItems[lightboxIndex].title}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />

                {/* Left/Right controls inside image frame on mobile/desktop */}
                <button
                  onClick={handlePrev}
                  className="absolute left-4 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-white/25 hover:bg-white/40 backdrop-blur-md text-white border border-white/20 hover:scale-105 transition-all text-center"
                >
                  <ChevronLeft className="w-5.5 h-5.5" />
                </button>
                <button
                  onClick={handleNext}
                  className="absolute right-4 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-white/25 hover:bg-white/40 backdrop-blur-md text-white border border-white/20 hover:scale-105 transition-all text-center"
                >
                  <ChevronRight className="w-5.5 h-5.5" />
                </button>
              </div>

              {/* Right Side: Detailed Cake Story Panel */}
              <div className="w-full md:w-2/5 p-8 flex flex-col justify-between bg-rosegold-50/20 relative">
                
                {/* Close Button top-right */}
                <button
                  onClick={closeLightbox}
                  className="absolute top-4 right-4 p-2 rounded-full hover:bg-rosegold-100/60 text-[#5d4d42] transition-colors"
                >
                  <X className="w-5.5 h-5.5" />
                </button>

                {/* Cake Story Content */}
                <div className="space-y-6 pt-2">
                  <div className="space-y-2">
                    <span className="inline-block text-[10px] uppercase font-bold tracking-widest text-rosegold-500 bg-[#FFF5F7] px-3 py-1 rounded-md border border-rosegold-200">
                      {filteredItems[lightboxIndex].tag}
                    </span>
                    <h3 className="font-serif text-2xl lg:text-3xl text-gray-900 font-bold leading-tight">
                      {filteredItems[lightboxIndex].title}
                    </h3>
                  </div>

                  <div className="w-12 h-[1px] bg-rosegold-300" />

                  <p className="text-xs sm:text-sm text-gray-600 font-medium leading-relaxed">
                    {filteredItems[lightboxIndex].description}
                  </p>

                  <div className="grid grid-cols-2 gap-4 pt-4 border-t border-rosegold-100 text-xs">
                    <div>
                      <span className="text-[10px] uppercase font-semibold text-[#a38c81] tracking-wider block mb-1">Scale / Dimensions:</span>
                      <p className="font-medium text-[#3d3430] flex items-center gap-1.5"><Cake className="w-4 h-4 text-[#cca592]" /> {filteredItems[lightboxIndex].size || 'Bespoke Custom sizing'}</p>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-semibold text-[#a38c81] tracking-wider block mb-1">Occasion match:</span>
                      <p className="font-medium text-[#c95151] capitalize flex items-center gap-1.5"><Heart className="w-4 h-4 text-[#e28080]" /> {filteredItems[lightboxIndex].category}</p>
                    </div>
                  </div>
                </div>

                {/* Order inquiry callback */}
                <div className="mt-8 pt-4 border-t border-rosegold-100/60">
                  <a
                    href="#design-studio"
                    onClick={closeLightbox}
                    className="w-full text-center inline-block btn-luxury py-3.5 rounded-2xl text-xs font-semibold uppercase tracking-widest"
                  >
                    Bake a design like this
                  </a>
                  <p className="text-[9.5px] text-[#a38c81] text-center mt-2.5 flex items-center justify-center gap-1">
                    <Calendar className="w-3 h-3" /> Average curation time: 7-14 days
                  </p>
                </div>

              </div>              

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </section>
  );
}
