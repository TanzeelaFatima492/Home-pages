import React, { useState } from 'react';
import { Sparkles, Heart, ChevronUp, Mail, CheckCircle, Smartphone } from 'lucide-react';

export default function Footer() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setSubscribed(true);
    setTimeout(() => {
      setEmail('');
    }, 2500);
  };

  const scrollBackToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#3d3430] text-rosegold-100 pt-16 pb-8 px-6 relative overflow-hidden border-t-2 border-rosegold-500/20">
      
      {/* Absolute Decorative Backdrop element */}
      <div className="absolute top-[30%] left-[-15%] w-[400px] h-[400px] rounded-full bg-blossom-500/5 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 right-[-10%] w-[350px] h-[350px] rounded-full bg-rosegold-500/5 blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Top Split Footer Columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-12 pb-16 border-b border-rosegold-100/10">
          
          {/* Col 1: Brand Info */}
          <div className="lg:col-span-4 space-y-6">
            <div className="flex flex-col">
              <span className="text-2xl sm:text-3xl font-serif tracking-widest text-white font-bold">
                Sweet <span className="text-rosegold-300 font-bold">Blossom</span>
              </span>
              <span className="text-[9px] uppercase tracking-[0.3em] text-[#bd8e77] -mt-1 font-bold">
                Luxury Cake Boutique
              </span>
            </div>
            <p className="text-xs text-rosegold-200/70 leading-relaxed font-light">
              Crafting happiness one slice at a time. Sweet Blossom binds rigorous French confectionary principles with elegant organic floral designs to construct stunning centerpiece cake sculptures.
            </p>
            <p className="text-[11px] text-rosegold-400 font-medium flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-rosegold-300" />
              Est. Paris 2011 • Madison Avenue NY
            </p>
          </div>

          {/* Col 2: Fast Navigation Links */}
          <div className="lg:col-span-2.5 space-y-6">
            <h4 className="font-serif text-sm uppercase tracking-wider text-white font-medium border-b border-white/5 pb-2">The Collections</h4>
            <div className="flex flex-col space-y-3 text-xs text-rosegold-200/80 font-light">
              <a href="#featured" className="hover:text-rosegold-300 transition-colors">Wedding Sculptures</a>
              <a href="#featured" className="hover:text-rosegold-300 transition-colors">High Birthdays</a>
              <a href="#featured" className="hover:text-rosegold-300 transition-colors">Anniversary Classics</a>
              <a href="#gallery" className="hover:text-rosegold-300 transition-colors">Design Gallery</a>
              <a href="#design-studio" className="hover:text-rosegold-300 transition-colors">Interactive Customizer</a>
            </div>
          </div>

          {/* Col 3: Curation Hours */}
          <div className="lg:col-span-2.5 space-y-6">
            <h4 className="font-serif text-sm uppercase tracking-wider text-white font-medium border-b border-white/5 pb-2">Hours & Visits</h4>
            <div className="space-y-3.5 text-xs text-rosegold-200/70 font-light">
              <div>
                <strong className="text-rosegold-300 block mb-0.5">Weekdays:</strong>
                <p>Mon - Thu: 09:00 AM - 06:00 PM</p>
              </div>
              <div>
                <strong className="text-rosegold-300 block mb-0.5">Weekends:</strong>
                <p>Fri - Sat: 08:00 AM - 08:30 PM</p>
                <p>Sunday: 10:00 AM - 04:00 PM</p>
              </div>
            </div>
          </div>

          {/* Col 4: Newsletter Signup */}
          <div className="lg:col-span-3 space-y-6">
            <h4 className="font-serif text-sm uppercase tracking-wider text-white font-medium border-b border-white/5 pb-2">Secret drops</h4>
            <p className="text-xs text-rosegold-200/70 leading-relaxed font-light">
              Subscribe to unlock quarterly secret collection flavors, luxury recipe tutorials, and priority catalog bookings.
            </p>

            {!subscribed ? (
              <form onSubmit={handleSubscribe} className="space-y-2">
                <div className="relative">
                  <Mail className="w-3.5 h-3.5 text-rosegold-400 absolute left-3 top-3.5" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    className="w-full bg-[#4e433f]/75 pl-9 pr-4 py-3 pb-3.5 rounded-xl text-xs text-white border border-rosegold-300/10 focus:outline-none focus:border-rosegold-400 focus:bg-[#4e433f]"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-[#cca592] hover:bg-[#b1785d] text-[#3d3430] hover:text-white transition-all font-semibold uppercase tracking-widest text-[9.5px] py-3 rounded-xl cursor-pointer"
                >
                  Join High Society list
                </button>
              </form>
            ) : (
              <div className="p-3 bg-white/5 rounded-xl border border-white/10 flex items-center gap-2.5 text-xs text-green-300 animate-scaleUp">
                <CheckCircle className="w-4 h-4 shrink-0 text-green-400" />
                <span>Subscription confirmed! Thank you!</span>
              </div>
            )}
          </div>

        </div>

        {/* Bottom Bar: Copyright and back-to-top */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-6 text-[10.5px] text-rosegold-200/40">
          
          <div className="flex items-center gap-1.5 order-2 sm:order-1">
            <span>&copy; {new Date().getFullYear()} Sweet Blossom Cake Bakery. All rights reserved.</span>
            <span>•</span>
            <span className="flex items-center gap-1 select-none">Made with <Heart className="w-3 h-3 text-rosegold-400 fill-rosegold-400 inline" /> for special celebrations.</span>
          </div>

          {/* Scroll block trigger */}
          <button
            onClick={scrollBackToTop}
            className="order-1 sm:order-2 p-3 rounded-full bg-[#4e433f] hover:bg-rosegold-500 hover:text-white transition-all text-rosegold-300 hover:scale-105 shadow-md flex items-center justify-center cursor-pointer"
            title="Scroll to Top"
          >
            <ChevronUp className="w-4.5 h-4.5" />
          </button>

        </div>

      </div>
    </footer>
  );
}
