import React, { useState, useEffect } from 'react';
import { Menu, X, Sparkles, Heart, Trash2, Milestone, Calendar, ArrowRight } from 'lucide-react';
import { CustomCakeInquiry } from '../types';

interface NavbarProps {
  onDesignClick: () => void;
  activeSection: string;
}

export default function Navbar({ onDesignClick, activeSection }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [savedInquiries, setSavedInquiries] = useState<CustomCakeInquiry[]>([]);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const loadSavedInquiries = () => {
    const stored = localStorage.getItem('sweet_blossom_inquiries');
    if (stored) {
      try {
        setSavedInquiries(JSON.parse(stored));
      } catch (e) {
        console.error('Failed to parse inquiries', e);
      }
    }
  };

  useEffect(() => {
    loadSavedInquiries();
    // Listening for storage updates or custom events when a cake is created
    const handleStorageChange = () => {
      loadSavedInquiries();
    };
    window.addEventListener('sweet_blossom_inquiry_added', handleStorageChange);
    return () => window.removeEventListener('sweet_blossom_inquiry_added', handleStorageChange);
  }, []);

  const deleteInquiry = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = savedInquiries.filter(item => item.id !== id);
    localStorage.setItem('sweet_blossom_inquiries', JSON.stringify(updated));
    setSavedInquiries(updated);
  };

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'Featured', href: '#featured' },
    { name: 'Why Us', href: '#why-us' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Design Studio', href: '#design-studio' },
    { name: 'Reviews', href: '#reviews' },
    { name: 'Instagram', href: '#instagram' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <>
      <nav id="navbar" className={`fixed top-0 left-0 w-full z-40 transition-all duration-500 ${isScrolled ? 'glass-navbar shadow-md py-3' : 'bg-transparent py-5'}`}>
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          
          {/* Brand Logo */}
          <a href="#home" className="flex flex-col select-none group">
            <span className="text-2xl md:text-3xl font-serif tracking-widest text-gray-900 font-bold group-hover:text-rosegold-500 transition-colors duration-300">
              Sweet <span className="text-rosegold-500 font-bold">Blossom</span>
            </span>
            <span className="text-[9px] uppercase tracking-[0.3em] text-rosegold-500/80 -mt-1 font-bold">
              Luxury Cake Boutique
            </span>
          </a>

          {/* Desktop Nav Links */}
          <div className="hidden lg:flex items-center space-x-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className={`text-sm font-bold uppercase tracking-wider transition-all duration-300 relative py-1 group ${
                  activeSection === link.href.slice(1)
                    ? 'text-rosegold-500 font-extrabold'
                    : 'text-gray-800 hover:text-rosegold-500'
                }`}
              >
                {link.name}
                <span className={`absolute bottom-0 left-0 w-full h-[1.5px] bg-rosegold-300 transition-transform duration-300 origin-left ${activeSection === link.href.slice(1) ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'}`} />
              </a>
            ))}
          </div>

          {/* CTA & Saved Designs Drawer Trigger */}
          <div className="hidden sm:flex items-center space-x-4">
            <button
              id="saved-creations-btn"
              onClick={() => {
                loadSavedInquiries();
                setIsDrawerOpen(true);
              }}
              className="relative p-2.5 rounded-full hover:bg-rosegold-100 transition-colors text-rosegold-500 flex items-center gap-1 group border border-transparent hover:border-rosegold-200"
              title="My Custom Creations"
            >
              <Heart className={`w-5.5 h-5.5 transition-transform duration-300 group-hover:scale-115 ${savedInquiries.length > 0 ? 'fill-rosegold-400 stroke-rosegold-500' : ''}`} />
              {savedInquiries.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-blossom-400 text-white text-[10px] w-5 h-5 flex items-center justify-center font-bold rounded-full shadow-md animate-pulse">
                  {savedInquiries.length}
                </span>
              )}
            </button>
            <button
              id="nav-customizer-cta-btn"
              onClick={onDesignClick}
              className="btn-luxury text-xs font-semibold uppercase tracking-widest px-6 py-2.5 rounded-full select-none cursor-pointer flex items-center gap-2"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Design Studio
            </button>
          </div>

          {/* Mobile Buttons */}
          <div className="flex items-center space-x-3 lg:hidden">
            <button
              onClick={() => {
                loadSavedInquiries();
                setIsDrawerOpen(true);
              }}
              className="relative p-2 rounded-full text-rosegold-500"
            >
              <Heart className={`w-5.5 h-5.5 ${savedInquiries.length > 0 ? 'fill-rosegold-400 stroke-rosegold-500' : ''}`} />
              {savedInquiries.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-blossom-400 text-white text-[9px] w-4.5 h-4.5 flex items-center justify-center font-bold rounded-full">
                  {savedInquiries.length}
                </span>
              )}
            </button>
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 text-[#5d4d42] hover:text-rosegold-500 transition-colors"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </nav>

      {/* Mobile Menu Panel */}
      <div className={`fixed inset-0 z-30 transition-all duration-500 lg:hidden ${isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}>
        <div className="fixed inset-0 bg-black/20 backdrop-blur-sm" onClick={() => setIsOpen(false)} />
        <div className={`fixed top-0 right-0 w-[80%] max-w-sm h-full bg-rosegold-50 shadow-2xl flex flex-col p-8 transition-transform duration-500 ease-out ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
          <div className="flex justify-between items-center mb-8">
            <span className="font-serif text-lg tracking-wider text-[#3d3430]">Explore Sweet Blossom</span>
            <button onClick={() => setIsOpen(false)} className="p-1 rounded-full hover:bg-rosegold-100 text-[#5d4d42]">
              <X className="w-5 h-5" />
            </button>
          </div>
          <div className="flex flex-col space-y-4">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setIsOpen(false)}
                className={`py-2 text-base font-medium uppercase tracking-wider transition-colors border-b border-rosegold-100/50 ${
                  activeSection === link.href.slice(1) ? 'text-rosegold-500' : 'text-[#5d4d42]'
                }`}
              >
                {link.name}
              </a>
            ))}
          </div>
          <div className="mt-auto pt-8">
            <button
              onClick={() => {
                setIsOpen(false);
                onDesignClick();
              }}
              className="w-full btn-luxury font-semibold uppercase tracking-widest py-3.5 rounded-xl flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              Custom Design Studio
            </button>
          </div>
        </div>
      </div>

      {/* Saved Creations Drawer */}
      <div className={`fixed inset-0 z-50 transition-all duration-500 ${isDrawerOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}>
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs" onClick={() => setIsDrawerOpen(false)} />
        <div className={`fixed top-0 right-0 w-full sm:w-[500px] h-full bg-white shadow-2xl flex flex-col transition-transform duration-500 ease-out ${isDrawerOpen ? 'translate-x-0' : 'translate-x-full'}`}>
          
          <div className="p-6 border-b border-rosegold-100 flex items-center justify-between bg-rosegold-50">
            <div className="flex items-center gap-2.5">
              <Heart className="w-5 h-5 text-blossom-400 fill-blossom-100" />
              <h3 className="font-serif text-xl tracking-wide text-[#3d3430]">My Designed Masterpieces</h3>
            </div>
            <button onClick={() => setIsDrawerOpen(false)} className="p-1.5 rounded-full hover:bg-rosegold-100/80 text-[#5d4d42] transition-colors">
              <X className="w-5.5 h-5.5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {savedInquiries.length === 0 ? (
              <div className="h-[60%] flex flex-col items-center justify-center text-center space-y-4">
                <div className="w-[100px] h-[100px] rounded-full bg-rosegold-50 border border-rosegold-100/60 flex items-center justify-center mb-2">
                  <Sparkles className="w-9 h-9 text-rosegold-400" />
                </div>
                <h4 className="font-serif text-lg text-[#5d4d42] font-medium">No Cake Designs Saved Yet</h4>
                <p className="text-xs text-[#8c7366] max-w-xs leading-relaxed">
                  Enter our boutique Custom Designer Studio where you can choose tiers, organic icing flavors, and rose gold floral trims to build your culinary masterpiece.
                </p>
                <button
                  onClick={() => {
                    setIsDrawerOpen(false);
                    onDesignClick();
                  }}
                  className="mt-2 text-xs font-semibold tracking-wider uppercase text-rosegold-500 hover:text-rosegold-600 transition-colors flex items-center gap-1"
                >
                  Go design now <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              savedInquiries.map((inquiry) => (
                <div key={inquiry.id} className="p-4 rounded-xl bg-rosegold-50/50 border border-rosegold-100 hover:border-rosegold-300 transition-all duration-300 shadow-xs relative group/item">
                  
                  <div className="flex justify-between items-start mb-2.5">
                    <div>
                      <span className="inline-block text-[10px] uppercase tracking-wider font-semibold text-rosegold-500 px-2 py-0.5 rounded-md bg-white border border-rosegold-100">
                        {inquiry.category} Edition
                      </span>
                      <h4 className="font-serif text-base text-[#3d3430] mt-1.5">
                        {inquiry.tiers} Tier {inquiry.flavor}
                      </h4>
                    </div>
                    <button
                      onClick={(e) => deleteInquiry(inquiry.id, e)}
                      className="p-1.5 rounded-md text-[#a38c81] hover:text-red-500 hover:bg-red-50 transition-colors"
                      title="Discard Design"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-y-1.5 gap-x-4 text-[11px] text-[#5d4d42] pb-3 border-b border-rosegold-100/50 mb-3">
                    <div><strong className="text-[#a38c81]">Frosting:</strong> {inquiry.frosting}</div>
                    <div><strong className="text-[#a38c81]">Servings:</strong> ~ {inquiry.servings} guests</div>
                    <div><strong className="text-[#a38c81]">Finish:</strong> {inquiry.metallicFinish === 'none' ? 'None' : `${inquiry.metallicFinish} accents`}</div>
                    <div className="flex items-center gap-1"><Calendar className="w-3 h-3 text-[#bd8e77]" /> {inquiry.deliveryDate}</div>
                  </div>

                  {inquiry.accents.length > 0 && (
                    <div className="mb-3">
                      <p className="text-[10px] text-[#a38c81] font-semibold uppercase tracking-wider mb-1">Luxury Ornaments</p>
                      <div className="flex flex-wrap gap-1">
                        {inquiry.accents.map((accent, idx) => (
                          <span key={idx} className="text-[10px] bg-white text-[#5d4d42] px-2 py-0.5 rounded-full border border-rosegold-100/80">
                            {accent}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="flex justify-between items-center text-xs">
                    <span className="text-[10px] text-[#a38c81]">Estimated Value:</span>
                    <strong className="text-sm font-semibold text-rosegold-600">${inquiry.estimatedPrice}</strong>
                  </div>

                </div>
              ))
            )}
          </div>

          {savedInquiries.length > 0 && (
            <div className="p-6 border-t border-rosegold-100 bg-rosegold-50/50 flex flex-col gap-3">
              <div className="flex justify-between items-center text-sm">
                <span className="text-[#5d4d42] font-medium">Total Designs:</span>
                <span className="font-semibold text-rosegold-600">{savedInquiries.length} Cakes</span>
              </div>
              <p className="text-[10.5px] text-[#8c7366] text-center leading-relaxed">
                Our bakers review submitted designs within 12 hours. We will phone you to finalize delivery times and customize exact wedding color details.
              </p>
            </div>
          )}

        </div>
      </div>
    </>
  );
}
