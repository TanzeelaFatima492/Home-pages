import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Twitter, FileText, Share2, CheckCircle } from "lucide-react";

export default function CTA() {
  const [signed, setSigned] = useState(false);

  const handleTwitterShare = () => {
    const text = "Supporting Umme Rabab Chandio in her 6-year struggle for justice against the feudal system. Justice delayed is justice denied. #UmmeRabab #JusticeForChandioFamily";
    const url = window.location.href;
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`;
    window.open(twitterUrl, "_blank", "noopener,noreferrer");
  };

  const handleSignPetition = () => {
    setSigned(true);
    setTimeout(() => setSigned(false), 5000);
  };

  return (
    <section className="py-24 bg-maroon text-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10 pointer-events-none ajrak-pattern invert"></div>
      
      <div className="container mx-auto px-6 relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto"
        >
          <h2 className="text-4xl md:text-6xl font-serif mb-8">Demand Justice</h2>
          <p className="text-xl text-white/80 mb-12 leading-relaxed">
            Umme Rabab's struggle is a fight for every citizen who has been silenced by the feudal system. 
            Your voice can help amplify her call for justice.
          </p>
          
          <div className="flex flex-wrap justify-center gap-6 relative">
            <button 
              onClick={handleTwitterShare}
              className="flex items-center gap-3 px-8 py-4 bg-white text-maroon font-bold uppercase tracking-widest text-sm hover:bg-gray-100 transition-colors rounded-sm"
            >
              <Twitter size={18} />
              Share on Twitter
            </button>
            <button 
              onClick={handleSignPetition}
              disabled={signed}
              className={`flex items-center gap-3 px-8 py-4 border border-white text-white font-bold uppercase tracking-widest text-sm transition-all rounded-sm ${signed ? 'bg-white/20 opacity-70 cursor-default' : 'hover:bg-white/10'}`}
            >
              <FileText size={18} />
              {signed ? "Petition Signed" : "Sign the Petition"}
            </button>

            <AnimatePresence>
              {signed && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="absolute -bottom-16 left-1/2 -translate-x-1/2 flex items-center gap-2 text-white bg-charcoal/50 backdrop-blur-md px-4 py-2 rounded-full border border-white/10 text-sm"
                >
                  <CheckCircle size={16} className="text-green-400" />
                  <span>Thank you! Your support has been recorded.</span>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          
          <div className="mt-24 pt-16 border-t border-white/10">
            <p className="text-sm uppercase tracking-[0.4em] text-white/50 mb-8">Spread the Word</p>
            <div className="flex justify-center gap-8">
              <button 
                onClick={() => {
                  if (navigator.share) {
                    navigator.share({
                      title: 'Umme Rabab: The Barefoot Struggle',
                      text: 'A tribute to Umme Rabab Chandio\'s 6-year journey for justice.',
                      url: window.location.href,
                    }).catch(console.error);
                  } else {
                    // Fallback: Copy to clipboard
                    navigator.clipboard.writeText(window.location.href);
                  }
                }}
                className="hover:text-white/70 transition-colors"
              >
                <Share2 size={24} />
              </button>
              <button 
                onClick={handleTwitterShare}
                className="hover:text-white/70 transition-colors"
              >
                <Twitter size={24} />
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
