import { motion } from "motion/react";
import { ArrowDown } from "lucide-react";

export default function Hero() {
  return (
    <section className="relative min-h-screen flex flex-col lg:flex-row overflow-hidden bg-charcoal">
      {/* Left Content Side */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 lg:p-24 relative z-10 ajrak-pattern">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="max-w-xl"
        >
          <span className="inline-block px-4 py-1 mb-8 border border-maroon text-maroon text-xs tracking-[0.3em] uppercase font-bold bg-maroon/5">
            Justice in the Courts of Pakistan
          </span>
          <h1 className="text-5xl md:text-7xl font-serif text-white mb-8 leading-[1.1] tracking-tight">
            The Barefoot <br />
            <span className="text-maroon italic">Struggle</span>
          </h1>
          <div className="w-20 h-1 bg-maroon mb-8"></div>
          <h2 className="text-2xl md:text-3xl font-serif text-white/90 mb-6 leading-snug">
            Umme Rabab Chandio <br />
            <span className="text-white/50 text-xl md:text-2xl">vs. The Feudal System</span>
          </h2>
          <p className="text-lg text-gray-400 mb-12 font-light leading-relaxed max-w-md">
            A daughter's 6-year journey through the Supreme Court of Pakistan to seek justice for the triple murder of her father, uncle, and grandfather in Mehar, Sindh.
          </p>
          
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8, duration: 1 }}
          >
            <a 
              href="#tragedy" 
              className="group inline-flex items-center gap-4 text-white hover:text-maroon transition-colors"
            >
              <div className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center group-hover:border-maroon group-hover:bg-maroon transition-all duration-300">
                <ArrowDown size={20} />
              </div>
              <span className="text-xs uppercase tracking-[0.3em] font-bold">Explore the Journey</span>
            </a>
          </motion.div>
        </motion.div>
      </div>

      {/* Right Image Side - Dual Imagery */}
      <div className="w-full lg:w-1/2 h-[60vh] lg:h-screen relative flex flex-col">
        {/* Top Image: Pakistan Court Symbolism */}
        <div className="h-1/2 w-full relative overflow-hidden border-b border-white/5">
          <motion.div
            initial={{ scale: 1.1, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 1.5 }}
            className="w-full h-full"
          >
            <img
              src="https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&q=80&w=1200"
              alt="Supreme Court of Pakistan Symbolism"
              className="w-full h-full object-cover grayscale brightness-50"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-maroon/10 mix-blend-multiply"></div>
            <div className="absolute bottom-4 left-6">
              <p className="text-[10px] uppercase tracking-widest text-white/40 font-bold">The Halls of Justice</p>
            </div>
          </motion.div>
        </div>

        {/* Bottom Image: Umme Rabab Representation */}
        <div className="h-1/2 w-full relative overflow-hidden">
          <motion.div
            initial={{ scale: 1.1, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 1.5, delay: 0.3 }}
            className="w-full h-full"
          >
            <img
              src="https://images.unsplash.com/photo-1505664194779-8beaceb93744?auto=format&fit=crop&q=80&w=1200"
              alt="Umme Rabab Chandio Representation"
              className="w-full h-full object-cover grayscale brightness-75"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-charcoal via-transparent to-transparent"></div>
            <div className="absolute bottom-4 left-6">
              <p className="text-[10px] uppercase tracking-widest text-white/40 font-bold">The Barefoot Daughter</p>
            </div>
          </motion.div>
        </div>
        
        {/* Side Rail Text Overlay */}
        <div className="absolute right-10 top-1/2 -translate-y-1/2 hidden xl:block z-20">
          <p className="writing-mode-vertical-rl text-[10px] uppercase tracking-[0.5em] text-white/40 font-mono">
            Supreme Court of Pakistan — Mehar, Sindh
          </p>
        </div>
      </div>
    </section>
  );
}

