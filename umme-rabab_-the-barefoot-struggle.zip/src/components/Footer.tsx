import { Twitter, Facebook, Instagram, Mail } from "lucide-react";

export default function Footer() {
  return (
    <footer className="py-16 bg-charcoal text-white border-t border-white/5">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h3 className="text-2xl font-serif mb-4">Umme Rabab Chandio</h3>
            <p className="text-gray-500 max-w-md leading-relaxed">
              Dedicated to the memory of Mukhtiar, Karamullah, and Kabil Chandio. 
              A tribute to the resilience of a daughter who refused to be silenced.
            </p>
          </div>
          <div className="md:text-right">
            <p className="text-3xl md:text-4xl font-serif italic text-maroon mb-4">
              "Justice Delayed is Justice Denied"
            </p>
            <div className="flex justify-start md:justify-end gap-6 text-gray-500">
              <a href="#" className="hover:text-white transition-colors"><Twitter size={20} /></a>
              <a href="#" className="hover:text-white transition-colors"><Facebook size={20} /></a>
              <a href="#" className="hover:text-white transition-colors"><Instagram size={20} /></a>
              <a href="#" className="hover:text-white transition-colors"><Mail size={20} /></a>
            </div>
          </div>
        </div>
        
        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] uppercase tracking-[0.2em] text-gray-600 font-bold">
          <p>© 2026 Justice for Chandio Family. All Rights Reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Use</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
