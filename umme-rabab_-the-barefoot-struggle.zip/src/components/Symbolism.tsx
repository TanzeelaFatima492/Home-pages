import { motion } from "motion/react";
import { Quote } from "lucide-react";

export default function Symbolism() {
  return (
    <section className="py-32 bg-charcoal text-white relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-maroon to-transparent"></div>
      <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-maroon to-transparent"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-maroon/20 mb-12"
          >
            <Quote className="text-maroon" size={32} />
          </motion.div>
          
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-3xl md:text-5xl font-serif italic leading-snug mb-12 text-balance"
          >
            "I walk barefoot to the courts not out of choice, but because the weight of my grief and the search for justice has stripped me of everything else. My feet touch the earth that holds my elders, and every step is a reminder of the promise I made to them."
          </motion.h2>
          
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5 }}
            className="flex flex-col items-center"
          >
            <div className="w-12 h-px bg-maroon mb-6"></div>
            <p className="text-maroon uppercase tracking-[0.3em] font-bold text-sm">Umme Rabab Chandio</p>
            <p className="text-gray-500 text-xs mt-2 uppercase tracking-widest">The Barefoot Daughter of Sindh</p>
          </motion.div>
        </div>
      </div>
      
      {/* Background Symbolism */}
      <div className="absolute -right-20 top-1/2 -translate-y-1/2 opacity-5 pointer-events-none">
        <h2 className="text-[20rem] font-serif font-bold leading-none select-none">JUSTICE</h2>
      </div>
    </section>
  );
}
