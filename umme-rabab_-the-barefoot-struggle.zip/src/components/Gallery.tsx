import { motion } from "motion/react";
import { Play, ExternalLink } from "lucide-react";

const mediaItems = [
  {
    type: "video",
    title: "Umme Rabab's Address to Media",
    thumbnail: "https://images.unsplash.com/photo-1495020689067-958852a7765e?auto=format&fit=crop&q=80&w=800",
    link: "#"
  },
  {
    type: "article",
    title: "The Daughter Who Challenged Feudalism",
    thumbnail: "https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&q=80&w=800",
    link: "#"
  },
  {
    type: "video",
    title: "Protests in Mehar: A Documentary",
    thumbnail: "https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&q=80&w=800",
    link: "#"
  },
  {
    type: "article",
    title: "Legal Hurdles in the Chandio Case",
    thumbnail: "https://images.unsplash.com/photo-1450101499163-c8848c66ca85?auto=format&fit=crop&q=80&w=800",
    link: "#"
  }
];

export default function Gallery() {
  return (
    <section className="py-24 bg-gray-50">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div>
            <h2 className="text-4xl font-serif mb-4">Media & News</h2>
            <p className="text-gray-500 uppercase tracking-widest text-xs">Documenting the struggle</p>
          </div>
          <a href="#" className="text-maroon font-bold text-sm uppercase tracking-widest border-b border-maroon pb-1 hover:opacity-70 transition-opacity">
            View All Coverage
          </a>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {mediaItems.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group cursor-pointer"
            >
              <div className="relative aspect-video mb-4 overflow-hidden rounded-sm bg-charcoal">
                <img 
                  src={item.thumbnail} 
                  alt={item.title}
                  className="w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-105 transition-all duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  {item.type === "video" ? (
                    <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center group-hover:bg-maroon group-hover:scale-110 transition-all duration-300">
                      <Play className="text-white fill-white" size={20} />
                    </div>
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center group-hover:bg-charcoal group-hover:scale-110 transition-all duration-300">
                      <ExternalLink className="text-white" size={20} />
                    </div>
                  )}
                </div>
              </div>
              <h3 className="text-lg font-serif group-hover:text-maroon transition-colors leading-tight">
                {item.title}
              </h3>
              <p className="text-[10px] uppercase tracking-widest text-gray-400 mt-2 font-bold">
                {item.type}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
