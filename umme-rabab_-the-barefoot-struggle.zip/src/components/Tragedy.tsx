import { motion } from "motion/react";

const martyrs = [
  {
    name: "Mukhtiar Chandio",
    role: "Father",
    description: "A man of integrity, murdered in cold blood while defending his family's honor.",
    image: "https://picsum.photos/seed/mukhtiar/400/500"
  },
  {
    name: "Karamullah Chandio",
    role: "Uncle",
    description: "Stood firm against the feudal lords, paying the ultimate price for his resistance.",
    image: "https://picsum.photos/seed/karamullah/400/500"
  },
  {
    name: "Kabil Chandio",
    role: "Grandfather",
    description: "The patriarch of the family, whose wisdom and presence were silenced by violence.",
    image: "https://picsum.photos/seed/kabil/400/500"
  }
];

export default function Tragedy() {
  return (
    <section id="tragedy" className="py-24 bg-white ajrak-pattern">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-start mb-20">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl font-serif mb-8 leading-tight">
              The Tragedy of <br />
              <span className="text-maroon italic">January 17, 2018</span>
            </h2>
            <div className="space-y-6 text-gray-600 leading-relaxed text-lg">
              <p>
                In the quiet town of Mehar, Sindh, a brutal act of violence shattered a family and ignited a movement. 
                Three generations of the Chandio family were gunned down in broad daylight, allegedly at the behest of powerful feudal lords.
              </p>
              <p>
                The incident wasn't just a crime; it was a demonstration of the unchecked power that the feudal system holds over the lives of ordinary citizens in rural Pakistan.
              </p>
              <p className="font-medium text-charcoal">
                Mukhtiar, Karamullah, and Kabil Chandio became martyrs of a system that values land and lineage over human life.
              </p>
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="aspect-[4/3] bg-charcoal overflow-hidden rounded-sm shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1505664194779-8beaceb93744?auto=format&fit=crop&q=80&w=1200" 
                alt="Mehar Sindh Landscape" 
                className="w-full h-full object-cover opacity-60"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 flex items-center justify-center p-12">
                <p className="text-white text-2xl md:text-3xl font-serif italic text-center leading-relaxed">
                  "The soil of Mehar still cries for the blood that was spilled that day."
                </p>
              </div>
            </div>
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-maroon/10 -z-10"></div>
          </motion.div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {martyrs.map((martyr, index) => (
            <motion.div
              key={martyr.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2, duration: 0.6 }}
              className="group"
            >
              <div className="relative aspect-[3/4] mb-6 overflow-hidden bg-gray-100">
                <img 
                  src={martyr.image} 
                  alt={martyr.name}
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-maroon/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              </div>
              <h3 className="text-xl font-serif mb-1">{martyr.name}</h3>
              <p className="text-maroon text-xs uppercase tracking-widest font-bold mb-3">{martyr.role}</p>
              <p className="text-gray-500 text-sm leading-relaxed">{martyr.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
