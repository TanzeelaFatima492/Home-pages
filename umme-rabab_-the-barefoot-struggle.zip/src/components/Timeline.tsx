import { motion } from "motion/react";

const events = [
  {
    date: "Jan 17, 2018",
    title: "The Mehar Massacre",
    description: "Umme Rabab's father, uncle, and grandfather are murdered in Mehar, Sindh, allegedly by feudal lords."
  },
  {
    date: "2019",
    title: "Supreme Court Intervention",
    description: "The Supreme Court of Pakistan takes suo motu notice of the case after Umme Rabab's persistent protests."
  },
  {
    date: "2020 - 2023",
    title: "The Barefoot Protests",
    description: "Umme Rabab becomes a national symbol of resistance, walking barefoot to every court hearing across the country."
  },
  {
    date: "2024",
    title: "Ongoing Trial",
    description: "The struggle continues as the trial moves through the legal system, facing delays but never losing momentum."
  }
];

export default function Timeline() {
  return (
    <section className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-20">
          <h2 className="text-4xl md:text-5xl font-serif mb-4">A Journey of Resilience</h2>
          <p className="text-gray-500 uppercase tracking-widest text-sm">Timeline of the Struggle</p>
        </div>

        <div className="relative max-w-4xl mx-auto">
          {/* Vertical Line */}
          <div className="absolute left-1/2 -translate-x-1/2 top-0 bottom-0 w-px bg-gray-200 hidden md:block"></div>
          
          <div className="space-y-16">
            {events.map((event, index) => (
              <motion.div
                key={event.date}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className={`relative flex flex-col md:flex-row items-center ${
                  index % 2 === 0 ? "md:flex-row-reverse" : ""
                }`}
              >
                {/* Dot */}
                <div className="absolute left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-maroon border-4 border-white shadow-sm z-10 hidden md:block"></div>
                
                <div className="w-full md:w-1/2 px-8 text-center md:text-left">
                  <div className={`${index % 2 === 0 ? "md:text-left" : "md:text-right"}`}>
                    <span className="text-maroon font-bold text-lg mb-2 block">{event.date}</span>
                    <h3 className="text-2xl font-serif mb-3">{event.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{event.description}</p>
                  </div>
                </div>
                <div className="w-full md:w-1/2 hidden md:block"></div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
