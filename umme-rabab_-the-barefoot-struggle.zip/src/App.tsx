import Hero from "./components/Hero";
import Tragedy from "./components/Tragedy";
import Symbolism from "./components/Symbolism";
import Timeline from "./components/Timeline";
import Gallery from "./components/Gallery";
import CTA from "./components/CTA";
import Footer from "./components/Footer";
import { motion, useScroll, useSpring } from "motion/react";

export default function App() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  return (
    <main className="relative">
      {/* Progress Bar */}
      <motion.div
        className="fixed top-0 left-0 right-0 h-1 bg-maroon z-50 origin-left"
        style={{ scaleX }}
      />

      <Hero />
      <Tragedy />
      <Symbolism />
      <Timeline />
      <Gallery />
      <CTA />
      <Footer />
    </main>
  );
}
