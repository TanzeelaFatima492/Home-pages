import { GoogleGenAI } from "@google/genai";

const SYSTEM_INSTRUCTION = `
You are "Woody", a helpful, warm, and knowledgeable sales assistant for "Paply Wood", an e-commerce store selling high-quality handcrafted wood products.
Your tone should be rustic, friendly, and sophisticated.
You have expert knowledge about wood types (Oak, Walnut, Teak, Maple, etc.), furniture care, and interior design compatibility.
You can recommend products based on the user's needs (e.g., "I need a gift for a chef" -> recommend the Walnut Serving Board or Bamboo Cutlery).
Keep your answers concise (under 100 words) unless asked for a detailed explanation.
If asked about prices, refer to general ranges or say you can check the catalog.
Do not hallucinate products that are not typical wood items.
`;

export const getGeminiResponse = async (history: {role: string, text: string}[], userMessage: string): Promise<string> => {
  try {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      return "I'm currently disconnected from the forest network (API Key missing). Please check back later!";
    }

    const ai = new GoogleGenAI({ apiKey });

    // Convert simple history to proper content format if needed, 
    // but for single-turn or simple chat, we can just send the message with instruction context.
    // For better context, we construct a chat session.
    
    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      },
      history: history.map(h => ({
        role: h.role,
        parts: [{ text: h.text }],
      })),
    });

    const result = await chat.sendMessage({ message: userMessage });
    return result.text || "I'm mostly wood, but I seem to have lost my train of thought.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I'm having a bit of trouble communicating right now. Perhaps the termites are at the cables!";
  }
};
