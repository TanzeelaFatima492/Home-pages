import React, { useState, useEffect, useMemo } from 'react';
import { ShoppingBag, Heart, Menu, X, Search, User, Star, ArrowRight, Check, Trash2, Plus, Minus, MessageCircle } from 'lucide-react';
import { PRODUCTS } from './constants';
import { Product, CartItem, ViewState, Category, ChatMessage } from './types';
import { getGeminiResponse } from './services/geminiService';

// --- Context/State Helpers ---
// (In a larger app, these would be in separate files, keeping here for the single-block requirement constraints where possible)

const App: React.FC = () => {
  // State
  const [view, setView] = useState<ViewState>('HOME');
  const [activeProduct, setActiveProduct] = useState<Product | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<Category | 'All'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Chatbot State
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    { role: 'model', text: "Hello! I'm Woody. Looking for something specific or need wood care advice?" }
  ]);
  const [chatInput, setChatInput] = useState('');
  const [isChatLoading, setIsChatLoading] = useState(false);

  // Derived State
  const cartTotal = useMemo(() => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0);
  }, [cart]);

  const cartCount = useMemo(() => {
    return cart.reduce((count, item) => count + item.quantity, 0);
  }, [cart]);

  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter(p => {
      const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
      const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [selectedCategory, searchQuery]);

  // Actions
  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (id: number) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const updateQuantity = (id: number, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const toggleWishlist = (id: number) => {
    setWishlist(prev => prev.includes(id) ? prev.filter(pid => pid !== id) : [...prev, id]);
  };

  const handleProductClick = (product: Product) => {
    setActiveProduct(product);
    setView('PRODUCT_DETAILS');
    window.scrollTo(0,0);
  };

  const handleChatSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const userMsg: ChatMessage = { role: 'user', text: chatInput };
    setChatMessages(prev => [...prev, userMsg]);
    setChatInput('');
    setIsChatLoading(true);

    // Format history for API
    const history = chatMessages.map(m => ({ role: m.role, text: m.text }));
    
    const responseText = await getGeminiResponse(history, userMsg.text);
    
    setChatMessages(prev => [...prev, { role: 'model', text: responseText }]);
    setIsChatLoading(false);
  };

  // --- Components ---

  const Navbar = () => (
    <nav className="sticky top-0 z-40 bg-wood-50/90 backdrop-blur-md border-b border-wood-200 shadow-sm">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        {/* Logo */}
        <div 
          className="flex items-center gap-2 cursor-pointer" 
          onClick={() => setView('HOME')}
        >
          <div className="w-8 h-8 bg-wood-800 rounded-lg flex items-center justify-center text-wood-50 font-serif font-bold text-xl">P</div>
          <span className="text-2xl font-serif font-bold text-wood-900 tracking-tight">Paply Wood</span>
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-8">
          <button onClick={() => setView('HOME')} className={`text-sm font-medium hover:text-wood-600 transition ${view === 'HOME' ? 'text-wood-800 font-bold' : 'text-wood-500'}`}>Home</button>
          <button onClick={() => { setView('SHOP'); setSelectedCategory('All'); }} className={`text-sm font-medium hover:text-wood-600 transition ${view === 'SHOP' ? 'text-wood-800 font-bold' : 'text-wood-500'}`}>Shop</button>
          <button onClick={() => { setView('SHOP'); setSelectedCategory(Category.FURNITURE); }} className="text-sm font-medium text-wood-500 hover:text-wood-600 transition">Furniture</button>
          <button onClick={() => { setView('SHOP'); setSelectedCategory(Category.DECOR); }} className="text-sm font-medium text-wood-500 hover:text-wood-600 transition">Decor</button>
        </div>

        {/* Icons */}
        <div className="flex items-center gap-4">
          <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="md:hidden text-wood-800">
            <Menu size={24} />
          </button>
          <div className="relative hidden md:block">
            <input 
              type="text" 
              placeholder="Search..." 
              value={searchQuery}
              onChange={(e) => { setSearchQuery(e.target.value); if (view !== 'SHOP') setView('SHOP'); }}
              className="pl-9 pr-4 py-1.5 bg-wood-100 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-wood-400 w-40 transition-all focus:w-64"
            />
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-wood-500" />
          </div>
          <button className="relative text-wood-800 hover:text-wood-600 transition">
            <Heart size={22} />
            {wishlist.length > 0 && <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">{wishlist.length}</span>}
          </button>
          <button 
            className="relative text-wood-800 hover:text-wood-600 transition"
            onClick={() => setIsCartOpen(true)}
          >
            <ShoppingBag size={22} />
            {cartCount > 0 && <span className="absolute -top-2 -right-2 bg-wood-600 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">{cartCount}</span>}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-wood-50 border-t border-wood-200 px-4 py-4 flex flex-col gap-4">
           <input 
              type="text" 
              placeholder="Search..." 
              value={searchQuery}
              onChange={(e) => { setSearchQuery(e.target.value); if (view !== 'SHOP') setView('SHOP'); }}
              className="w-full pl-4 pr-4 py-2 bg-wood-100 rounded-full text-sm focus:outline-none"
            />
           <button onClick={() => { setView('HOME'); setIsMobileMenuOpen(false); }} className="text-left text-wood-800 font-medium">Home</button>
           <button onClick={() => { setView('SHOP'); setSelectedCategory('All'); setIsMobileMenuOpen(false); }} className="text-left text-wood-800 font-medium">Shop All</button>
        </div>
      )}
    </nav>
  );

  const CartDrawer = () => (
    <>
      {isCartOpen && <div className="fixed inset-0 bg-black/30 z-40 backdrop-blur-sm transition-opacity" onClick={() => setIsCartOpen(false)} />}
      <div className={`fixed top-0 right-0 h-full w-full sm:w-[400px] bg-white z-50 shadow-2xl transform transition-transform duration-300 ease-in-out ${isCartOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="flex flex-col h-full">
          <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-wood-50">
            <h2 className="text-xl font-serif font-bold text-wood-900">Your Cart</h2>
            <button onClick={() => setIsCartOpen(false)} className="text-wood-500 hover:text-wood-800"><X size={24} /></button>
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {cart.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-wood-400 space-y-4">
                <ShoppingBag size={48} />
                <p className="text-lg">Your cart is empty</p>
                <button onClick={() => { setIsCartOpen(false); setView('SHOP'); }} className="text-wood-600 underline hover:text-wood-800">Start Shopping</button>
              </div>
            ) : (
              cart.map(item => (
                <div key={item.id} className="flex gap-4">
                  <img src={item.image} alt={item.name} className="w-20 h-20 object-cover rounded-lg bg-gray-100" />
                  <div className="flex-1">
                    <h3 className="font-medium text-wood-900">{item.name}</h3>
                    <p className="text-wood-500 text-sm mb-2">${item.price.toFixed(2)}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center border border-wood-200 rounded-md">
                        <button onClick={() => updateQuantity(item.id, -1)} className="px-2 py-1 hover:bg-wood-100 text-wood-600"><Minus size={14} /></button>
                        <span className="px-2 text-sm text-wood-900 min-w-[20px] text-center">{item.quantity}</span>
                        <button onClick={() => updateQuantity(item.id, 1)} className="px-2 py-1 hover:bg-wood-100 text-wood-600"><Plus size={14} /></button>
                      </div>
                      <button onClick={() => removeFromCart(item.id)} className="text-red-400 hover:text-red-600"><Trash2 size={18} /></button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {cart.length > 0 && (
            <div className="p-6 border-t border-gray-100 bg-wood-50">
              <div className="flex justify-between mb-4">
                <span className="text-wood-600">Subtotal</span>
                <span className="font-bold text-wood-900 text-lg">${cartTotal.toFixed(2)}</span>
              </div>
              <p className="text-xs text-wood-400 mb-4 text-center">Shipping and taxes calculated at checkout.</p>
              <button 
                onClick={() => { setIsCartOpen(false); setView('CHECKOUT'); }}
                className="w-full bg-wood-800 text-wood-50 py-4 rounded-xl font-semibold hover:bg-wood-900 transition flex items-center justify-center gap-2 shadow-lg shadow-wood-800/20"
              >
                Proceed to Checkout <ArrowRight size={18} />
              </button>
            </div>
          )}
        </div>
      </div>
    </>
  );

  const ProductCard: React.FC<{ product: Product }> = ({ product }) => (
    <div className="group">
      <div className="relative overflow-hidden rounded-2xl bg-gray-100 aspect-[3/4] mb-4 cursor-pointer" onClick={() => handleProductClick(product)}>
        <img 
          src={product.image} 
          alt={product.name} 
          className="h-full w-full object-cover object-center group-hover:scale-105 transition duration-500"
        />
        <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
           <button 
             onClick={(e) => { e.stopPropagation(); toggleWishlist(product.id); }}
             className={`p-2 rounded-full shadow-md transition ${wishlist.includes(product.id) ? 'bg-red-500 text-white' : 'bg-white text-gray-900 hover:bg-gray-50'}`}
           >
             <Heart size={18} fill={wishlist.includes(product.id) ? "currentColor" : "none"} />
           </button>
        </div>
        <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-full group-hover:translate-y-0 transition duration-300 bg-gradient-to-t from-black/60 to-transparent">
           <button 
            onClick={(e) => { e.stopPropagation(); addToCart(product); }}
            className="w-full bg-white text-wood-900 py-2 rounded-lg text-sm font-medium hover:bg-wood-50 transition"
           >
             Add to Cart
           </button>
        </div>
      </div>
      <div className="flex justify-between items-start">
        <div>
          <h3 onClick={() => handleProductClick(product)} className="text-lg font-medium text-wood-900 cursor-pointer hover:text-wood-600 transition">{product.name}</h3>
          <p className="text-sm text-wood-500 mt-1">{product.category}</p>
        </div>
        <p className="text-lg font-semibold text-wood-800">${product.price}</p>
      </div>
    </div>
  );

  const HeroSection = () => (
    <div className="relative bg-wood-800 text-wood-50 overflow-hidden">
      <div className="absolute inset-0 z-0">
         <img src="https://images.unsplash.com/photo-1617104551722-3b2d51366400?q=80&w=2070&auto=format&fit=crop" className="w-full h-full object-cover opacity-40" alt="Workshop" />
      </div>
      <div className="relative z-10 container mx-auto px-4 py-32 md:py-48 text-center">
        <span className="inline-block py-1 px-3 border border-wood-300/30 rounded-full text-wood-200 text-sm mb-6 backdrop-blur-sm">Sustainable & Handcrafted</span>
        <h1 className="text-5xl md:text-7xl font-serif font-bold mb-6 leading-tight">Crafted by Nature,<br /> Perfected by Hand.</h1>
        <p className="text-xl text-wood-100 max-w-2xl mx-auto mb-10 font-light">Discover our curated collection of artisanal wood furniture and decor, designed to bring warmth and character to your modern home.</p>
        <button 
          onClick={() => setView('SHOP')}
          className="bg-wood-100 text-wood-900 px-8 py-4 rounded-xl font-semibold text-lg hover:bg-white transition shadow-xl shadow-black/10"
        >
          Shop Collection
        </button>
      </div>
    </div>
  );

  const Footer = () => (
    <footer className="bg-wood-900 text-wood-200 pt-20 pb-10">
      <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-10 mb-16">
        <div>
          <div className="flex items-center gap-2 mb-6">
            <div className="w-8 h-8 bg-wood-100 rounded-lg flex items-center justify-center text-wood-900 font-serif font-bold text-xl">P</div>
            <span className="text-2xl font-serif font-bold text-white tracking-tight">Paply Wood</span>
          </div>
          <p className="text-wood-400 text-sm leading-relaxed">Bringing the serenity of the forest into your living space with sustainably sourced, handcrafted wooden masterpieces.</p>
        </div>
        <div>
          <h4 className="text-white font-serif font-bold mb-4">Shop</h4>
          <ul className="space-y-2 text-sm text-wood-400">
            <li className="cursor-pointer hover:text-white">New Arrivals</li>
            <li className="cursor-pointer hover:text-white">Furniture</li>
            <li className="cursor-pointer hover:text-white">Home Decor</li>
            <li className="cursor-pointer hover:text-white">Kitchenware</li>
          </ul>
        </div>
        <div>
          <h4 className="text-white font-serif font-bold mb-4">Support</h4>
          <ul className="space-y-2 text-sm text-wood-400">
            <li className="cursor-pointer hover:text-white">Shipping & Returns</li>
            <li className="cursor-pointer hover:text-white">Care Instructions</li>
            <li className="cursor-pointer hover:text-white">FAQ</li>
            <li className="cursor-pointer hover:text-white">Contact Us</li>
          </ul>
        </div>
        <div>
          <h4 className="text-white font-serif font-bold mb-4">Stay in the loop</h4>
          <div className="flex gap-2">
            <input type="email" placeholder="Email address" className="bg-wood-800 border-none text-sm p-3 rounded-lg w-full focus:ring-1 focus:ring-wood-400 text-white" />
            <button className="bg-wood-100 text-wood-900 px-4 rounded-lg font-medium hover:bg-white">Join</button>
          </div>
        </div>
      </div>
      <div className="container mx-auto px-4 pt-8 border-t border-wood-800 text-center text-sm text-wood-500">
        © 2025 Paply Wood. All rights reserved. Designed with React & Tailwind.
      </div>
    </footer>
  );

  const ChatWidget = () => (
    <>
      {!isChatOpen && (
        <button 
          onClick={() => setIsChatOpen(true)}
          className="fixed bottom-6 right-6 bg-wood-800 text-white p-4 rounded-full shadow-xl shadow-wood-900/30 hover:scale-110 transition z-40 flex items-center gap-2 group"
        >
          <MessageCircle size={24} />
          <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-300 whitespace-nowrap">Ask Woody</span>
        </button>
      )}
      {isChatOpen && (
        <div className="fixed bottom-6 right-6 w-full max-w-xs sm:max-w-sm bg-white rounded-2xl shadow-2xl border border-wood-100 z-50 flex flex-col overflow-hidden h-[500px]">
          <div className="bg-wood-800 p-4 flex justify-between items-center">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <h3 className="text-white font-medium">Woody AI Assistant</h3>
            </div>
            <button onClick={() => setIsChatOpen(false)} className="text-wood-300 hover:text-white"><X size={18} /></button>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-wood-50">
            {chatMessages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] p-3 rounded-xl text-sm leading-relaxed ${msg.role === 'user' ? 'bg-wood-600 text-white rounded-br-none' : 'bg-white text-wood-800 shadow-sm border border-wood-100 rounded-bl-none'}`}>
                  {msg.text}
                </div>
              </div>
            ))}
            {isChatLoading && (
              <div className="flex justify-start">
                <div className="bg-white p-3 rounded-xl rounded-bl-none shadow-sm border border-wood-100 flex gap-1">
                  <span className="w-2 h-2 bg-wood-400 rounded-full animate-bounce"></span>
                  <span className="w-2 h-2 bg-wood-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></span>
                  <span className="w-2 h-2 bg-wood-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></span>
                </div>
              </div>
            )}
          </div>
          <form onSubmit={handleChatSubmit} className="p-3 bg-white border-t border-wood-100 flex gap-2">
            <input 
              type="text" 
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              placeholder="Ask about wood care..."
              className="flex-1 bg-wood-50 border border-wood-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-wood-400"
            />
            <button type="submit" disabled={isChatLoading} className="bg-wood-800 text-white p-2 rounded-lg hover:bg-wood-700 disabled:opacity-50">
              <ArrowRight size={18} />
            </button>
          </form>
        </div>
      )}
    </>
  );

  // --- View Renderers ---

  const renderHome = () => (
    <>
      <HeroSection />
      <div className="container mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <span className="text-wood-500 font-medium tracking-wider text-sm uppercase">Curated Selection</span>
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-wood-900 mt-2">Featured Products</h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {PRODUCTS.slice(0, 4).map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
        <div className="mt-16 text-center">
          <button onClick={() => setView('SHOP')} className="inline-flex items-center gap-2 text-wood-800 font-semibold hover:gap-4 transition-all">View All Products <ArrowRight size={20} /></button>
        </div>
      </div>

      <div className="bg-wood-100 py-20">
        <div className="container mx-auto px-4 flex flex-col md:flex-row items-center gap-12">
          <div className="flex-1">
            <img src="https://images.unsplash.com/photo-1601058268499-e52642340f39?q=80&w=2070&auto=format&fit=crop" alt="Craftsman" className="rounded-2xl shadow-2xl rotate-2 hover:rotate-0 transition duration-500" />
          </div>
          <div className="flex-1 space-y-6">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-wood-900">Generations of Craftsmanship</h2>
            <p className="text-wood-700 leading-relaxed text-lg">
              At Paply Wood, we don't just sell objects; we share stories. Every piece in our collection is hand-selected from artisans who honor the tradition of woodworking. Using sustainably sourced timber and non-toxic finishes, we ensure that your purchase cares for the planet as much as it cares for your home.
            </p>
            <div className="grid grid-cols-2 gap-6 pt-4">
              <div>
                <h4 className="font-bold text-wood-900 text-xl">100%</h4>
                <p className="text-wood-600 text-sm">Sustainable Wood</p>
              </div>
              <div>
                <h4 className="font-bold text-wood-900 text-xl">50+</h4>
                <p className="text-wood-600 text-sm">Artisan Partners</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );

  const renderShop = () => (
    <div className="container mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row justify-between items-end mb-10 border-b border-wood-200 pb-6 gap-4">
        <div>
           <h1 className="text-4xl font-serif font-bold text-wood-900 mb-2">Shop</h1>
           <p className="text-wood-500">Browse our complete collection of wooden treasures.</p>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2 w-full md:w-auto no-scrollbar">
          {['All', ...Object.values(Category)].map(cat => (
            <button 
              key={cat} 
              onClick={() => setSelectedCategory(cat as Category | 'All')}
              className={`px-4 py-2 rounded-full text-sm whitespace-nowrap transition ${selectedCategory === cat ? 'bg-wood-800 text-white' : 'bg-wood-100 text-wood-600 hover:bg-wood-200'}`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>
      
      {filteredProducts.length === 0 ? (
        <div className="py-20 text-center">
           <p className="text-wood-500 text-lg">No products found matching your criteria.</p>
           <button onClick={() => { setSelectedCategory('All'); setSearchQuery(''); }} className="mt-4 text-wood-800 font-medium underline">Clear Filters</button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {filteredProducts.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );

  const renderProductDetails = () => {
    if (!activeProduct) return null;
    return (
      <div className="container mx-auto px-4 py-12">
        <button onClick={() => setView('SHOP')} className="mb-8 text-wood-500 hover:text-wood-900 flex items-center gap-2 text-sm font-medium"><ArrowRight size={16} className="rotate-180" /> Back to Shop</button>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-20">
          <div className="bg-gray-100 rounded-3xl overflow-hidden aspect-square sticky top-24">
            <img src={activeProduct.image} alt={activeProduct.name} className="w-full h-full object-cover" />
          </div>
          <div className="flex flex-col justify-center">
             <div className="mb-6">
               <span className="text-wood-500 text-sm tracking-wide uppercase font-medium">{activeProduct.category}</span>
               <h1 className="text-4xl md:text-5xl font-serif font-bold text-wood-900 mt-2 mb-4">{activeProduct.name}</h1>
               <div className="flex items-center gap-4">
                 <span className="text-2xl font-medium text-wood-800">${activeProduct.price}</span>
                 <div className="flex items-center gap-1 text-yellow-500 text-sm">
                   <Star fill="currentColor" size={16} />
                   <span className="text-wood-600 ml-1 font-medium">{activeProduct.rating} ({activeProduct.reviews} reviews)</span>
                 </div>
               </div>
             </div>

             <p className="text-wood-600 text-lg leading-relaxed mb-8">{activeProduct.description}</p>
             
             <div className="mb-8 p-6 bg-wood-50 rounded-xl border border-wood-100">
               <h3 className="font-serif font-bold text-wood-900 mb-4">Product Details</h3>
               <ul className="space-y-2">
                 {activeProduct.details.map((detail, i) => (
                   <li key={i} className="flex items-center gap-3 text-wood-700 text-sm">
                     <div className="w-1.5 h-1.5 rounded-full bg-wood-400"></div>
                     {detail}
                   </li>
                 ))}
               </ul>
             </div>

             <div className="flex gap-4">
               <button 
                onClick={() => addToCart(activeProduct)}
                className="flex-1 bg-wood-800 text-white py-4 rounded-xl font-bold text-lg hover:bg-wood-900 transition shadow-xl shadow-wood-900/10"
               >
                 Add to Cart
               </button>
               <button 
                 onClick={() => toggleWishlist(activeProduct.id)}
                 className={`p-4 rounded-xl border-2 transition ${wishlist.includes(activeProduct.id) ? 'border-red-500 text-red-500 bg-red-50' : 'border-wood-200 text-wood-800 hover:border-wood-400'}`}
               >
                 <Heart fill={wishlist.includes(activeProduct.id) ? "currentColor" : "none"} size={24} />
               </button>
             </div>
          </div>
        </div>
      </div>
    );
  };

  const renderCheckout = () => (
    <div className="container mx-auto px-4 py-12 max-w-6xl">
       <h1 className="text-3xl font-serif font-bold text-wood-900 mb-10 text-center">Secure Checkout</h1>
       <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
         {/* Form */}
         <div className="lg:col-span-2 space-y-8">
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-wood-100">
              <h2 className="text-xl font-bold text-wood-900 mb-6 flex items-center gap-2"><User size={20} /> Contact Information</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-wood-700">Email Address</label>
                  <input type="email" className="w-full p-3 bg-wood-50 rounded-lg border border-wood-200 focus:ring-2 focus:ring-wood-400 focus:outline-none" placeholder="john@example.com" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-wood-700">Phone Number</label>
                  <input type="tel" className="w-full p-3 bg-wood-50 rounded-lg border border-wood-200 focus:ring-2 focus:ring-wood-400 focus:outline-none" placeholder="+1 (555) 000-0000" />
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-sm border border-wood-100">
              <h2 className="text-xl font-bold text-wood-900 mb-6">Shipping Address</h2>
              <div className="grid grid-cols-1 gap-6">
                <div className="grid grid-cols-2 gap-6">
                   <input type="text" placeholder="First Name" className="w-full p-3 bg-wood-50 rounded-lg border border-wood-200 focus:ring-2 focus:ring-wood-400 focus:outline-none" />
                   <input type="text" placeholder="Last Name" className="w-full p-3 bg-wood-50 rounded-lg border border-wood-200 focus:ring-2 focus:ring-wood-400 focus:outline-none" />
                </div>
                <input type="text" placeholder="Address" className="w-full p-3 bg-wood-50 rounded-lg border border-wood-200 focus:ring-2 focus:ring-wood-400 focus:outline-none" />
                <div className="grid grid-cols-3 gap-6">
                   <input type="text" placeholder="City" className="w-full p-3 bg-wood-50 rounded-lg border border-wood-200 focus:ring-2 focus:ring-wood-400 focus:outline-none" />
                   <input type="text" placeholder="State" className="w-full p-3 bg-wood-50 rounded-lg border border-wood-200 focus:ring-2 focus:ring-wood-400 focus:outline-none" />
                   <input type="text" placeholder="ZIP Code" className="w-full p-3 bg-wood-50 rounded-lg border border-wood-200 focus:ring-2 focus:ring-wood-400 focus:outline-none" />
                </div>
              </div>
            </div>
            
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-wood-100">
               <h2 className="text-xl font-bold text-wood-900 mb-6">Payment Details</h2>
               <div className="p-4 bg-wood-50 rounded-lg border border-wood-200 text-wood-500 text-sm text-center">
                 Payment integration is simulated for this demo. No actual charge will be made.
               </div>
            </div>

            <button 
              onClick={() => { setCart([]); setView('SUCCESS'); window.scrollTo(0,0); }}
              className="w-full bg-wood-800 text-white py-4 rounded-xl font-bold text-lg hover:bg-wood-900 transition shadow-xl shadow-wood-900/10"
            >
              Pay ${cartTotal.toFixed(2)}
            </button>
         </div>

         {/* Order Summary */}
         <div className="lg:col-span-1">
           <div className="bg-white p-6 rounded-2xl shadow-sm border border-wood-100 sticky top-24">
             <h3 className="text-lg font-bold text-wood-900 mb-4">Order Summary</h3>
             <div className="space-y-4 mb-6 max-h-60 overflow-y-auto">
               {cart.map(item => (
                 <div key={item.id} className="flex justify-between items-center text-sm">
                   <div className="flex items-center gap-3">
                     <div className="relative">
                       <img src={item.image} alt={item.name} className="w-12 h-12 rounded-md object-cover" />
                       <span className="absolute -top-2 -right-2 bg-gray-500 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">{item.quantity}</span>
                     </div>
                     <span className="text-wood-800 font-medium max-w-[120px] truncate">{item.name}</span>
                   </div>
                   <span className="text-wood-600">${(item.price * item.quantity).toFixed(2)}</span>
                 </div>
               ))}
             </div>
             <div className="border-t border-wood-100 pt-4 space-y-2">
               <div className="flex justify-between text-wood-600 text-sm">
                 <span>Subtotal</span>
                 <span>${cartTotal.toFixed(2)}</span>
               </div>
               <div className="flex justify-between text-wood-600 text-sm">
                 <span>Shipping</span>
                 <span>Free</span>
               </div>
               <div className="flex justify-between text-wood-900 font-bold text-lg pt-2">
                 <span>Total</span>
                 <span>${cartTotal.toFixed(2)}</span>
               </div>
             </div>
           </div>
         </div>
       </div>
    </div>
  );

  const renderSuccess = () => (
    <div className="container mx-auto px-4 py-24 text-center">
      <div className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-8">
        <Check size={48} />
      </div>
      <h1 className="text-4xl font-serif font-bold text-wood-900 mb-4">Thank you for your order!</h1>
      <p className="text-wood-600 text-lg max-w-md mx-auto mb-10">Your handcrafted items are being prepared with care. You will receive an email confirmation shortly.</p>
      <button onClick={() => setView('HOME')} className="bg-wood-800 text-white px-8 py-3 rounded-xl font-semibold hover:bg-wood-900 transition">Return Home</button>
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <CartDrawer />
      <main className="flex-grow">
        {view === 'HOME' && renderHome()}
        {view === 'SHOP' && renderShop()}
        {view === 'PRODUCT_DETAILS' && renderProductDetails()}
        {view === 'CHECKOUT' && renderCheckout()}
        {view === 'SUCCESS' && renderSuccess()}
      </main>
      <Footer />
      <ChatWidget />
    </div>
  );
};

export default App;
