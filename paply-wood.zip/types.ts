export enum Category {
  FURNITURE = 'Furniture',
  DECOR = 'Decor',
  KITCHEN = 'Kitchen',
  ACCESSORIES = 'Accessories',
}

export interface Product {
  id: number;
  name: string;
  price: number;
  description: string;
  category: Category;
  image: string;
  rating: number;
  reviews: number;
  details: string[];
}

export interface CartItem extends Product {
  quantity: number;
}

export type ViewState = 'HOME' | 'SHOP' | 'PRODUCT_DETAILS' | 'CHECKOUT' | 'SUCCESS';

// Gemini Types
export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
