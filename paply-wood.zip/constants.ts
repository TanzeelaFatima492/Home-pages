import { Category, Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: 1,
    name: "Oak Minimalist Chair",
    price: 249.00,
    category: Category.FURNITURE,
    description: "A sturdy, handcrafted oak chair with a timeless minimalist design. Perfect for dining rooms or home offices.",
    image: "https://picsum.photos/seed/chair1/600/800",
    rating: 4.8,
    reviews: 124,
    details: ["Solid White Oak", "Hand-oiled finish", "Ergonomic backrest", "Weight: 7kg"]
  },
  {
    id: 2,
    name: "Walnut Serving Board",
    price: 85.00,
    category: Category.KITCHEN,
    description: "Premium black walnut serving board with live edge details. Ideal for charcuterie and serving guests.",
    image: "https://picsum.photos/seed/board2/600/800",
    rating: 4.9,
    reviews: 89,
    details: ["Sustainably sourced Walnut", "Food-safe mineral oil finish", "24 inch length", "Hand wash only"]
  },
  {
    id: 3,
    name: "Maple Geometric Lamp",
    price: 120.00,
    category: Category.DECOR,
    description: "Modern geometric desk lamp crafted from light maple wood. Casts a warm, ambient glow.",
    image: "https://picsum.photos/seed/lamp3/600/800",
    rating: 4.7,
    reviews: 56,
    details: ["Maple wood base", "LED bulb included", "Touch dimmer switch", "Height: 30cm"]
  },
  {
    id: 4,
    name: "Teak Coffee Table",
    price: 450.00,
    category: Category.FURNITURE,
    description: "Mid-century modern inspired coffee table made from reclaimed teak. Durable and stylish.",
    image: "https://picsum.photos/seed/table4/600/800",
    rating: 4.6,
    reviews: 210,
    details: ["Reclaimed Teak", "Matte varnish", "Assembly required", "Diameter: 90cm"]
  },
  {
    id: 5,
    name: "Bamboo Cutlery Set",
    price: 35.00,
    category: Category.KITCHEN,
    description: "Eco-friendly reusable bamboo cutlery set with a canvas travel pouch.",
    image: "https://picsum.photos/seed/cutlery5/600/800",
    rating: 4.5,
    reviews: 340,
    details: ["100% Organic Bamboo", "Includes fork, spoon, knife", "Dishwasher safe", "Biodegradable"]
  },
  {
    id: 6,
    name: "Ebony Desk Organizer",
    price: 65.00,
    category: Category.ACCESSORIES,
    description: "Sleek dark ebony wood organizer for your pens, phone, and essentials.",
    image: "https://picsum.photos/seed/desk6/600/800",
    rating: 4.8,
    reviews: 78,
    details: ["Solid Ebony", "Non-slip base", "Phone stand slot", "Width: 25cm"]
  },
  {
    id: 7,
    name: "Cedar Wall Planter",
    price: 55.00,
    category: Category.DECOR,
    description: "Aromatic cedar wall-mounted planter. Adds a touch of greenery and nature to any wall.",
    image: "https://picsum.photos/seed/planter7/600/800",
    rating: 4.9,
    reviews: 112,
    details: ["Western Red Cedar", "Water-resistant", "Mounting hardware included", "Holds 4-inch pots"]
  },
  {
    id: 8,
    name: "Mahogany Watch Stand",
    price: 45.00,
    category: Category.ACCESSORIES,
    description: "Display your timepiece with elegance on this hand-carved mahogany watch stand.",
    image: "https://picsum.photos/seed/watch8/600/800",
    rating: 4.7,
    reviews: 45,
    details: ["Genuine Mahogany", "Soft leather cushion", "Compact design", "Great gift item"]
  }
];
