
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY || "";

export const getBusinessAdvice = async (userPrompt: string): Promise<string> => {
  if (!API_KEY) {
    return "API Key is missing. Please ensure process.env.API_KEY is configured.";
  }

  const ai = new GoogleGenAI({ apiKey: API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: userPrompt,
      config: {
        systemInstruction: `You are NexusAI, a world-class senior business consultant with expertise in strategy, finance, marketing, and digital transformation. 
        Your goal is to provide concise, actionable, and professional advice to business owners and executives. 
        Always structure your responses with clear headings, bullet points, and a professional tone. 
        If asked about a specific industry, provide context-relevant insights. 
        Keep responses helpful but grounded in realistic business practices.`,
        temperature: 0.7,
        topP: 0.95,
      },
    });

    return response.text || "I'm sorry, I couldn't generate a response at this time.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "An error occurred while consulting the AI. Please try again later.";
  }
};
