
import React, { useState, useRef, useEffect } from 'react';
import { getBusinessAdvice } from '../services/geminiService';
import { ChatMessage } from '../types';

/**
 * A simple formatter to handle markdown-like syntax from Gemini
 * without requiring heavy external libraries.
 */
const FormattedText: React.FC<{ content: string }> = ({ content }) => {
  const lines = content.split('\n');
  
  return (
    <div className="space-y-2">
      {lines.map((line, idx) => {
        // Headers (### Header)
        if (line.startsWith('### ')) {
          return <h4 key={idx} className="text-lg font-bold text-slate-900 mt-4 mb-2">{line.replace('### ', '')}</h4>;
        }
        if (line.startsWith('## ')) {
          return <h3 key={idx} className="text-xl font-bold text-slate-900 mt-5 mb-3">{line.replace('## ', '')}</h3>;
        }
        if (line.startsWith('# ')) {
          return <h2 key={idx} className="text-2xl font-bold text-slate-900 mt-6 mb-4">{line.replace('# ', '')}</h2>;
        }

        // List items (- or *)
        if (line.trim().startsWith('- ') || line.trim().startsWith('* ')) {
          const text = line.trim().substring(2);
          return (
            <div key={idx} className="flex items-start space-x-2 ml-4">
              <span className="text-blue-500 font-bold">•</span>
              <span className="flex-1">{parseInline(text)}</span>
            </div>
          );
        }

        // Numbered lists (1.)
        const numberedMatch = line.trim().match(/^\d+\.\s+(.*)/);
        if (numberedMatch) {
          return (
            <div key={idx} className="flex items-start space-x-2 ml-4">
              <span className="text-blue-600 font-bold min-w-[1.2rem]">{line.trim().split('.')[0]}.</span>
              <span className="flex-1">{parseInline(numberedMatch[1])}</span>
            </div>
          );
        }

        // Code Blocks (Basic check)
        if (line.startsWith('```')) {
          return null; // Simplified for this example, we'll treat lines between ``` as mono
        }

        // Default paragraph
        return line.trim() === '' ? <div key={idx} className="h-2" /> : <p key={idx} className="leading-relaxed">{parseInline(line)}</p>;
      })}
    </div>
  );
};

// Helper to handle bold and inline code
function parseInline(text: string) {
  const parts = text.split(/(\*\*.*?\*\*|`.*?`)/g);
  return parts.map((part, i) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return <strong key={i} className="font-bold text-slate-900">{part.slice(2, -2)}</strong>;
    }
    if (part.startsWith('`') && part.endsWith('`')) {
      return <code key={i} className="bg-slate-100 text-pink-600 px-1.5 py-0.5 rounded text-xs font-mono">{part.slice(1, -1)}</code>;
    }
    return part;
  });
}

const AIConsultant: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'assistant',
      content: "Hello! I'm **NexusAI**, your virtual strategic partner. \n\nHow can I help you today? Typical areas of consultation include:\n- ### Growth Strategies\n- ### Operational Efficiency\n- ### Market Sentiment Analysis\n- ### Digital Transformation Roadmaps",
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    const aiResponse = await getBusinessAdvice(input);
    
    const assistantMessage: ChatMessage = {
      role: 'assistant',
      content: aiResponse,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, assistantMessage]);
    setIsLoading(false);
  };

  return (
    <div className="flex flex-col h-[700px] w-full max-w-5xl mx-auto bg-white rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.1)] overflow-hidden border border-slate-200">
      {/* Header */}
      <div className="bg-slate-950 p-6 flex items-center justify-between border-b border-slate-800">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-500/20">
              <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
            </div>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-4 border-slate-950 rounded-full"></div>
          </div>
          <div>
            <h3 className="text-white font-bold text-xl tracking-tight">NexusAI Strategy Advisor</h3>
            <p className="text-slate-400 text-xs font-medium uppercase tracking-widest">Enterprise Intelligence Tier</p>
          </div>
        </div>
        <div className="hidden sm:flex space-x-2">
          <div className="px-3 py-1 bg-white/5 rounded-full text-[10px] font-bold text-slate-400 border border-white/10 uppercase">v3.1-Flash</div>
          <div className="px-3 py-1 bg-blue-500/10 rounded-full text-[10px] font-bold text-blue-400 border border-blue-500/20 uppercase">Encrypted</div>
        </div>
      </div>

      {/* Chat Area */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-8 space-y-8 bg-slate-50/50">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-fade-in`}>
            <div className={`max-w-[90%] sm:max-w-[80%] rounded-3xl px-6 py-5 shadow-sm transition-all ${
              msg.role === 'user' 
                ? 'bg-slate-900 text-white rounded-br-none shadow-xl shadow-slate-200' 
                : 'bg-white text-slate-700 border border-slate-200 rounded-bl-none'
            }`}>
              {msg.role === 'assistant' ? (
                <FormattedText content={msg.content} />
              ) : (
                <div className="whitespace-pre-wrap text-base leading-relaxed">
                  {msg.content}
                </div>
              )}
              <div className={`text-[10px] mt-4 font-bold uppercase tracking-widest opacity-40 flex items-center ${msg.role === 'user' ? 'text-white' : 'text-slate-500'}`}>
                {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                {msg.role === 'assistant' && <span className="ml-2 inline-block w-1 h-1 bg-slate-400 rounded-full"></span>}
                {msg.role === 'assistant' && <span className="ml-2">Verified Output</span>}
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white border border-slate-200 rounded-3xl rounded-bl-none px-6 py-5 shadow-sm">
              <div className="flex space-x-2 py-1">
                <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce delay-100"></div>
                <div className="w-2 h-2 bg-blue-200 rounded-full animate-bounce delay-200"></div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Input Form */}
      <form onSubmit={handleSend} className="p-6 bg-white border-t border-slate-200">
        <div className="relative flex items-center">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Discuss market entry, SWOT analysis, or cost optimization..."
            className="w-full pl-6 pr-32 py-4 rounded-2xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-base text-slate-900"
          />
          <div className="absolute right-2 flex space-x-2">
            <button
              type="submit"
              disabled={isLoading || !input.trim()}
              className="bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white px-6 py-2.5 rounded-xl font-bold transition-all flex items-center space-x-2 shadow-lg shadow-blue-500/20 active:scale-95"
            >
              <span className="hidden sm:inline">Consult</span>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </button>
          </div>
        </div>
        <p className="mt-3 text-[10px] text-slate-400 font-medium uppercase tracking-[0.2em] text-center">
          NexusAI is an advisory tool. Always verify strategic outputs with human experts.
        </p>
      </form>
    </div>
  );
};

export default AIConsultant;
