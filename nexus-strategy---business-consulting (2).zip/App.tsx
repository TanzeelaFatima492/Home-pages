
import React, { useState } from 'react';
import AIConsultant from './components/AIConsultant';
import Dashboard from './components/Dashboard';
import { Service, Testimonial } from './types';

const services: Service[] = [
  {
    id: '1',
    title: 'Strategic Advisory',
    description: 'Bespoke roadmaps for long-term growth and market dominance.',
    icon: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z',
    features: ['Market Entry Strategy', 'Competitive Analysis', 'Growth Roadmapping']
  },
  {
    id: '2',
    title: 'Digital Transformation',
    description: 'Modernizing your tech stack to drive efficiency and innovation.',
    icon: 'M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4',
    features: ['AI Integration', 'Process Automation', 'Cloud Migration']
  },
  {
    id: '3',
    title: 'Financial Excellence',
    description: 'Optimizing capital structures and financial reporting systems.',
    icon: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z',
    features: ['Cost Optimization', 'M&A Support', 'Capital Allocation']
  }
];

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Elena Rodriguez",
    role: "CEO",
    company: "TechFlow Systems",
    content: "Nexus redefined how we approach global scaling. Their AI-driven insights saved us months of trial and error.",
    avatar: "https://picsum.photos/100/100?random=1"
  },
  {
    id: 2,
    name: "Marcus Thorne",
    role: "COO",
    company: "Thorne Manufacturing",
    content: "The digital transformation they spearheaded reduced our operational costs by 34% in the first year alone.",
    avatar: "https://picsum.photos/100/100?random=2"
  }
];

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'home' | 'ai' | 'services'>('home');

  return (
    <div className="min-h-screen flex flex-col font-sans">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20">
            <div className="flex items-center">
              <div className="flex-shrink-0 flex items-center space-x-2 cursor-pointer" onClick={() => setActiveTab('home')}>
                <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-blue-500/30">N</div>
                <span className="text-2xl font-serif font-bold tracking-tight text-slate-900">Nexus Strategy</span>
              </div>
              <div className="hidden md:ml-10 md:flex md:space-x-8">
                <button 
                  onClick={() => setActiveTab('home')}
                  className={`inline-flex items-center px-1 pt-1 text-sm font-semibold transition-all ${activeTab === 'home' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-500 hover:text-slate-900'}`}
                >
                  Overview
                </button>
                <button 
                  onClick={() => setActiveTab('services')}
                  className={`inline-flex items-center px-1 pt-1 text-sm font-semibold transition-all ${activeTab === 'services' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-500 hover:text-slate-900'}`}
                >
                  Solutions
                </button>
                <button 
                  onClick={() => setActiveTab('ai')}
                  className={`inline-flex items-center px-1 pt-1 text-sm font-semibold transition-all ${activeTab === 'ai' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-500 hover:text-slate-900'}`}
                >
                  AI Advisor
                </button>
              </div>
            </div>
            <div className="flex items-center">
              <button className="bg-slate-900 hover:bg-slate-800 text-white px-6 py-2.5 rounded-full font-bold text-sm transition-all shadow-lg hover:shadow-xl active:scale-95">
                Book Consultation
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Content Area */}
      <div className="flex-grow">
        {activeTab === 'home' && (
          <>
            {/* Hero Section */}
            <header className="relative py-24 md:py-32 overflow-hidden bg-slate-950 text-white">
              <div className="absolute inset-0 overflow-hidden pointer-events-none">
                <div className="absolute top-0 -left-1/4 w-[600px] h-[600px] bg-blue-600 rounded-full blur-[160px] opacity-20"></div>
                <div className="absolute bottom-0 -right-1/4 w-[600px] h-[600px] bg-indigo-600 rounded-full blur-[160px] opacity-20"></div>
              </div>
              
              <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
                <div className="inline-flex items-center space-x-2 bg-white/10 px-4 py-2 rounded-full border border-white/20 mb-8 animate-pulse">
                  <span className="flex h-2 w-2 rounded-full bg-blue-400 shadow-[0_0_8px_rgba(96,165,250,0.8)]"></span>
                  <span className="text-xs font-bold tracking-widest uppercase">Pioneering Strategy with AI</span>
                </div>
                <h1 className="text-5xl md:text-8xl font-serif font-bold mb-8 leading-[1.1] tracking-tight max-w-5xl mx-auto">
                  Architecting <span className="text-blue-500">Global Success</span> with Intelligence
                </h1>
                <p className="text-slate-400 text-lg md:text-2xl max-w-3xl mx-auto mb-12 leading-relaxed font-light">
                  Bridging the gap between ambitious vision and executable reality through elite strategic consulting and proprietary AI insights.
                </p>
                <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-6">
                  <button 
                    onClick={() => setActiveTab('ai')}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-10 py-5 rounded-2xl font-bold text-lg transition-all shadow-2xl shadow-blue-500/20 hover:-translate-y-1 flex items-center justify-center space-x-3"
                  >
                    <span>Consult NexusAI</span>
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                  </button>
                  <button 
                    onClick={() => setActiveTab('services')}
                    className="bg-white/5 hover:bg-white/10 backdrop-blur-md text-white border border-white/20 px-10 py-5 rounded-2xl font-bold text-lg transition-all"
                  >
                    Explore Methodologies
                  </button>
                </div>
              </div>
            </header>

            {/* Impact Section */}
            <div className="py-16 bg-white border-b border-slate-100">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-12 text-center">
                  <div className="p-4">
                    <div className="text-5xl font-black text-slate-900 mb-2 font-serif">$2.4B+</div>
                    <div className="text-xs text-slate-500 uppercase tracking-[0.2em] font-bold">Capital Optimized</div>
                  </div>
                  <div className="p-4">
                    <div className="text-5xl font-black text-slate-900 mb-2 font-serif">150+</div>
                    <div className="text-xs text-slate-500 uppercase tracking-[0.2em] font-bold">Fortune 500 Partners</div>
                  </div>
                  <div className="p-4">
                    <div className="text-5xl font-black text-slate-900 mb-2 font-serif">94%</div>
                    <div className="text-xs text-slate-500 uppercase tracking-[0.2em] font-bold">Strategy Implementation</div>
                  </div>
                  <div className="p-4">
                    <div className="text-5xl font-black text-slate-900 mb-2 font-serif">12</div>
                    <div className="text-xs text-slate-500 uppercase tracking-[0.2em] font-bold">Global Innovation Hubs</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Services Highlights */}
            <section className="py-32 bg-slate-50">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-20">
                  <h2 className="text-4xl md:text-6xl font-serif font-bold text-slate-900 mb-6">Expertise Redefined</h2>
                  <p className="text-slate-600 max-w-2xl mx-auto text-xl font-light">Our specialized consulting practices are engineered to navigate complexity and deliver durable competitive advantages.</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
                  {services.map(service => (
                    <div key={service.id} className="bg-white p-10 rounded-[2.5rem] shadow-sm hover:shadow-2xl hover:shadow-blue-500/5 transition-all duration-500 border border-slate-100 group">
                      <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mb-8 group-hover:bg-blue-600 group-hover:text-white transition-all duration-300">
                        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={service.icon} />
                        </svg>
                      </div>
                      <h3 className="text-2xl font-bold text-slate-900 mb-4">{service.title}</h3>
                      <p className="text-slate-600 mb-8 leading-relaxed text-lg">{service.description}</p>
                      <ul className="space-y-4 mb-10">
                        {service.features.map((feature, i) => (
                          <li key={i} className="flex items-center text-slate-700">
                            <div className="w-5 h-5 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                              <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                              </svg>
                            </div>
                            <span className="font-medium">{feature}</span>
                          </li>
                        ))}
                      </ul>
                      <button className="text-blue-600 font-bold flex items-center group-hover:translate-x-3 transition-transform duration-300">
                        Details
                        <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                        </svg>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            {/* Dashboard Visual Section */}
            <section className="py-32 bg-white overflow-hidden">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex flex-col lg:flex-row items-center gap-20">
                  <div className="flex-1 text-left">
                    <h2 className="text-4xl md:text-6xl font-serif font-bold text-slate-900 mb-8 leading-tight">Data-Driven <br/>Decision Making</h2>
                    <p className="text-slate-600 mb-12 text-xl font-light leading-relaxed">
                      Beyond intuition, we rely on deep-tech analytics. Our strategic interventions are validated through real-time operational metrics and market sentiment analysis.
                    </p>
                    <div className="grid grid-cols-1 gap-10">
                      <div className="flex items-start space-x-6 group">
                        <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                          <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                          </svg>
                        </div>
                        <div>
                          <h4 className="text-xl font-bold text-slate-900 mb-2">Alpha-Driven Growth</h4>
                          <p className="text-slate-500 leading-relaxed">Our proprietary AI identifies micro-inefficiencies that, when corrected, yield significant bottom-line improvements.</p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-6 group">
                        <div className="w-16 h-16 bg-indigo-50 rounded-2xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                          <svg className="w-8 h-8 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                          </svg>
                        </div>
                        <div>
                          <h4 className="text-xl font-bold text-slate-900 mb-2">Risk Mitigation 2.0</h4>
                          <p className="text-slate-500 leading-relaxed">Real-time simulation of market shocks allows our clients to pivot before volatility impacts their valuation.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex-1 w-full relative">
                    <div className="absolute -inset-4 bg-blue-500/5 rounded-[3rem] blur-2xl"></div>
                    <Dashboard />
                  </div>
                </div>
              </div>
            </section>

            {/* Testimonials */}
            <section className="py-32 bg-slate-950 text-white relative">
              <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
              <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-24">
                  <h2 className="text-4xl md:text-6xl font-serif font-bold mb-6">Partners in Progress</h2>
                  <p className="text-slate-400 text-xl font-light">Global leaders rely on Nexus to navigate their most pivotal moments.</p>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
                  {testimonials.map(t => (
                    <div key={t.id} className="relative bg-white/5 backdrop-blur-sm border border-white/10 p-12 rounded-[3rem] group hover:bg-white/[0.08] transition-all">
                      <div className="mb-10 text-blue-500">
                        <svg className="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M14.017 21L14.017 18C14.017 16.8954 14.9124 16 16.017 16H19.017C19.5693 16 20.017 15.5523 20.017 15V9C20.017 8.44772 19.5693 8 19.017 8H15.017C14.4647 8 14.017 8.44772 14.017 9V12C14.017 12.5523 13.5693 13 13.017 13H12.017V21H14.017ZM6.017 21L6.017 18C6.017 16.8954 6.91243 16 8.017 16H11.017C11.5693 16 12.017 15.5523 12.017 15V9C12.017 8.44772 11.5693 8 11.017 8H7.01701C6.46473 8 6.01701 8.44772 6.01701 9V12C6.01701 12.5523 5.5693 13 5.01701 13H4.01701V21H6.01701Z" />
                        </svg>
                      </div>
                      <p className="text-2xl italic text-slate-200 mb-12 leading-relaxed font-light">"{t.content}"</p>
                      <div className="flex items-center space-x-6">
                        <img src={t.avatar} alt={t.name} className="w-16 h-16 rounded-2xl border-2 border-blue-500 shadow-xl shadow-blue-500/20" />
                        <div>
                          <h4 className="text-xl font-bold text-white mb-1">{t.name}</h4>
                          <p className="text-blue-400 font-semibold tracking-wide uppercase text-xs">{t.role} — {t.company}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          </>
        )}

        {/* AI Advisor Tab */}
        {activeTab === 'ai' && (
          <main className="min-h-[calc(100vh-80px)] bg-slate-100 flex items-center justify-center p-4 md:p-12">
            <div className="w-full max-w-7xl animate-fade-in-up">
              <div className="text-center mb-12">
                <h1 className="text-4xl md:text-6xl font-serif font-bold text-slate-900 mb-6">NexusAI Strategy Desk</h1>
                <p className="text-slate-600 max-w-2xl mx-auto text-xl font-light leading-relaxed">
                  Tap into our proprietary strategic intelligence. Ask about market analysis, SWOT structures, or operational workflows.
                </p>
              </div>
              <AIConsultant />
            </div>
          </main>
        )}

        {/* Services Tab */}
        {activeTab === 'services' && (
          <main className="bg-white py-24 md:py-32">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
               <div className="text-center mb-24">
                <h1 className="text-5xl md:text-7xl font-serif font-bold text-slate-900 mb-8 leading-tight">Strategic Solutions</h1>
                <p className="text-slate-600 max-w-3xl mx-auto text-xl font-light leading-relaxed">
                  We deploy multi-disciplinary teams across three core domains to catalyze transformational growth.
                </p>
              </div>
              <div className="grid grid-cols-1 gap-24">
                {services.map((s, idx) => (
                  <div key={s.id} className={`flex flex-col ${idx % 2 === 1 ? 'lg:flex-row-reverse' : 'lg:flex-row'} items-center gap-20`}>
                    <div className="flex-1">
                      <div className="inline-block px-4 py-2 bg-blue-50 text-blue-600 rounded-lg text-sm font-bold tracking-widest uppercase mb-6">
                        Practice Area 0{s.id}
                      </div>
                      <h3 className="text-4xl md:text-5xl font-serif font-bold mb-8 text-slate-900">{s.title}</h3>
                      <p className="text-slate-600 mb-10 text-2xl font-light leading-relaxed">{s.description}</p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        {s.features.map((f, i) => (
                          <div key={i} className="flex items-center p-5 bg-slate-50 rounded-2xl border border-slate-100 group hover:bg-blue-600 hover:text-white transition-all duration-300">
                            <div className="w-3 h-3 bg-blue-600 group-hover:bg-white rounded-full mr-4 shadow-xl"></div>
                            <span className="text-slate-800 group-hover:text-white font-bold text-lg">{f}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="flex-1 w-full">
                       <div className="aspect-square bg-slate-100 rounded-[4rem] flex items-center justify-center p-12 border-2 border-dashed border-slate-200 relative group overflow-hidden">
                          <div className="absolute inset-0 bg-blue-600 opacity-0 group-hover:opacity-5 transition-opacity"></div>
                          <svg className="w-48 h-48 text-slate-200 group-hover:text-blue-100 group-hover:scale-110 transition-all duration-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={0.5} d={s.icon} />
                          </svg>
                          <div className="absolute bottom-10 left-10 text-slate-400 font-mono text-xs opacity-50">#STRAT_{s.id} // SOLUTION_REF</div>
                       </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </main>
        )}
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold shadow-lg shadow-blue-500/30">N</div>
                <span className="text-2xl font-serif font-bold text-slate-900">Nexus Strategy</span>
              </div>
              <p className="text-slate-500 max-w-sm text-lg leading-relaxed">
                Elite business consultation powered by advanced AI. Building the resilient organizations of tomorrow.
              </p>
            </div>
            <div>
              <h5 className="font-bold text-slate-900 mb-6 uppercase tracking-widest text-xs">Firm</h5>
              <ul className="space-y-4 text-slate-500 font-medium">
                <li><a href="#" className="hover:text-blue-600 transition-colors">Our Ethos</a></li>
                <li><a href="#" className="hover:text-blue-600 transition-colors">Leadership</a></li>
                <li><a href="#" className="hover:text-blue-600 transition-colors">Client Results</a></li>
                <li><a href="#" className="hover:text-blue-600 transition-colors">Careers</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-bold text-slate-900 mb-6 uppercase tracking-widest text-xs">Contact</h5>
              <ul className="space-y-4 text-slate-500 font-medium">
                <li><a href="#" className="hover:text-blue-600 transition-colors">New York Office</a></li>
                <li><a href="#" className="hover:text-blue-600 transition-colors">London Office</a></li>
                <li><a href="#" className="hover:text-blue-600 transition-colors">Singapore Office</a></li>
                <li><a href="#" className="hover:text-blue-600 transition-colors">advisory@nexus-strat.com</a></li>
              </ul>
            </div>
          </div>
          <div className="flex flex-col md:flex-row justify-between items-center pt-8 border-t border-slate-100 text-slate-400 text-sm font-medium">
            <p>&copy; 2024 Nexus Strategic Advisory Group. All rights reserved.</p>
            <div className="flex space-x-8 mt-4 md:mt-0">
              <a href="#" className="hover:text-blue-600 transition-colors">Privacy Charter</a>
              <a href="#" className="hover:text-blue-600 transition-colors">Terms of Engagement</a>
              <a href="#" className="hover:text-blue-600 transition-colors">AI Disclosure</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
