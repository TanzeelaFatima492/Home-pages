/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from './hooks/useTheme';
import Navbar from './components/Navbar';
import Footer from './components/Footer';

// Pages
import Home from './pages/Home';
import Countdown from './pages/Countdown';
import GreetingGenerator from './pages/GreetingGenerator';
import Recipes from './pages/Recipes';
import Charity from './pages/Charity';
import Outfits from './pages/Outfits';
import Wishes from './pages/Wishes';
import Gallery from './pages/Gallery';
import Contact from './pages/Contact';

export default function App() {
  return (
    <ThemeProvider>
      <Router>
        <div className="min-h-screen flex flex-col">
          <Navbar />
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/countdown" element={<Countdown />} />
              <Route path="/greetings" element={<GreetingGenerator />} />
              <Route path="/recipes" element={<Recipes />} />
              <Route path="/charity" element={<Charity />} />
              <Route path="/outfits" element={<Outfits />} />
              <Route path="/wishes" element={<Wishes />} />
              <Route path="/gallery" element={<Gallery />} />
              <Route path="/contact" element={<Contact />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </Router>
    </ThemeProvider>
  );
}
