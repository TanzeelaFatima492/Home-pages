import { motion } from 'motion/react';

export default function Lantern({ className = "" }: { className?: string }) {
  return (
    <motion.div
      className={`relative w-12 h-20 ${className}`}
      animate={{
        y: [0, -20, 0],
        rotate: [-5, 5, -5]
      }}
      transition={{
        duration: 4,
        repeat: Infinity,
        ease: "easeInOut"
      }}
    >
      {/* Lantern Top */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-6 h-4 bg-eid-gold rounded-t-full"></div>
      {/* Lantern Body */}
      <div className="absolute top-4 left-0 w-full h-12 bg-eid-gold/80 rounded-lg shadow-[0_0_20px_rgba(212,175,55,0.5)] flex items-center justify-center">
        <div className="w-4 h-8 bg-eid-accent/40 rounded-full blur-sm"></div>
      </div>
      {/* Lantern Bottom */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-4 bg-eid-gold rounded-b-lg"></div>
      {/* Tassels */}
      <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 flex space-x-1">
        <div className="w-0.5 h-4 bg-eid-gold"></div>
        <div className="w-0.5 h-6 bg-eid-gold"></div>
        <div className="w-0.5 h-4 bg-eid-gold"></div>
      </div>
    </motion.div>
  );
}
