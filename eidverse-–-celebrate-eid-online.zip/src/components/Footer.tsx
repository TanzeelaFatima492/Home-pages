import { Facebook, Twitter, Instagram, Youtube, Heart } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-eid-blue border-t border-white/10 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <Link to="/" className="text-3xl font-serif font-bold text-eid-gold mb-4 block">
              EidVerse
            </Link>
            <p className="text-white/60 max-w-md leading-relaxed">
              Celebrate the joy of Eid with your loved ones. EidVerse is your digital companion for 
              everything Eid—from countdowns and greetings to recipes and charity.
            </p>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold text-white mb-6">Quick Links</h4>
            <ul className="space-y-4">
              <li><Link to="/countdown" className="text-white/60 hover:text-eid-gold transition-colors">Countdown</Link></li>
              <li><Link to="/recipes" className="text-white/60 hover:text-eid-gold transition-colors">Recipes</Link></li>
              <li><Link to="/charity" className="text-white/60 hover:text-eid-gold transition-colors">Charity</Link></li>
              <li><Link to="/contact" className="text-white/60 hover:text-eid-gold transition-colors">Contact Us</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold text-white mb-6">Follow Us</h4>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-eid-gold hover:text-eid-blue transition-all">
                <Facebook size={20} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-eid-gold hover:text-eid-blue transition-all">
                <Twitter size={20} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-eid-gold hover:text-eid-blue transition-all">
                <Instagram size={20} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-eid-gold hover:text-eid-blue transition-all">
                <Youtube size={20} />
              </a>
            </div>
          </div>
        </div>
        
        <div className="relative py-8 flex flex-col items-center">
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-eid-gold/30 to-transparent"></div>
          <div className="flex items-center space-x-2 text-white/40 text-sm">
            <span>© {new Date().getFullYear()} EidVerse. Made with</span>
            <Heart size={14} className="text-red-500 fill-current" />
            <span>for the Ummah.</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
