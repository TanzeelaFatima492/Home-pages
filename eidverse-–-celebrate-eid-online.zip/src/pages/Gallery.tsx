import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Maximize2, ZoomIn, Heart } from 'lucide-react';

const images = [
  { id: 1, src: 'https://picsum.photos/seed/eid1/1200/800', title: 'Eid Prayer Gathering', category: 'Celebration' },
  { id: 2, src: 'https://picsum.photos/seed/eid2/1200/800', title: 'Traditional Eid Feast', category: 'Food' },
  { id: 3, src: 'https://picsum.photos/seed/eid3/1200/800', title: 'Beautiful Mosque at Night', category: 'Architecture' },
  { id: 4, src: 'https://picsum.photos/seed/eid4/1200/800', title: 'Children Celebrating', category: 'Joy' },
  { id: 5, src: 'https://picsum.photos/seed/eid5/1200/800', title: 'Henna Art (Mehndi)', category: 'Tradition' },
  { id: 6, src: 'https://picsum.photos/seed/eid6/1200/800', title: 'Eid Gifts and Sweets', category: 'Gifts' },
  { id: 7, src: 'https://picsum.photos/seed/eid7/1200/800', title: 'Illuminated Streets', category: 'Celebration' },
  { id: 8, src: 'https://picsum.photos/seed/eid8/1200/800', title: 'Family Reunion', category: 'Joy' },
  { id: 9, src: 'https://picsum.photos/seed/eid9/1200/800', title: 'Eid Moon Sighting', category: 'Tradition' },
];

export default function Gallery() {
  const [selectedImage, setSelectedImage] = useState<typeof images[0] | null>(null);
  const [filter, setFilter] = useState('All');

  const filteredImages = filter === 'All' 
    ? images 
    : images.filter(img => img.category === filter);

  const categories = ['All', ...new Set(images.map(img => img.category))];

  return (
    <div className="min-h-screen pt-32 pb-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-serif font-bold text-eid-gold mb-4">Eid Celebration Gallery</h1>
          <p className="text-white/60 max-w-2xl mx-auto">
            Capturing the beautiful moments, traditions, and joy of Eid celebrations from around the world.
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-6 py-2 rounded-xl text-sm font-medium transition-all ${
                filter === cat 
                  ? 'bg-eid-gold text-eid-blue shadow-lg' 
                  : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence mode="popLayout">
            {filteredImages.map((image) => (
              <motion.div
                key={image.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                whileHover={{ y: -5 }}
                className="relative aspect-[4/3] group cursor-pointer overflow-hidden rounded-2xl"
                onClick={() => setSelectedImage(image)}
              >
                <img 
                  src={image.src} 
                  alt={image.title} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-eid-blue/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center p-6 text-center">
                  <Maximize2 size={32} className="text-eid-gold mb-4 transform scale-50 group-hover:scale-100 transition-transform duration-300" />
                  <h3 className="text-lg font-bold text-white mb-2">{image.title}</h3>
                  <span className="text-xs font-medium text-eid-gold uppercase tracking-widest">{image.category}</span>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Lightbox */}
        <AnimatePresence>
          {selectedImage && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-12">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setSelectedImage(null)}
                className="absolute inset-0 bg-eid-blue/95 backdrop-blur-md"
              ></motion.div>
              
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="relative w-full max-w-6xl max-h-full flex flex-col items-center"
              >
                <button
                  onClick={() => setSelectedImage(null)}
                  className="absolute -top-12 right-0 p-2 text-white hover:text-eid-gold transition-colors"
                >
                  <X size={32} />
                </button>
                
                <div className="relative w-full h-full overflow-hidden rounded-2xl shadow-2xl border border-white/10">
                  <img 
                    src={selectedImage.src} 
                    alt={selectedImage.title} 
                    className="w-full h-full object-contain bg-black/40"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-black/80 to-transparent">
                    <h2 className="text-2xl font-serif font-bold text-white mb-2">{selectedImage.title}</h2>
                    <div className="flex items-center space-x-4">
                      <span className="text-eid-gold text-sm font-medium uppercase tracking-widest">{selectedImage.category}</span>
                      <div className="w-1 h-1 bg-white/30 rounded-full"></div>
                      <button className="flex items-center space-x-2 text-white/60 hover:text-red-500 transition-colors text-sm">
                        <Heart size={16} />
                        <span>Like</span>
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
