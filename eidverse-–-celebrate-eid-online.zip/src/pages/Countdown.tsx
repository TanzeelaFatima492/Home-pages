import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

export default function Countdown() {
  // Set Eid date - for demo purposes, let's set it to 3 days from now
  const [targetDate] = useState(() => {
    return new Date('2026-03-20T00:00:00');
  });

  const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());
  const [isEid, setIsEid] = useState(false);

  function calculateTimeLeft() {
    const difference = +targetDate - +new Date();
    let timeLeft = {
      days: 0,
      hours: 0,
      minutes: 0,
      seconds: 0,
    };

    if (difference > 0) {
      timeLeft = {
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60),
      };
    }

    return timeLeft;
  }

  useEffect(() => {
    const timer = setInterval(() => {
      const newTime = calculateTimeLeft();
      setTimeLeft(newTime);

      if (newTime.days === 0 && newTime.hours === 0 && newTime.minutes === 0 && newTime.seconds === 0) {
        setIsEid(true);
        triggerFireworks();
        clearInterval(timer);
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [targetDate]);

  const triggerFireworks = () => {
    const duration = 15 * 1000;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 };

    function randomInRange(min: number, max: number) {
      return Math.random() * (max - min) + min;
    }

    const interval: any = setInterval(function() {
      const timeLeft = animationEnd - Date.now();

      if (timeLeft <= 0) {
        return clearInterval(interval);
      }

      const particleCount = 50 * (timeLeft / duration);
      confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 } });
      confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 } });
    }, 250);
  };

  const TimeUnit = ({ value, label }: { value: number; label: string }) => (
    <div className="flex flex-col items-center">
      <div className="glass w-20 h-24 md:w-32 md:h-40 flex items-center justify-center mb-4 relative overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.span
            key={value}
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -20, opacity: 0 }}
            className="text-4xl md:text-6xl font-bold text-eid-gold"
          >
            {value.toString().padStart(2, '0')}
          </motion.span>
        </AnimatePresence>
        <div className="absolute inset-0 bg-gradient-to-t from-eid-gold/5 to-transparent pointer-events-none"></div>
      </div>
      <span className="text-xs md:text-sm font-medium uppercase tracking-widest text-white/60">{label}</span>
    </div>
  );

  return (
    <div className="min-h-screen pt-32 pb-20 px-4 flex flex-col items-center justify-center relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-eid-purple/20 rounded-full blur-[120px] pointer-events-none"></div>
      
      <div className="max-w-4xl w-full text-center z-10">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="mb-12"
        >
          <Link to="/" className="inline-flex items-center space-x-2 text-white/60 hover:text-eid-gold transition-colors mb-8">
            <ArrowLeft size={16} />
            <span>Back to Home</span>
          </Link>
          
          <h1 className="text-4xl md:text-5xl font-serif font-bold text-white mb-4">
            {isEid ? "Eid Mubarak!" : "Countdown to Eid"}
          </h1>
          <p className="text-lg text-white/60 max-w-lg mx-auto">
            {isEid 
              ? "The blessed day has arrived. May your Eid be filled with joy and prosperity." 
              : "Anticipating the joy and blessings of the upcoming Eid celebration."}
          </p>
        </motion.div>

        {!isEid ? (
          <div className="flex justify-center gap-4 md:gap-8 mb-16">
            <TimeUnit value={timeLeft.days} label="Days" />
            <TimeUnit value={timeLeft.hours} label="Hours" />
            <TimeUnit value={timeLeft.minutes} label="Minutes" />
            <TimeUnit value={timeLeft.seconds} label="Seconds" />
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass p-12 mb-16"
          >
            <Sparkles size={64} className="text-eid-gold mx-auto mb-6" />
            <h2 className="text-3xl font-serif font-bold text-eid-gold mb-4">It's Celebration Time!</h2>
            <p className="text-white/80 mb-8">The moon has been sighted. Let the festivities begin!</p>
            <button 
              onClick={triggerFireworks}
              className="px-8 py-3 bg-eid-gold text-eid-blue font-bold rounded-full hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] transition-all"
            >
              Celebrate Again
            </button>
          </motion.div>
        )}

        <div className="flex flex-col items-center">
          <p className="text-sm text-white/40 mb-4 italic">"May this Eid bring peace, happiness, and prosperity to everyone."</p>
          <div className="w-12 h-1 bg-eid-gold/20 rounded-full"></div>
        </div>
      </div>
    </div>
  );
}
