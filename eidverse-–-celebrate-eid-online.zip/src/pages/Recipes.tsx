import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Clock, Users, ChefHat } from 'lucide-react';

const recipes = [
  {
    id: 1,
    title: 'Sheer Khurma',
    image: 'https://picsum.photos/seed/sheer/800/600',
    time: '45 mins',
    servings: '6-8',
    ingredients: [
      '1 liter full cream milk',
      '1/2 cup vermicelli (seviyan)',
      '1/2 cup sugar',
      '1/4 cup chopped dates',
      '1/4 cup mixed nuts (almonds, pistachios, cashews)',
      '1/2 tsp cardamom powder',
      '1 tbsp ghee',
      'A few strands of saffron'
    ],
    steps: [
      'Heat ghee in a pan and roast the vermicelli until golden brown. Set aside.',
      'In a large heavy-bottomed pot, bring milk to a boil.',
      'Add chopped dates and simmer on low heat for 15-20 minutes until the milk thickens slightly.',
      'Add sugar, roasted vermicelli, and cardamom powder. Cook for another 10 minutes.',
      'In a separate small pan, roast the nuts in a little ghee and add them to the milk.',
      'Add saffron strands and simmer for 5 more minutes.',
      'Serve hot or chilled, garnished with more nuts.'
    ]
  },
  {
    id: 2,
    title: 'Mutton Biryani',
    image: 'https://picsum.photos/seed/biryani/800/600',
    time: '90 mins',
    servings: '4-6',
    ingredients: [
      '500g mutton, cut into pieces',
      '2 cups Basmati rice, soaked',
      '2 large onions, thinly sliced',
      '1 cup yogurt',
      '2 tbsp ginger-garlic paste',
      'Biryani masala (cloves, cardamom, cinnamon, bay leaf)',
      '1/2 cup fresh mint and coriander leaves',
      '1/4 cup ghee or oil'
    ],
    steps: [
      'Marinate mutton with yogurt, ginger-garlic paste, and spices for at least 2 hours.',
      'Fry onions until golden brown (birista). Set half aside for garnishing.',
      'Cook marinated mutton in a pressure cooker or heavy pot until tender.',
      'Parboil rice with whole spices until 70% cooked. Drain.',
      'Layer the mutton and rice in a heavy-bottomed pot. Top with fried onions, mint, and coriander.',
      'Seal the pot with dough or a tight lid and cook on very low heat (dum) for 20-30 minutes.',
      'Gently mix and serve with raita.'
    ]
  },
  {
    id: 3,
    title: 'Seekh Kebabs',
    image: 'https://picsum.photos/seed/kebab/800/600',
    time: '40 mins',
    servings: '4',
    ingredients: [
      '500g minced meat (lamb or beef)',
      '1 large onion, finely chopped and squeezed',
      '1 tbsp ginger-garlic paste',
      '2 green chilies, finely chopped',
      '1 tsp cumin powder',
      '1 tsp garam masala',
      '1/2 cup fresh coriander, chopped',
      'Salt to taste'
    ],
    steps: [
      'In a large bowl, mix minced meat with all ingredients. Knead well for 5-10 minutes.',
      'Refrigerate the mixture for at least 1 hour.',
      'Take a portion of the mixture and wrap it around a skewer, forming a long cylindrical shape.',
      'Grill over charcoal or in a preheated oven at 200°C for 15-20 minutes, turning occasionally.',
      'Brush with butter or oil during the last few minutes of cooking.',
      'Serve hot with mint chutney and onion rings.'
    ]
  },
  {
    id: 4,
    title: 'Shahi Kheer',
    image: 'https://picsum.photos/seed/kheer/800/600',
    time: '60 mins',
    servings: '6',
    ingredients: [
      '1 liter full cream milk',
      '1/4 cup Basmati rice, washed and soaked',
      '1/2 cup sugar',
      '1/4 tsp cardamom powder',
      '1/4 cup mixed nuts, sliced',
      '1 tsp rose water (optional)',
      'Silver leaf (vark) for garnishing'
    ],
    steps: [
      'Drain the soaked rice and grind it coarsely.',
      'Bring milk to a boil in a heavy pot.',
      'Add the ground rice and cook on low heat, stirring frequently to prevent sticking.',
      'Simmer until the rice is completely cooked and the milk has reduced and thickened.',
      'Add sugar and cardamom powder. Cook for another 5-10 minutes.',
      'Stir in half of the nuts and rose water.',
      'Garnish with remaining nuts and silver leaf. Serve chilled.'
    ]
  }
];

export default function Recipes() {
  const [selectedRecipe, setSelectedRecipe] = useState<typeof recipes[0] | null>(null);

  return (
    <div className="min-h-screen pt-32 pb-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-serif font-bold text-eid-gold mb-4">Eid Special Recipes</h1>
          <p className="text-white/60 max-w-2xl mx-auto">
            Traditional flavors and festive delights to make your Eid celebration truly special. 
            Explore our curated collection of must-have Eid dishes.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {recipes.map((recipe) => (
            <motion.div
              key={recipe.id}
              whileHover={{ y: -10 }}
              className="glass overflow-hidden flex flex-col h-full"
            >
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={recipe.image} 
                  alt={recipe.title} 
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-4 right-4 bg-eid-blue/80 backdrop-blur-md px-3 py-1 rounded-full text-xs font-medium text-eid-gold">
                  {recipe.time}
                </div>
              </div>
              
              <div className="p-6 flex-grow flex flex-col">
                <h3 className="text-xl font-bold text-white mb-2">{recipe.title}</h3>
                <p className="text-white/60 text-sm mb-6 line-clamp-2">
                  A classic Eid delicacy made with {recipe.ingredients[0].toLowerCase()} and traditional spices.
                </p>
                
                <div className="mt-auto">
                  <button
                    onClick={() => setSelectedRecipe(recipe)}
                    className="w-full py-3 bg-white/5 border border-white/10 rounded-xl text-sm font-medium hover:bg-eid-gold hover:text-eid-blue hover:border-eid-gold transition-all"
                  >
                    View Recipe
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Recipe Modal */}
        <AnimatePresence>
          {selectedRecipe && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setSelectedRecipe(null)}
                className="absolute inset-0 bg-eid-blue/90 backdrop-blur-sm"
              ></motion.div>
              
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="relative glass w-full max-w-4xl max-h-[90vh] overflow-y-auto"
              >
                <button
                  onClick={() => setSelectedRecipe(null)}
                  className="absolute top-4 right-4 p-2 bg-white/10 rounded-full hover:bg-white/20 transition-colors z-10"
                >
                  <X size={20} />
                </button>
                
                <div className="grid grid-cols-1 md:grid-cols-2">
                  <div className="h-64 md:h-full">
                    <img 
                      src={selectedRecipe.image} 
                      alt={selectedRecipe.title} 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  
                  <div className="p-8 md:p-12">
                    <h2 className="text-3xl font-serif font-bold text-eid-gold mb-6">{selectedRecipe.title}</h2>
                    
                    <div className="flex items-center space-x-6 mb-8 text-white/60 text-sm">
                      <div className="flex items-center space-x-2">
                        <Clock size={16} className="text-eid-gold" />
                        <span>{selectedRecipe.time}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Users size={16} className="text-eid-gold" />
                        <span>{selectedRecipe.servings} Servings</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <ChefHat size={16} className="text-eid-gold" />
                        <span>Intermediate</span>
                      </div>
                    </div>
                    
                    <div className="mb-8">
                      <h4 className="text-lg font-bold text-white mb-4 flex items-center space-x-2">
                        <span className="w-1.5 h-1.5 bg-eid-gold rounded-full"></span>
                        <span>Ingredients</span>
                      </h4>
                      <ul className="grid grid-cols-1 gap-2">
                        {selectedRecipe.ingredients.map((ing, i) => (
                          <li key={i} className="text-white/70 text-sm flex items-start space-x-2">
                            <span className="text-eid-gold mt-1">•</span>
                            <span>{ing}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    <div>
                      <h4 className="text-lg font-bold text-white mb-4 flex items-center space-x-2">
                        <span className="w-1.5 h-1.5 bg-eid-gold rounded-full"></span>
                        <span>Instructions</span>
                      </h4>
                      <div className="space-y-4">
                        {selectedRecipe.steps.map((step, i) => (
                          <div key={i} className="flex space-x-4">
                            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-eid-gold/20 text-eid-gold text-xs flex items-center justify-center font-bold">
                              {i + 1}
                            </span>
                            <p className="text-white/70 text-sm leading-relaxed">{step}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
