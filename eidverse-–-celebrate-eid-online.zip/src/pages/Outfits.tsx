import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ShoppingBag, Star, Heart } from 'lucide-react';

const outfits = [
  {
    id: 1,
    category: 'Men',
    title: 'Royal Blue Sherwani',
    image: 'https://picsum.photos/seed/men-eid/800/1000',
    price: '$120',
    description: 'Exquisite hand-embroidered royal blue sherwani with gold detailing. Perfect for the main Eid prayer and family gatherings.',
    features: ['Premium Silk Blend', 'Hand Embroidery', 'Includes Trousers', 'Slim Fit']
  },
  {
    id: 2,
    category: 'Women',
    title: 'Emerald Anarkali Suit',
    image: 'https://picsum.photos/seed/women-eid/800/1000',
    price: '$150',
    description: 'Stunning emerald green Anarkali suit with intricate zari work and a matching heavy dupatta. Elegance redefined for your festive look.',
    features: ['Georgette Fabric', 'Zari & Stone Work', 'Full Flare', 'Designer Dupatta']
  },
  {
    id: 3,
    category: 'Kids',
    title: 'Mini Prince Kurta Set',
    image: 'https://picsum.photos/seed/kids-eid/800/1000',
    price: '$45',
    description: 'Adorable white and gold kurta set for boys. Comfortable, stylish, and perfect for a long day of celebrations.',
    features: ['Soft Cotton', 'Gold Piping', 'Easy Wear', 'Breathable']
  },
  {
    id: 4,
    category: 'Women',
    title: 'Pastel Pink Abaya',
    image: 'https://picsum.photos/seed/abaya-eid/800/1000',
    price: '$85',
    description: 'Modern pastel pink abaya with floral lace accents. A perfect blend of modesty and contemporary fashion.',
    features: ['Nida Fabric', 'Lace Detailing', 'Matching Hijab', 'Loose Fit']
  },
  {
    id: 5,
    category: 'Men',
    title: 'Classic White Kurta',
    image: 'https://picsum.photos/seed/kurta-eid/800/1000',
    price: '$60',
    description: 'A timeless classic white cotton kurta with subtle self-embroidery. Versatile and elegant for any Eid occasion.',
    features: ['100% Cotton', 'Self Pattern', 'Mandarin Collar', 'Regular Fit']
  },
  {
    id: 6,
    category: 'Kids',
    title: 'Little Fairy Lehenga',
    image: 'https://picsum.photos/seed/girl-eid/800/1000',
    price: '$55',
    description: 'Vibrant yellow and pink lehenga choli for girls. Lightweight and festive, making your little one shine.',
    features: ['Silk & Net', 'Sequin Work', 'Elastic Waist', 'Includes Dupatta']
  }
];

export default function Outfits() {
  const [filter, setFilter] = useState('All');
  const [selectedOutfit, setSelectedOutfit] = useState<typeof outfits[0] | null>(null);

  const filteredOutfits = filter === 'All' 
    ? outfits 
    : outfits.filter(o => o.category === filter);

  return (
    <div className="min-h-screen pt-32 pb-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-serif font-bold text-eid-gold mb-4">Eid Fashion Gallery</h1>
          <p className="text-white/60 max-w-2xl mx-auto">
            Discover the perfect look for your Eid celebrations. From traditional classics to modern trends, 
            find inspiration for the whole family.
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex justify-center mb-12">
          <div className="glass p-1 flex space-x-1">
            {['All', 'Men', 'Women', 'Kids'].map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`px-6 py-2 rounded-xl text-sm font-medium transition-all ${
                  filter === cat 
                    ? 'bg-eid-gold text-eid-blue shadow-lg' 
                    : 'text-white/60 hover:text-white hover:bg-white/5'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Outfits Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          <AnimatePresence mode="popLayout">
            {filteredOutfits.map((outfit) => (
              <motion.div
                key={outfit.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                whileHover={{ y: -10 }}
                className="glass group overflow-hidden"
              >
                <div className="relative aspect-[3/4] overflow-hidden">
                  <img 
                    src={outfit.image} 
                    alt={outfit.title} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-eid-blue/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
                    <button
                      onClick={() => setSelectedOutfit(outfit)}
                      className="w-full py-3 bg-eid-gold text-eid-blue font-bold rounded-xl flex items-center justify-center space-x-2 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300"
                    >
                      <ShoppingBag size={18} />
                      <span>View Details</span>
                    </button>
                  </div>
                  <div className="absolute top-4 left-4 bg-eid-blue/60 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-bold text-eid-gold uppercase tracking-widest">
                    {outfit.category}
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-lg font-bold text-white">{outfit.title}</h3>
                    <span className="text-eid-gold font-bold">{outfit.price}</span>
                  </div>
                  <div className="flex items-center space-x-1 text-eid-accent">
                    {[...Array(5)].map((_, i) => <Star key={i} size={12} fill="currentColor" />)}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Detail Modal */}
        <AnimatePresence>
          {selectedOutfit && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setSelectedOutfit(null)}
                className="absolute inset-0 bg-eid-blue/90 backdrop-blur-sm"
              ></motion.div>
              
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="relative glass w-full max-w-4xl overflow-hidden"
              >
                <button
                  onClick={() => setSelectedOutfit(null)}
                  className="absolute top-4 right-4 p-2 bg-white/10 rounded-full hover:bg-white/20 transition-colors z-10"
                >
                  <X size={20} />
                </button>
                
                <div className="grid grid-cols-1 md:grid-cols-2">
                  <div className="h-80 md:h-[600px]">
                    <img 
                      src={selectedOutfit.image} 
                      alt={selectedOutfit.title} 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  
                  <div className="p-8 md:p-12 flex flex-col">
                    <div className="mb-2">
                      <span className="text-xs font-bold text-eid-gold uppercase tracking-widest">{selectedOutfit.category} Collection</span>
                    </div>
                    <h2 className="text-3xl font-serif font-bold text-white mb-4">{selectedOutfit.title}</h2>
                    <div className="text-2xl font-bold text-eid-gold mb-6">{selectedOutfit.price}</div>
                    
                    <p className="text-white/70 leading-relaxed mb-8">
                      {selectedOutfit.description}
                    </p>
                    
                    <div className="mb-8">
                      <h4 className="text-sm font-bold text-white mb-4 uppercase tracking-widest">Key Features</h4>
                      <ul className="grid grid-cols-2 gap-3">
                        {selectedOutfit.features.map((f, i) => (
                          <li key={i} className="flex items-center space-x-2 text-white/60 text-sm">
                            <Heart size={14} className="text-eid-gold" />
                            <span>{f}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    <div className="mt-auto space-y-4">
                      <button className="w-full py-4 bg-eid-gold text-eid-blue font-bold rounded-xl hover:shadow-[0_0_20px_rgba(212,175,55,0.3)] transition-all">
                        Add to Wishlist
                      </button>
                      <p className="text-[10px] text-white/40 text-center italic">
                        * This is a showcase item. Actual products may vary.
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
