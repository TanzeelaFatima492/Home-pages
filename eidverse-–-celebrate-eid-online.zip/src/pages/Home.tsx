import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowRight, Star, Moon } from 'lucide-react';
import Lantern from '../components/Lantern';

export default function Home() {
  return (
    <div className="relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        <Lantern className="absolute top-20 left-[10%] opacity-40 scale-75" />
        <Lantern className="absolute top-40 right-[15%] opacity-30 scale-110" />
        <Lantern className="absolute bottom-40 left-[20%] opacity-20 scale-90" />
        <Lantern className="absolute top-1/2 right-[5%] opacity-25" />
        
        {/* Stars */}
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
            }}
            animate={{
              opacity: [0.2, 1, 0.2],
              scale: [1, 1.5, 1],
            }}
            transition={{
              duration: 2 + Math.random() * 3,
              repeat: Infinity,
              delay: Math.random() * 5,
            }}
          />
        ))}
      </div>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-20 pb-12 px-4">
        <div className="max-w-4xl mx-auto text-center z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="flex justify-center mb-6">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                className="relative"
              >
                <Moon size={64} className="text-eid-gold fill-eid-gold/20" />
                <Star size={24} className="absolute -top-2 -right-2 text-eid-accent animate-pulse" />
              </motion.div>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-serif font-bold mb-6 bg-gradient-to-r from-eid-gold via-eid-accent to-eid-gold bg-clip-text text-transparent">
              EidVerse
            </h1>
            <p className="text-xl md:text-2xl text-white/80 font-arabic mb-4">
              عيد مبارك
            </p>
            <h2 className="text-2xl md:text-3xl font-light text-white/90 mb-8 tracking-wide">
              Celebrate Eid Online
            </h2>
            <p className="text-lg text-white/60 mb-10 max-w-2xl mx-auto leading-relaxed">
              Experience the magic of Eid with our digital celebration hub. 
              Count down the moments, share beautiful greetings, discover delicious recipes, 
              and spread the joy of giving.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/countdown">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 bg-eid-gold text-eid-blue font-bold rounded-full flex items-center space-x-2 shadow-[0_0_20px_rgba(212,175,55,0.4)] hover:shadow-[0_0_30px_rgba(212,175,55,0.6)] transition-all"
                >
                  <span>Explore Eid</span>
                  <ArrowRight size={20} />
                </motion.button>
              </Link>
              <Link to="/greetings">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 bg-white/10 backdrop-blur-md text-white font-bold rounded-full border border-white/20 hover:bg-white/20 transition-all"
                >
                  Send Greetings
                </motion.button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 px-4 bg-eid-blue/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-eid-gold mb-4">Everything You Need for Eid</h2>
            <div className="w-24 h-1 bg-eid-gold/30 mx-auto rounded-full"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { title: 'Live Countdown', desc: 'Watch the moments tick away as we approach the blessed day of Eid.', link: '/countdown', icon: '⏰' },
              { title: 'Greeting Cards', desc: 'Create and share personalized Eid cards with your friends and family.', link: '/greetings', icon: '💌' },
              { title: 'Eid Recipes', desc: 'Discover traditional and modern recipes to make your Eid feast unforgettable.', link: '/recipes', icon: '🍲' },
              { title: 'Charity & Zakat', desc: 'Learn about the importance of giving and find ways to help those in need.', link: '/charity', icon: '🌙' },
              { title: 'Eid Outfits', desc: 'Get inspired by the latest trends in Eid fashion for the whole family.', link: '/outfits', icon: '👗' },
              { title: 'Inspirational Wishes', desc: 'Find the perfect words to express your joy and blessings.', link: '/wishes', icon: '✨' },
            ].map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="glass p-8 hover:bg-white/15 transition-all group"
              >
                <div className="text-4xl mb-6 group-hover:scale-110 transition-transform">{feature.icon}</div>
                <h3 className="text-xl font-bold text-white mb-4">{feature.title}</h3>
                <p className="text-white/60 mb-6 leading-relaxed">{feature.desc}</p>
                <Link to={feature.link} className="text-eid-gold font-medium flex items-center space-x-2 hover:translate-x-2 transition-transform">
                  <span>Learn more</span>
                  <ArrowRight size={16} />
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
