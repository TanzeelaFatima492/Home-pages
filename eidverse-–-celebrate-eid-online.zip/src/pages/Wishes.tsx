import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Copy, Check, Quote, Send } from 'lucide-react';

const wishes = [
  {
    id: 1,
    text: "May the magic of this Eid bring lots of happiness in your life and may you celebrate it with all your close friends & may it fill your heart with wonders. Eid Mubarak!",
    category: "General"
  },
  {
    id: 2,
    text: "May Allah's blessings be with you today, tomorrow and always. Eid Mubarak to you and your family!",
    category: "Religious"
  },
  {
    id: 3,
    text: "Sending you warm wishes on Eid and wishing that it brings your way ever joys and happiness. Remember me in your prayers.",
    category: "Friends"
  },
  {
    id: 4,
    text: "May the divine blessings of Allah bring you hope, faith, and joy on Eid-ul-Fitr and forever. Happy Eid!",
    category: "Religious"
  },
  {
    id: 5,
    text: "E-Embrace with open heart, I-Inculcate good deeds, D-Distribute & share Allah's bounties with the underprivileged. Eid Mubarak!",
    category: "Inspirational"
  },
  {
    id: 6,
    text: "May this Eid be the beginning of another successful year in your life. Eid Mubarak to you and your lovely family!",
    category: "Family"
  },
  {
    id: 7,
    text: "Your presence in my life is a blessing. Wishing you a very Happy Eid filled with love and laughter.",
    category: "Love"
  },
  {
    id: 8,
    text: "On this holy occasion, wishing you a day filled with laughter and happy moments. Eid Mubarak from my heart to yours!",
    category: "General"
  }
];

export default function Wishes() {
  const [copiedId, setCopiedId] = useState<number | null>(null);
  const [filter, setFilter] = useState('All');

  const handleCopy = (text: string, id: number) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const filteredWishes = filter === 'All' 
    ? wishes 
    : wishes.filter(w => w.category === filter);

  const categories = ['All', ...new Set(wishes.map(w => w.category))];

  return (
    <div className="min-h-screen pt-32 pb-20 px-4">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-serif font-bold text-eid-gold mb-4">Inspirational Eid Wishes</h1>
          <p className="text-white/60 max-w-2xl mx-auto">
            Find the perfect words to share your joy and blessings with friends, family, and loved ones. 
            Copy and send these heartfelt messages.
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-5 py-2 rounded-full text-xs font-bold uppercase tracking-widest transition-all ${
                filter === cat 
                  ? 'bg-eid-gold text-eid-blue shadow-lg' 
                  : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Wishes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <AnimatePresence mode="popLayout">
            {filteredWishes.map((wish) => (
              <motion.div
                key={wish.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="glass p-8 flex flex-col relative group"
              >
                <Quote size={40} className="absolute top-4 right-4 text-eid-gold/10 group-hover:text-eid-gold/20 transition-colors" />
                
                <div className="mb-4">
                  <span className="text-[10px] font-bold text-eid-gold uppercase tracking-widest bg-eid-gold/10 px-2 py-1 rounded">
                    {wish.category}
                  </span>
                </div>
                
                <p className="text-white/80 leading-relaxed mb-8 flex-grow italic">
                  "{wish.text}"
                </p>
                
                <div className="flex items-center justify-between pt-6 border-t border-white/5">
                  <button
                    onClick={() => handleCopy(wish.text, wish.id)}
                    className={`flex items-center space-x-2 text-sm font-medium transition-colors ${
                      copiedId === wish.id ? 'text-green-500' : 'text-eid-gold hover:text-eid-accent'
                    }`}
                  >
                    {copiedId === wish.id ? (
                      <>
                        <Check size={16} />
                        <span>Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy size={16} />
                        <span>Copy Message</span>
                      </>
                    )}
                  </button>
                  
                  <button className="p-2 bg-white/5 rounded-full hover:bg-white/10 transition-colors text-white/60 hover:text-eid-gold">
                    <Send size={16} />
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        <div className="mt-16 text-center">
          <div className="glass inline-block px-8 py-6 max-w-lg">
            <p className="text-white/60 text-sm italic">
              "The best of all gifts around any Eid is the presence of a happy family all wrapped up in each other."
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
