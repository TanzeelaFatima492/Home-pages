import React, { useState, FormEvent } from 'react';
import { motion } from 'motion/react';
import { Heart, Gift, ShieldCheck, Info, CheckCircle2 } from 'lucide-react';

export default function Charity() {
  const [amount, setAmount] = useState('');
  const [donated, setDonated] = useState(false);

  const handleDonate = (e: FormEvent) => {
    e.preventDefault();
    if (amount) {
      setDonated(true);
      setTimeout(() => setDonated(false), 5000);
      setAmount('');
    }
  };

  return (
    <div className="min-h-screen pt-32 pb-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-serif font-bold text-eid-gold mb-4">Charity & Zakat</h1>
          <p className="text-white/60 max-w-2xl mx-auto">
            Eid is a time of joy, but also a time for reflection and giving. 
            Learn about the importance of Zakat and Sadaqah in our faith.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Information Section */}
          <div className="lg:col-span-2 space-y-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="glass p-8"
            >
              <div className="flex items-center space-x-4 mb-6">
                <div className="w-12 h-12 rounded-full bg-eid-gold/20 flex items-center justify-center text-eid-gold">
                  <Gift size={24} />
                </div>
                <h2 className="text-2xl font-serif font-bold">Understanding Zakat</h2>
              </div>
              <p className="text-white/70 leading-relaxed mb-6">
                Zakat is one of the Five Pillars of Islam, representing a mandatory form of almsgiving 
                for those who meet the necessary criteria of wealth. It is not just a charitable contribution 
                but a religious obligation to purify one's wealth and provide for the less fortunate.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                  <h4 className="font-bold text-eid-gold mb-2">Who Receives Zakat?</h4>
                  <p className="text-sm text-white/60">The poor, the needy, those in debt, and those working to spread the message of Islam.</p>
                </div>
                <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                  <h4 className="font-bold text-eid-gold mb-2">How Much is Zakat?</h4>
                  <p className="text-sm text-white/60">Typically 2.5% of a Muslim's total savings and wealth above a minimum amount (Nisab).</p>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="glass p-8"
            >
              <div className="flex items-center space-x-4 mb-6">
                <div className="w-12 h-12 rounded-full bg-eid-purple/20 flex items-center justify-center text-eid-purple">
                  <Heart size={24} />
                </div>
                <h2 className="text-2xl font-serif font-bold">The Spirit of Sadaqah</h2>
              </div>
              <p className="text-white/70 leading-relaxed mb-6">
                Unlike Zakat, Sadaqah is a voluntary act of charity given out of compassion, love, 
                friendship, or religious duty. It can be anything from a monetary donation to a simple 
                smile or a helping hand.
              </p>
              <ul className="space-y-4">
                {[
                  'Sadaqah Jariyah: Ongoing charity that continues to benefit others after one\'s passing.',
                  'Helping a neighbor or a stranger in need.',
                  'Planting a tree or providing water to a thirsty animal.',
                  'Sharing knowledge or teaching someone a skill.'
                ].map((item, i) => (
                  <li key={i} className="flex items-start space-x-3 text-white/60 text-sm">
                    <ShieldCheck size={18} className="text-eid-gold flex-shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          </div>

          {/* Donation Form */}
          <div className="lg:col-span-1">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="glass p-8 sticky top-32"
            >
              <h3 className="text-xl font-bold mb-6 text-center">Make a Difference</h3>
              
              {donated ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center py-12"
                >
                  <div className="w-20 h-20 bg-green-500/20 text-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
                    <CheckCircle2 size={40} />
                  </div>
                  <h4 className="text-2xl font-bold text-white mb-2">Thank You!</h4>
                  <p className="text-white/60">Your dummy donation has been received. May you be rewarded for your generosity.</p>
                </motion.div>
              ) : (
                <form onSubmit={handleDonate} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-white/60 mb-2">Select Amount ($)</label>
                    <div className="grid grid-cols-3 gap-3 mb-4">
                      {['10', '50', '100'].map((val) => (
                        <button
                          key={val}
                          type="button"
                          onClick={() => setAmount(val)}
                          className={`py-2 rounded-lg border transition-all ${
                            amount === val 
                              ? 'bg-eid-gold border-eid-gold text-eid-blue font-bold' 
                              : 'bg-white/5 border-white/10 text-white hover:border-white/30'
                          }`}
                        >
                          ${val}
                        </button>
                      ))}
                    </div>
                    <input
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="Custom Amount"
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-eid-gold transition-colors"
                    />
                  </div>
                  
                  <div className="bg-eid-gold/10 p-4 rounded-xl border border-eid-gold/20 flex items-start space-x-3">
                    <Info size={20} className="text-eid-gold flex-shrink-0 mt-0.5" />
                    <p className="text-xs text-white/70 leading-relaxed">
                      This is a demonstration form. No real transactions will be processed. 
                      Please donate to registered charities in your local area.
                    </p>
                  </div>
                  
                  <button
                    type="submit"
                    disabled={!amount}
                    className="w-full py-4 bg-eid-gold text-eid-blue font-bold rounded-xl shadow-[0_0_20px_rgba(212,175,55,0.3)] hover:shadow-[0_0_30px_rgba(212,175,55,0.5)] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Donate Now
                  </button>
                </form>
              )}
              
              <div className="mt-8 pt-8 border-t border-white/10 text-center">
                <p className="text-xs text-white/40 uppercase tracking-widest mb-4">Trusted Partners</p>
                <div className="flex justify-center space-x-6 opacity-30 grayscale">
                  <div className="w-8 h-8 bg-white rounded-full"></div>
                  <div className="w-8 h-8 bg-white rounded-full"></div>
                  <div className="w-8 h-8 bg-white rounded-full"></div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
