import { useState, useRef } from 'react';
import { motion } from 'motion/react';
import { Download, Share2, RefreshCw, Send, Facebook, Twitter, MessageCircle } from 'lucide-react';
import { toPng } from 'html-to-image';

export default function GreetingGenerator() {
  const [name, setName] = useState('');
  const [generated, setGenerated] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  const handleGenerate = () => {
    if (name.trim()) {
      setGenerated(true);
    }
  };

  const handleDownload = async () => {
    if (cardRef.current === null) return;
    
    try {
      const dataUrl = await toPng(cardRef.current, { cacheBust: true });
      const link = document.createElement('a');
      link.download = `eid-greeting-${name.toLowerCase().replace(/\s+/g, '-')}.png`;
      link.href = dataUrl;
      link.click();
    } catch (err) {
      console.error('Error generating image:', err);
    }
  };

  const handleShare = (platform: string) => {
    const text = `Eid Mubarak! Check out this personalized greeting for ${name}.`;
    const url = window.location.href;
    
    let shareUrl = '';
    switch (platform) {
      case 'facebook':
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
        break;
      case 'twitter':
        shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`;
        break;
      case 'whatsapp':
        shareUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(text + ' ' + url)}`;
        break;
    }
    
    if (shareUrl) window.open(shareUrl, '_blank');
  };

  return (
    <div className="min-h-screen pt-32 pb-20 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-serif font-bold text-eid-gold mb-4">Greeting Generator</h1>
          <p className="text-white/60">Create a personalized Eid greeting card for your loved ones.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* Input Section */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="glass p-8"
          >
            <h2 className="text-xl font-bold mb-6">Customize Your Card</h2>
            <div className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-white/60 mb-2">Recipient Name</label>
                <input
                  type="text"
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter name here..."
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-eid-gold transition-colors"
                />
              </div>
              
              <button
                onClick={handleGenerate}
                disabled={!name.trim()}
                className="w-full py-4 bg-eid-gold text-eid-blue font-bold rounded-xl flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-[0_0_20px_rgba(212,175,55,0.3)] transition-all"
              >
                <RefreshCw size={20} className={generated ? "animate-spin-slow" : ""} />
                <span>{generated ? "Regenerate Card" : "Generate Card"}</span>
              </button>
            </div>

            {generated && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-8 pt-8 border-t border-white/10"
              >
                <h3 className="text-sm font-medium text-white/60 mb-4 uppercase tracking-widest">Share with others</h3>
                <div className="flex gap-4">
                  <button onClick={() => handleShare('whatsapp')} className="flex-1 py-3 bg-green-600/20 text-green-500 rounded-xl flex items-center justify-center hover:bg-green-600/30 transition-all">
                    <MessageCircle size={20} />
                  </button>
                  <button onClick={() => handleShare('facebook')} className="flex-1 py-3 bg-blue-600/20 text-blue-500 rounded-xl flex items-center justify-center hover:bg-blue-600/30 transition-all">
                    <Facebook size={20} />
                  </button>
                  <button onClick={() => handleShare('twitter')} className="flex-1 py-3 bg-sky-500/20 text-sky-400 rounded-xl flex items-center justify-center hover:bg-sky-500/30 transition-all">
                    <Twitter size={20} />
                  </button>
                </div>
                <button
                  onClick={handleDownload}
                  className="w-full mt-4 py-3 bg-white/10 text-white rounded-xl flex items-center justify-center space-x-2 hover:bg-white/20 transition-all"
                >
                  <Download size={20} />
                  <span>Download Image</span>
                </button>
              </motion.div>
            )}
          </motion.div>

          {/* Preview Section */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex flex-col items-center"
          >
            <div 
              ref={cardRef}
              className="relative w-full aspect-[4/5] max-w-[400px] bg-eid-blue rounded-2xl overflow-hidden shadow-2xl border-4 border-eid-gold/30"
            >
              {/* Card Background Pattern */}
              <div className="absolute inset-0 opacity-20 pointer-events-none">
                <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-eid-gold/20 via-transparent to-transparent"></div>
                <div className="grid grid-cols-8 gap-4 p-4">
                  {[...Array(32)].map((_, i) => (
                    <div key={i} className="w-1 h-1 bg-eid-gold rounded-full opacity-30"></div>
                  ))}
                </div>
              </div>

              {/* Card Content */}
              <div className="relative h-full flex flex-col items-center justify-center p-8 text-center">
                <motion.div
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 4, repeat: Infinity }}
                  className="mb-8"
                >
                  <div className="text-6xl mb-4">🌙</div>
                </motion.div>
                
                <h2 className="text-4xl font-serif font-bold text-eid-gold mb-2">Eid Mubarak</h2>
                <div className="w-16 h-0.5 bg-eid-gold/50 mb-8"></div>
                
                <p className="text-white/60 text-sm italic mb-6">"Wishing you and your family a blessed Eid filled with joy, peace, and prosperity."</p>
                
                {generated && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="mt-4"
                  >
                    <p className="text-white/40 text-xs uppercase tracking-[0.3em] mb-2">Specially for</p>
                    <p className="text-3xl font-serif font-bold text-white tracking-wide">{name}</p>
                  </motion.div>
                )}

                <div className="absolute bottom-8 left-0 right-0 text-[10px] text-eid-gold/40 uppercase tracking-[0.5em]">
                  Created via EidVerse
                </div>
              </div>
              
              {/* Decorative Corners */}
              <div className="absolute top-4 left-4 w-8 h-8 border-t-2 border-l-2 border-eid-gold/30 rounded-tl-lg"></div>
              <div className="absolute top-4 right-4 w-8 h-8 border-t-2 border-r-2 border-eid-gold/30 rounded-tr-lg"></div>
              <div className="absolute bottom-4 left-4 w-8 h-8 border-b-2 border-l-2 border-eid-gold/30 rounded-bl-lg"></div>
              <div className="absolute bottom-4 right-4 w-8 h-8 border-b-2 border-r-2 border-eid-gold/30 rounded-br-lg"></div>
            </div>
            
            {!generated && (
              <p className="mt-6 text-white/40 text-sm italic">Enter a name to see the preview</p>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}
