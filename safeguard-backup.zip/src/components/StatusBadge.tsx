import { motion } from 'motion/react';
import { cn } from '@/src/lib/utils';

interface StatusBadgeProps {
  status: 'online' | 'warning' | 'error';
  label: string;
}

export function StatusBadge({ status, label }: StatusBadgeProps) {
  const colors = {
    online: 'bg-emerald-500',
    warning: 'bg-amber-500',
    error: 'bg-rose-500',
  };

  return (
    <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-50 border border-slate-100">
      <motion.div
        animate={{ scale: [1, 1.2, 1] }}
        transition={{ duration: 2, repeat: Infinity }}
        className={cn("w-2 h-2 rounded-full", colors[status])}
      />
      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">{label}</span>
    </div>
  );
}
