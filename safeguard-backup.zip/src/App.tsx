import { 
  ShieldCheck, 
  CloudUpload, 
  Database, 
  RefreshCcw, 
  Activity, 
  Lock, 
  HardDrive, 
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  History
} from 'lucide-react';
import { motion } from 'motion/react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { FeatureCard } from './components/FeatureCard';
import { StatusBadge } from './components/StatusBadge';

const data = [
  { name: 'Mon', usage: 45 },
  { name: 'Tue', usage: 52 },
  { name: 'Wed', usage: 48 },
  { name: 'Thu', usage: 61 },
  { name: 'Fri', usage: 55 },
  { name: 'Sat', usage: 67 },
  { name: 'Sun', usage: 72 },
];

export default function App() {
  return (
    <div className="min-h-screen bg-slate-50 selection:bg-emerald-100 selection:text-emerald-900">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-bottom border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white">
                <ShieldCheck size={20} />
              </div>
              <span className="text-xl font-bold tracking-tight text-slate-900">SafeGuard</span>
            </div>
            <div className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-sm font-medium text-slate-600 hover:text-emerald-600 transition-colors">Features</a>
              <a href="#dashboard" className="text-sm font-medium text-slate-600 hover:text-emerald-600 transition-colors">Live Status</a>
              <button className="px-4 py-2 bg-slate-900 text-white text-sm font-semibold rounded-lg hover:bg-slate-800 transition-colors">
                Get Started
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main>
        {/* Hero Section */}
        <section className="relative pt-20 pb-32 overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="text-center max-w-3xl mx-auto">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-bold uppercase tracking-wider mb-6"
              >
                <Activity size={14} />
                Real-time Protection Active
              </motion.div>
              <motion.h1 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="text-5xl md:text-6xl font-bold text-slate-900 tracking-tight mb-6 leading-[1.1]"
              >
                Business Data Protection <span className="text-emerald-600">Simplified.</span>
              </motion.h1>
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-lg text-slate-600 mb-10 leading-relaxed"
              >
                We help businesses prevent data loss through automated daily backups, 
                secure offsite storage, and regular recovery testing.
              </motion.p>
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="flex flex-col sm:flex-row items-center justify-center gap-4"
              >
                <button className="w-full sm:w-auto px-8 py-4 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-200 flex items-center justify-center gap-2 group">
                  Start Free Trial
                  <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
                </button>
                <button className="w-full sm:w-auto px-8 py-4 bg-white text-slate-700 font-bold rounded-xl border border-slate-200 hover:bg-slate-50 transition-all">
                  Book a Demo
                </button>
              </motion.div>
            </div>
          </div>
          
          {/* Background Decorative Elements */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full -z-10 pointer-events-none opacity-20">
            <div className="absolute top-0 left-1/4 w-96 h-96 bg-emerald-400 rounded-full blur-[120px]" />
            <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-blue-400 rounded-full blur-[120px]" />
          </div>
        </section>

        {/* Features Grid */}
        <section id="features" className="py-24 bg-white border-y border-slate-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-16">
              <h2 className="text-3xl font-bold text-slate-900 mb-4">How we prevent data loss</h2>
              <p className="text-slate-500 max-w-2xl">Our comprehensive approach ensures your business remains resilient against any data disaster.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <FeatureCard 
                icon={CloudUpload}
                title="Automated Daily Backups"
                description="Set it and forget it. We handle your daily data snapshots automatically without interrupting your workflow."
                delay={0.1}
              />
              <FeatureCard 
                icon={Lock}
                title="Secure Offsite Storage"
                description="Your data is encrypted and stored in geographically redundant data centers for maximum security."
                delay={0.2}
              />
              <FeatureCard 
                icon={RefreshCcw}
                title="Regular Recovery Testing"
                description="A backup is only as good as its recovery. We perform automated tests to ensure your data is always restorable."
                delay={0.3}
              />
              <FeatureCard 
                icon={Database}
                title="Quick Restoration"
                description="Minimize downtime with our high-speed restoration process. Get back to business in minutes, not days."
                delay={0.4}
              />
            </div>
          </div>
        </section>

        {/* Live Dashboard Preview */}
        <section id="dashboard" className="py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl overflow-hidden">
              <div className="p-8 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <h2 className="text-2xl font-bold text-slate-900">System Overview</h2>
                  <p className="text-slate-500 text-sm">Live status of your backup infrastructure</p>
                </div>
                <div className="flex items-center gap-3">
                  <StatusBadge status="online" label="Cloud Sync" />
                  <StatusBadge status="online" label="Local Agent" />
                  <StatusBadge status="online" label="Encryption" />
                </div>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-3">
                {/* Left Column: Stats */}
                <div className="p-8 border-r border-slate-100 space-y-8">
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2 block">Storage Usage</label>
                    <div className="flex items-end gap-2">
                      <span className="text-4xl font-bold text-slate-900">2.4</span>
                      <span className="text-slate-400 font-medium mb-1">TB</span>
                    </div>
                    <div className="mt-4 w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div className="bg-emerald-500 h-full w-[72%]" />
                    </div>
                    <p className="mt-2 text-xs text-slate-500">72% of 4TB plan used</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
                      <div className="text-emerald-600 mb-2"><CheckCircle2 size={20} /></div>
                      <div className="text-xl font-bold text-slate-900">1,248</div>
                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">Backups Completed</div>
                    </div>
                    <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
                      <div className="text-blue-600 mb-2"><History size={20} /></div>
                      <div className="text-xl font-bold text-slate-900">14m</div>
                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">Avg. Recovery Time</div>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-amber-50 border border-amber-100 flex items-start gap-3">
                    <AlertCircle className="text-amber-600 shrink-0" size={20} />
                    <div>
                      <h4 className="text-sm font-bold text-amber-900">Next Recovery Test</h4>
                      <p className="text-xs text-amber-700 mt-1">Scheduled for tomorrow at 02:00 AM. No action required.</p>
                    </div>
                  </div>
                </div>

                {/* Middle Column: Chart */}
                <div className="p-8 lg:col-span-2 bg-slate-50/50">
                  <div className="flex items-center justify-between mb-8">
                    <h3 className="font-bold text-slate-900">Data Growth Trend</h3>
                    <div className="flex gap-2">
                      <button className="px-3 py-1 text-xs font-bold rounded-md bg-white border border-slate-200 text-slate-600">7D</button>
                      <button className="px-3 py-1 text-xs font-bold rounded-md bg-slate-900 text-white">30D</button>
                    </div>
                  </div>
                  <div className="h-[300px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={data}>
                        <defs>
                          <linearGradient id="colorUsage" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                        <XAxis 
                          dataKey="name" 
                          axisLine={false} 
                          tickLine={false} 
                          tick={{fontSize: 12, fill: '#94a3b8'}}
                          dy={10}
                        />
                        <YAxis 
                          hide 
                        />
                        <Tooltip 
                          contentStyle={{ 
                            borderRadius: '12px', 
                            border: 'none', 
                            boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                            fontSize: '12px'
                          }} 
                        />
                        <Area 
                          type="monotone" 
                          dataKey="usage" 
                          stroke="#10b981" 
                          strokeWidth={3}
                          fillOpacity={1} 
                          fill="url(#colorUsage)" 
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-24 bg-slate-900 text-white overflow-hidden relative">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
            <h2 className="text-4xl font-bold mb-6">Ready to secure your business data?</h2>
            <p className="text-slate-400 mb-10 max-w-xl mx-auto">Join 2,000+ businesses who trust SafeGuard for their daily backup and recovery needs.</p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button className="w-full sm:w-auto px-8 py-4 bg-emerald-500 text-slate-900 font-bold rounded-xl hover:bg-emerald-400 transition-all">
                Start 14-Day Free Trial
              </button>
              <button className="w-full sm:w-auto px-8 py-4 bg-transparent text-white font-bold rounded-xl border border-white/20 hover:bg-white/10 transition-all">
                Contact Sales
              </button>
            </div>
          </div>
          
          {/* Decorative circles */}
          <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/2 w-96 h-96 border border-white/5 rounded-full" />
          <div className="absolute bottom-0 left-0 translate-y-1/2 -translate-x-1/2 w-[600px] h-[600px] border border-white/5 rounded-full" />
        </section>
      </main>

      <footer className="bg-white py-12 border-t border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-emerald-600 rounded flex items-center justify-center text-white">
                <ShieldCheck size={14} />
              </div>
              <span className="text-lg font-bold tracking-tight text-slate-900">SafeGuard</span>
            </div>
            <div className="flex gap-8 text-sm text-slate-500">
              <a href="#" className="hover:text-emerald-600 transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-emerald-600 transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-emerald-600 transition-colors">Security</a>
            </div>
            <div className="text-sm text-slate-400">
              © 2026 SafeGuard Backup & Recovery. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
